# Farm2Home demo accounts (development only)

Created automatically on first launch when the Users table is empty and
`SeedDemoAccounts` is `true` in App.config. Passwords are stored hashed (PBKDF2), never in plaintext.

| Role          | Email                      | Password        |
|---------------|----------------------------|-----------------|
| Consumer      | consumer@farm2home.local   | Farm2Home@2026  |
| Cooperative   | coop@farm2home.local       | Farm2Home@2026  |
| Administrator | admin@farm2home.local      | Farm2Home@2026  |

Before any real deployment: set `SeedDemoAccounts` to `false` and delete these accounts.
