-- Farm2Home seed data (SQLite). Runs only when the database is brand new.
-- Users are NOT seeded here: passwords are hashed with PBKDF2 in C#, so the app creates the demo accounts.

INSERT OR IGNORE INTO Roles (RoleName) VALUES ('Consumer'), ('Cooperative'), ('Administrator');

INSERT OR IGNORE INTO Categories (CategoryName) VALUES
 ('Vegetables'), ('Fruits'), ('Rice & grains'), ('Cacao & coffee'), ('Root crops');

INSERT OR IGNORE INTO Cooperatives (Name, Description, Location, ContactEmail, ContactPhone, EstablishedYear, MemberFarmers, HectaresFarmed) VALUES
 ('Benguet Vegetable Growers Coop', 'Highland growers supplying cool-climate vegetables.', 'La Trinidad, Benguet', 'benguet@farm2home.local', '0917-000-0001', 2004, 212, 340),
 ('Laguna Organic Growers Circle',  'Family farms growing organic fruits and vegetables.', 'Los Baños, Laguna',  'laguna@farm2home.local',  '0917-000-0002', 2011, 86, 120),
 ('Davao Cacao Farmers Assoc.',     'Cacao, coffee and tropical fruit growers.',           'Toril, Davao City',  'davao@farm2home.local',   '0917-000-0003', 1998, 154, 410);

WITH v(Coop, Cat, ProductName, Descr, Price, Unit, Stock, Harvest) AS (VALUES
 ('Benguet Vegetable Growers Coop','Vegetables','Organic Tomatoes','Vine-ripened organic tomatoes, picked this week.',80.00,'kg',120,'Harvested this week'),
 ('Benguet Vegetable Growers Coop','Root crops','Fresh Carrots','Crisp highland carrots, sweet and crunchy.',70.00,'kg',200,'Harvested this week'),
 ('Benguet Vegetable Growers Coop','Vegetables','Organic Lettuce','Cool-climate lettuce, washed and ready to eat.',95.00,'kg',60,'Harvested 2 days ago'),
 ('Benguet Vegetable Growers Coop','Vegetables','Fresh Spinach','Tender leafy spinach from the highlands.',90.00,'kg',45,'Harvested 2 days ago'),
 ('Laguna Organic Growers Circle','Vegetables','Native Eggplant','Slender native eggplant grown without synthetic pesticides.',65.00,'kg',90,'Harvested this week'),
 ('Laguna Organic Growers Circle','Vegetables','Organic Cucumber','Firm, refreshing organic cucumbers.',55.00,'kg',80,'Harvested this week'),
 ('Laguna Organic Growers Circle','Root crops','Sweet Potato','Naturally sweet camote, great for boiling or baking.',50.00,'kg',150,'Harvested last week'),
 ('Laguna Organic Growers Circle','Fruits','Fresh Calamansi','Juicy calamansi, perfect for juice and cooking.',120.00,'kg',70,'Harvested this week'),
 ('Davao Cacao Farmers Assoc.','Fruits','Local Bananas','Sweet lakatan bananas from Davao farms.',60.00,'kg',180,'Harvested this week'),
 ('Davao Cacao Farmers Assoc.','Rice & grains','Native Corn','Fresh native corn on the cob.',45.00,'kg',100,'Harvested this week')
)
INSERT INTO Products (CooperativeId, CategoryId, ProductName, Description, Price, Unit, StockQuantity, HarvestInfo)
SELECT c.CooperativeId, k.CategoryId, v.ProductName, v.Descr, v.Price, v.Unit, v.Stock, v.Harvest
FROM v
JOIN Cooperatives c ON c.Name = v.Coop
JOIN Categories  k ON k.CategoryName = v.Cat
WHERE NOT EXISTS (SELECT 1 FROM Products);

INSERT OR IGNORE INTO PromoCodes (Code, Percent) VALUES ('FARM10', 10), ('FRESH5', 5);
