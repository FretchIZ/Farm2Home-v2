-- Farm2Home schema (SQLite). Safe to re-run: every statement uses IF NOT EXISTS.
-- Dates are stored as UTC text 'YYYY-MM-DD HH:MM:SS'. Booleans are 0/1.

CREATE TABLE IF NOT EXISTS Roles (
    RoleId   INTEGER PRIMARY KEY AUTOINCREMENT,
    RoleName TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Cooperatives (
    CooperativeId INTEGER PRIMARY KEY AUTOINCREMENT,
    Name          TEXT NOT NULL UNIQUE,
    Description   TEXT NULL,
    Location      TEXT NOT NULL,
    ContactEmail  TEXT NULL,
    ContactPhone  TEXT NULL,
    ImagePath     TEXT NULL,
    IsOrganicCertified INTEGER NOT NULL DEFAULT 1,
    IsActive      INTEGER NOT NULL DEFAULT 1,
    CreatedAt     DATETIME NOT NULL DEFAULT (datetime('now')),
    EstablishedYear INTEGER NULL,
    MemberFarmers   INTEGER NULL,
    HectaresFarmed  INTEGER NULL
);

CREATE TABLE IF NOT EXISTS Users (
    UserId        INTEGER PRIMARY KEY AUTOINCREMENT,
    Email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    CanonicalEmail TEXT NULL,                       -- same mailbox spelled differently (Gmail dots / +tags) maps to one value
    FullName      TEXT NOT NULL,
    PasswordHash  BLOB NOT NULL,
    PasswordSalt  BLOB NOT NULL,
    RoleId        INTEGER NOT NULL REFERENCES Roles(RoleId),
    CooperativeId INTEGER NULL REFERENCES Cooperatives(CooperativeId),
    ContactNumber TEXT NULL,
    DefaultAddress TEXT NULL,
    IsActive      INTEGER NOT NULL DEFAULT 1,
    FailedLogins  INTEGER NOT NULL DEFAULT 0,
    CreatedAt     DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Categories (
    CategoryId   INTEGER PRIMARY KEY AUTOINCREMENT,
    CategoryName TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Products (
    ProductId     INTEGER PRIMARY KEY AUTOINCREMENT,
    CooperativeId INTEGER NOT NULL REFERENCES Cooperatives(CooperativeId),
    CategoryId    INTEGER NOT NULL REFERENCES Categories(CategoryId),
    ProductName   TEXT NOT NULL,
    Description   TEXT NOT NULL,
    Price         NUMERIC NOT NULL CONSTRAINT CK_Products_Price CHECK (Price > 0),
    Unit          TEXT NOT NULL,
    StockQuantity INTEGER NOT NULL CONSTRAINT CK_Products_Stock CHECK (StockQuantity >= 0),
    IsAvailable   INTEGER NOT NULL DEFAULT 1,
    ImagePath     TEXT NULL,
    HarvestInfo   TEXT NULL,
    IsDeleted     INTEGER NOT NULL DEFAULT 0,
    CreatedAt     DATETIME NOT NULL DEFAULT (datetime('now')),
    UpdatedAt     DATETIME NULL
);
CREATE INDEX IF NOT EXISTS IX_Products_Search ON Products(ProductName) WHERE IsDeleted = 0;
CREATE INDEX IF NOT EXISTS IX_Products_Coop ON Products(CooperativeId);

CREATE TABLE IF NOT EXISTS Carts (
    CartId    INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId    INTEGER NOT NULL UNIQUE REFERENCES Users(UserId),
    UpdatedAt DATETIME NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS CartItems (
    CartItemId INTEGER PRIMARY KEY AUTOINCREMENT,
    CartId     INTEGER NOT NULL REFERENCES Carts(CartId) ON DELETE CASCADE,
    ProductId  INTEGER NOT NULL REFERENCES Products(ProductId),
    Quantity   INTEGER NOT NULL CONSTRAINT CK_CartItems_Qty CHECK (Quantity > 0),
    CONSTRAINT UQ_CartItems UNIQUE (CartId, ProductId)
);

CREATE TABLE IF NOT EXISTS Orders (
    OrderId         INTEGER PRIMARY KEY AUTOINCREMENT,
    OrderNumber     TEXT NOT NULL UNIQUE,            -- e.g. FH-2026-000123
    CustomerId      INTEGER NOT NULL REFERENCES Users(UserId),
    CooperativeId   INTEGER NOT NULL REFERENCES Cooperatives(CooperativeId),
    OrderDate       DATETIME NOT NULL DEFAULT (datetime('now')),
    Subtotal        NUMERIC NOT NULL,
    DeliveryFee     NUMERIC NOT NULL,
    Discount        NUMERIC NOT NULL DEFAULT 0,      -- promo code saving
    PromoCode       TEXT NULL,
    Total           NUMERIC NOT NULL,
    PaymentMethod   TEXT NOT NULL DEFAULT 'CashOnDelivery',
    PaymentStatus   TEXT NOT NULL DEFAULT 'Unpaid',
    OrderStatus     INTEGER NOT NULL DEFAULT 1
        CONSTRAINT CK_Orders_Status CHECK (OrderStatus BETWEEN 1 AND 7),
        -- 1 Pending, 2 Confirmed, 3 Preparing, 4 ReadyForDelivery,
        -- 5 OutForDelivery, 6 Delivered, 7 Cancelled
    CustomerName    TEXT NOT NULL,
    DeliveryAddress TEXT NOT NULL,
    ContactNumber   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_Orders_Customer ON Orders(CustomerId);
CREATE INDEX IF NOT EXISTS IX_Orders_Coop ON Orders(CooperativeId);

CREATE TABLE IF NOT EXISTS OrderItems (
    OrderItemId INTEGER PRIMARY KEY AUTOINCREMENT,
    OrderId     INTEGER NOT NULL REFERENCES Orders(OrderId) ON DELETE CASCADE,
    ProductId   INTEGER NOT NULL REFERENCES Products(ProductId),
    ProductName TEXT NOT NULL,                      -- snapshot at purchase time
    Quantity    INTEGER NOT NULL CHECK (Quantity > 0),
    UnitPrice   NUMERIC NOT NULL,                   -- actual purchase price
    Subtotal    NUMERIC NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_OrderItems_Order ON OrderItems(OrderId);

CREATE TABLE IF NOT EXISTS Deliveries (
    DeliveryId  INTEGER PRIMARY KEY AUTOINCREMENT,
    OrderId     INTEGER NOT NULL UNIQUE REFERENCES Orders(OrderId) ON DELETE CASCADE,
    Status      INTEGER NOT NULL DEFAULT 1,
    UpdatedAt   DATETIME NOT NULL DEFAULT (datetime('now')),
    Notes       TEXT NULL
);

CREATE TABLE IF NOT EXISTS PromoCodes (
    Code     TEXT PRIMARY KEY COLLATE NOCASE,
    Percent  INTEGER NOT NULL CHECK (Percent BETWEEN 1 AND 90),
    IsActive INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS Follows (
    UserId        INTEGER NOT NULL REFERENCES Users(UserId) ON DELETE CASCADE,
    CooperativeId INTEGER NOT NULL REFERENCES Cooperatives(CooperativeId) ON DELETE CASCADE,
    CreatedAt     DATETIME NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (UserId, CooperativeId)
);

CREATE TABLE IF NOT EXISTS Messages (
    MessageId     INTEGER PRIMARY KEY AUTOINCREMENT,
    FromUserId    INTEGER NOT NULL REFERENCES Users(UserId) ON DELETE CASCADE,
    CooperativeId INTEGER NOT NULL REFERENCES Cooperatives(CooperativeId) ON DELETE CASCADE,
    Body          TEXT NOT NULL,
    IsRead        INTEGER NOT NULL DEFAULT 0,
    CreatedAt     DATETIME NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS IX_Messages_Coop ON Messages(CooperativeId, IsRead);

CREATE TABLE IF NOT EXISTS Reviews (
    ReviewId  INTEGER PRIMARY KEY AUTOINCREMENT,
    ProductId INTEGER NOT NULL REFERENCES Products(ProductId),
    UserId    INTEGER NOT NULL REFERENCES Users(UserId) ON DELETE CASCADE,
    Rating    INTEGER NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    Comment   TEXT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT (datetime('now')),
    CONSTRAINT UQ_Reviews UNIQUE (ProductId, UserId)
);
CREATE INDEX IF NOT EXISTS IX_Reviews_Product ON Reviews(ProductId);

CREATE UNIQUE INDEX IF NOT EXISTS UX_Users_CanonicalEmail ON Users(CanonicalEmail);
