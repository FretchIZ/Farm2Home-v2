# Farm2Home colour, contrast and states (section 1.3)

## Rule followed
The original palette is kept. Fixes were made first with outlines, focus rings, shape cues, weight and size; a colour value was changed only where those could not work.

## Colours
- 27 of 28 colours are identical to the original (checked by an automated test against the original values).
- One colour changed: `MarigoldText` `#B9761A` -> `#955F15` (same hue, lighter shade removed). It is used for small amber text (Pending badges, "Needs action", low stock, "New"). The original measured 3.17-3.70:1; it now measures 4.6-5.4:1 (AA needs 4.5:1). Size/weight could not fix it because the text is small.
- No new colours, gradients or themes. Three colours that were typed straight into drawing code now have names (`NeutralBadge`, `ToggleTrack`, `UnreadTint`), values unchanged.
- Colours are defined once in `Farm2Home.UI/Resources/Palette.cs`.

## What was done without changing any colour
| Problem (original) | Fix |
|---|---|
| Input, dropdown, quantity and date outlines 1.2-1.5:1 | Outline now uses the existing `Muted` green-grey (5.0:1 or more); 2px `Forest` while focused |
| Focus ring in marigold, 1.95:1 on the page | Two-tone ring: `Forest` outer + white inner, visible on every button colour; sidebar items get a white ring |
| Unticked box, off switch, slider track faint | `Muted` outline/fill; switch shows a tick when on |
| Empty vs filled stars differed only by colour | Empty = hollow outline, filled = marigold with darker outline |
| Selected segment (Consumer/Cooperative) 1.2:1 | Outlined in `Forest`; now reachable by keyboard (Tab, arrow keys) |
| Outline/Chip buttons had no pressed state | Pressed: tint plus label moves 1px |
| Unread message shown by dot and tint only | Added the word "New" |
| Hero eyebrow 4.40:1 | Uses the existing lighter `MarigoldHover` (5.05:1) |
| Secondary text at 8-8.5pt | Raised to 9pt |
| Buttons had no loading state | `FlatButton.Busy` shows a spinner and ignores clicks |
| Windows High Contrast ignored | Borders and focus rings use system colours when it is on |

## Documented exceptions (not changed)
- Disabled button label `Muted` on `Disabled`, 4.3:1: inactive components are exempt (WCAG 1.4.3); still visibly different.
- Card hairlines and dividers (`Border`, `BorderStrong`): decorative, never the only cue for a control.
- Placeholder icons (`IconGreen` on page/tint): decorative, text label alongside.
- Decorative marigold shapes: decoration only.
- Segmented-toggle track: selected segment is outlined and every segment is labelled.
These are listed in `Farm2Home.Tests/ContrastTests.cs`; the test fails if one starts passing or a new pair fails.

## Verification
- `Farm2Home.Tests`: 6 colour tests (identity, adjustment size, ~50 contrast pairs, exceptions, maths). Full suite: 102 passed, 0 failed.
- Visual regression (`docs/visual-regression`): same pages captured before and after at 1280x800. Changed pixels per page: 0.1% to 2.2%, all outlines, focus and text size. Also captured at 1000x660 (minimum) and 1920x1080: no clipping.
- Run yourself: `Farm2Home.exe --selftest --size 1000x660 --shots <folder>`.

## Limits
- UI was rendered on Mono/Linux (Xvfb), not Windows. Fonts and anti-aliasing differ slightly on Windows.
- The app has no DPI manifest, so Windows scales it as a whole at 125-200%; this was not changed and not tested.
- High Contrast mode is applied at start-up; it was not tested on a real Windows High Contrast theme.
- The sign-in window cannot be screenshotted under Mono (a Mono drawing limit, same in the original), so its colours are checked by the contrast tests only.
