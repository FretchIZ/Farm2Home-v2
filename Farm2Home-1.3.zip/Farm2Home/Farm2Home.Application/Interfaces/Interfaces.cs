using System;
using System.Collections.Generic;
using Farm2Home.Application.DTOs;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Application.Interfaces
{
    public interface IAppLogger
    {
        void Info(string message);
        void Error(Exception ex, string context);
    }

    public interface ICategoryRepository
    {
        List<Category> GetAll();
    }

    public interface ICooperativeRepository
    {
        List<Cooperative> GetAll(string search);
        Cooperative GetById(int cooperativeId);
        bool UpdateProfile(Cooperative cooperative);
        PublicStats GetPublicStats();      // counts only; safe to show before sign-in
    }

    public interface IProductRepository
    {
        List<Product> Search(ProductFilter filter);
        List<Product> GetByCooperative(int cooperativeId);   // includes unavailable listings
        Product GetById(int productId);
        int Add(int cooperativeId, ProductInput input);
        bool Update(int cooperativeId, ProductInput input);
        bool SoftDelete(int cooperativeId, int productId);
        bool UpdateStock(int cooperativeId, int productId, int stockQuantity);
    }

    public interface ICartRepository
    {
        List<CartItem> GetItems(int userId);
        int GetQuantity(int userId, int productId);
        void SetItem(int userId, int productId, int quantity);
        void RemoveItem(int userId, int productId);
        void Clear(int userId);
    }

    public interface IOrderRepository
    {
        /// <summary>Atomically turns the user's cart into orders (one per cooperative).</summary>
        List<Order> PlaceOrders(int userId, CheckoutRequest request, decimal deliveryFeePerOrder);
        Order GetById(int orderId);
        List<Order> GetByCustomer(int userId);
        List<Order> GetByCooperative(int cooperativeId);
        void UpdateStatus(int orderId, OrderStatus status);
        void Cancel(int orderId);   // restocks inventory
        CooperativeStats GetStats(int cooperativeId);
        List<DailySale> GetDailySales(int cooperativeId, int days);   // oldest first, ends today
    }
}

namespace Farm2Home.Application.Interfaces
{
    public interface IUserRepository
    {
        User GetByEmail(string email);                 // also finds the same mailbox spelled differently (Gmail dots / +tags)
        int Create(User user);          // throws BusinessException if the email is already used
        int CountUsers();
        void UpdatePassword(int userId, byte[] hash, byte[] salt);
    }

    public interface IPasswordHasher
    {
        void Hash(string password, out byte[] hash, out byte[] salt);
        bool Verify(string password, byte[] hash, byte[] salt);
    }
}

namespace Farm2Home.Application.Interfaces
{
    /// <summary>Promo codes, following a cooperative, messages to cooperatives and product reviews.</summary>
    public interface IEngagementRepository
    {
        int? GetPromoPercent(string code);                      // null when the code does not exist or is switched off

        bool IsFollowing(int userId, int cooperativeId);
        void SetFollowing(int userId, int cooperativeId, bool follow);

        int AddMessage(int fromUserId, int cooperativeId, string body);
        List<CoopMessage> GetInbox(int cooperativeId);
        void MarkRead(int cooperativeId, int messageId);
        int UnreadCount(int cooperativeId);

        List<Review> GetReviews(int productId);
        bool HasDeliveredOrder(int userId, int productId);
        void SaveReview(Review review);                         // one review per person per product; saving again updates it
    }
}
