using System;
using System.Collections.Generic;

namespace Farm2Home.Application
{
    /// <summary>An expected, user-facing error. The message is safe to show in the UI.</summary>
    public class BusinessException : Exception
    {
        public BusinessException(string message) : base(message) { }

        public static BusinessException FromErrors(IEnumerable<string> errors)
        {
            return new BusinessException(string.Join(Environment.NewLine, errors));
        }
    }
}
