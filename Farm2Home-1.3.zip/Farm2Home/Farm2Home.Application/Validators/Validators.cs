using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Farm2Home.Application.DTOs;

namespace Farm2Home.Application.Validators
{
    public static class ProductValidator
    {
        public static readonly string[] Units = { "kg", "g", "piece", "bundle", "sack", "dozen", "liter" };

        public static List<string> Validate(ProductInput p)
        {
            var e = new List<string>();
            if (string.IsNullOrWhiteSpace(p.ProductName)) e.Add("Product name is required.");
            else if (p.ProductName.Trim().Length > 120) e.Add("Product name must be 120 characters or fewer.");
            if (p.CategoryId <= 0) e.Add("Please select a category.");
            if (string.IsNullOrWhiteSpace(p.Unit) || !Units.Contains(p.Unit)) e.Add("Please select a unit.");
            if (p.Price <= 0) e.Add("Price must be greater than zero.");
            if (p.Price > 1000000m) e.Add("Price is too large.");
            if (p.Price > 0 && decimal.Round(p.Price, 2) != p.Price) e.Add("Price can have at most 2 decimal places.");
            if (p.StockQuantity < 0) e.Add("Stock cannot be negative.");
            if (p.StockQuantity > 1000000) e.Add("Stock quantity is too large.");
            var d = (p.Description ?? "").Trim();
            if (d.Length < 10 || d.Length > 1000) e.Add("Description must be between 10 and 1000 characters.");
            if (!string.IsNullOrEmpty(p.HarvestInfo) && p.HarvestInfo.Length > 200) e.Add("Harvest information is too long.");
            if (!string.IsNullOrEmpty(p.ImagePath) && p.ImagePath.Length > 260) e.Add("Image path is too long.");
            return e;
        }
    }

    public static class CheckoutValidator
    {
        private static readonly Regex Phone = new Regex(@"^[0-9+\-\s()]{7,20}$");
        public static readonly string[] PaymentMethods = { "CashOnDelivery" };

        public static List<string> Validate(CheckoutRequest r)
        {
            var e = new List<string>();
            if (string.IsNullOrWhiteSpace(r.CustomerName)) e.Add("Customer name is required.");
            else if (r.CustomerName.Trim().Length > 150) e.Add("Customer name is too long.");
            if (string.IsNullOrWhiteSpace(r.ContactNumber) || !Phone.IsMatch(r.ContactNumber.Trim()))
                e.Add("Please enter a valid contact number.");
            if (string.IsNullOrWhiteSpace(r.DeliveryAddress)) e.Add("Delivery address is required.");
            else if (r.DeliveryAddress.Trim().Length < 10 || r.DeliveryAddress.Trim().Length > 300)
                e.Add("Please enter a complete delivery address (10-300 characters).");
            if (!PaymentMethods.Contains(r.PaymentMethod)) e.Add("Please choose a valid payment method.");
            if (r.DeliverySlot != null && r.DeliverySlot.Length > 100) e.Add("Delivery time slot is too long.");
            return e;
        }
    }
}
