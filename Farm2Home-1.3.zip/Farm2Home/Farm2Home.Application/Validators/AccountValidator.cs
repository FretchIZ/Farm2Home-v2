using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Farm2Home.Application.Validators
{
    public static class AccountValidator
    {
        private static readonly Regex Email = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        private static readonly Regex Phone = new Regex(@"^[0-9+\-\s()]{7,20}$");

        public static bool IsValidEmail(string email)
        {
            return EmailRules.IsValid(email);
        }

        public static List<string> ValidatePassword(string password)
        {
            var e = new List<string>();
            if (string.IsNullOrEmpty(password) || password.Length < 8) e.Add("Password must be at least 8 characters.");
            else if (password.Length > 128) e.Add("Password is too long.");
            else if (!password.Any(char.IsLetter) || !password.Any(char.IsDigit))
                e.Add("Password must contain at least one letter and one number.");
            return e;
        }

        public static List<string> ValidateRegistration(string fullName, string email, string password, string contact)
        {
            var e = new List<string>();
            if (string.IsNullOrWhiteSpace(fullName)) e.Add("Full name is required.");
            else if (fullName.Trim().Length > 150) e.Add("Full name is too long.");
            var emailProblem = EmailRules.Problem(email);
            if (emailProblem != null) e.Add(emailProblem);
            e.AddRange(ValidatePassword(password));
            if (!string.IsNullOrWhiteSpace(contact) && !Phone.IsMatch(contact.Trim()))
                e.Add("Please enter a valid contact number.");
            return e;
        }
    }
}
