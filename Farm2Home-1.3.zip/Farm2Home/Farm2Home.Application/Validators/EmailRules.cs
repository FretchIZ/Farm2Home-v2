using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Farm2Home.Application.Validators
{
    /// <summary>One place for what counts as a real email address, how it is stored, and when two spellings are the same mailbox.</summary>
    public static class EmailRules
    {
        private static readonly Regex Local = new Regex(@"^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*$", RegexOptions.Compiled);
        private static readonly Regex Label = new Regex(@"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$", RegexOptions.Compiled);

        /// <summary>Common typos of big providers. Better to ask than to store an address nobody can read.</summary>
        private static readonly string[][] Typos =
        {
            new[] { "gmial.com", "gmail.com" }, new[] { "gmal.com", "gmail.com" }, new[] { "gamil.com", "gmail.com" },
            new[] { "gmail.con", "gmail.com" }, new[] { "gmail.co", "gmail.com" }, new[] { "gmail.cm", "gmail.com" },
            new[] { "gmai.com", "gmail.com" }, new[] { "gmail.comm", "gmail.com" },
            new[] { "yaho.com", "yahoo.com" }, new[] { "yahoo.con", "yahoo.com" }, new[] { "yahooo.com", "yahoo.com" },
            new[] { "hotmial.com", "hotmail.com" }, new[] { "hotmail.con", "hotmail.com" }, new[] { "outlok.com", "outlook.com" },
            new[] { "outlook.con", "outlook.com" }
        };

        /// <summary>Trimmed, lower-case. This is what is stored and shown.</summary>
        public static string Normalize(string email) { return (email ?? "").Trim().ToLowerInvariant(); }

        /// <summary>Null when the address looks like a real mailbox, otherwise a friendly reason.</summary>
        public static string Problem(string email)
        {
            string e = Normalize(email);
            if (e.Length == 0) return "Email is required.";
            if (e.Length > 150) return "That email address is too long.";
            int at = e.LastIndexOf('@');
            if (at <= 0 || at != e.IndexOf('@')) return "Please enter a valid email address, like name@gmail.com.";
            string local = e.Substring(0, at), domain = e.Substring(at + 1);
            if (local.Length > 64 || !Local.IsMatch(local)) return "Please enter a valid email address, like name@gmail.com.";
            var labels = domain.Split('.');
            if (labels.Length < 2 || labels.Any(l => l.Length == 0 || l.Length > 63 || !Label.IsMatch(l)))
                return "Please enter a valid email address, like name@gmail.com.";
            string tld = labels[labels.Length - 1];
            if (tld.Length < 2 || !tld.All(char.IsLetter)) return "Please enter a valid email address, like name@gmail.com.";
            foreach (var t in Typos)
                if (domain == t[0]) return "Did you mean " + local + "@" + t[1] + "? Please check the spelling.";
            return null;
        }

        public static bool IsValid(string email) { return Problem(email) == null; }

        /// <summary>
        /// The mailbox identity. Gmail ignores dots and "+tags" (john.doe+shop@gmail.com is johndoe@gmail.com), so those spellings
        /// must not become two accounts. Other providers: just the lower-case address.
        /// </summary>
        public static string Canonical(string email)
        {
            string e = Normalize(email);
            int at = e.LastIndexOf('@');
            if (at <= 0) return e;
            string local = e.Substring(0, at), domain = e.Substring(at + 1);
            if (domain == "gmail.com" || domain == "googlemail.com")
            {
                int plus = local.IndexOf('+');
                if (plus >= 0) local = local.Substring(0, plus);
                local = local.Replace(".", "");
                domain = "gmail.com";
            }
            return local + "@" + domain;
        }
    }
}
