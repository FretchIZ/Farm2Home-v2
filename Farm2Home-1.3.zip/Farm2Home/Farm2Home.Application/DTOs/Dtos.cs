using System;
using System.Collections.Generic;
using System.Linq;
using Farm2Home.Domain.Entities;

namespace Farm2Home.Application.DTOs
{
    public enum ProductSort { RecentlyAdded, PriceLowToHigh, PriceHighToLow, NameAToZ }

    public class ProductFilter
    {
        public string Search { get; set; }
        public int? CategoryId { get; set; }
        public int? CooperativeId { get; set; }
        public bool InStockOnly { get; set; }
        public bool OrganicOnly { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public ProductSort Sort { get; set; } = ProductSort.RecentlyAdded;
        public int? Take { get; set; }
    }

    public class CartSummary
    {
        public List<CartItem> Items { get; set; } = new List<CartItem>();
        public decimal Subtotal { get { return Items.Sum(i => i.Subtotal); } }
        public int ItemCount { get { return Items.Sum(i => i.Quantity); } }
    }

    public class CheckoutRequest
    {
        public string CustomerName { get; set; }
        public string ContactNumber { get; set; }
        public string DeliveryAddress { get; set; }
        public string PaymentMethod { get; set; } = "CashOnDelivery";
        public string DeliverySlot { get; set; }      // optional, e.g. "Tomorrow, 8-10 AM"
        public string PromoCode { get; set; }         // optional; checked again by the database layer
    }

    public class ProductInput
    {
        public int ProductId { get; set; }          // 0 = new listing
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string Unit { get; set; }
        public int StockQuantity { get; set; }
        public bool IsAvailable { get; set; } = true;
        public string ImagePath { get; set; }
        public string HarvestInfo { get; set; }
    }

    public class CooperativeStats
    {
        public int TotalProducts { get; set; }
        public int ActiveListings { get; set; }
        public int PendingOrders { get; set; }
        public int CompletedOrders { get; set; }
        public decimal TotalSales { get; set; }          // delivered orders, all time
        public decimal MonthSales { get; set; }          // not cancelled, this calendar month
        public int CustomersReached { get; set; }        // distinct customers with a non-cancelled order
    }

    public class DailySale
    {
        public DateTime Date { get; set; }
        public decimal Total { get; set; }
    }

    public class PublicStats
    {
        public int Cooperatives { get; set; }
        public int Products { get; set; }
    }

    public class PromoInfo
    {
        public string Code { get; set; }
        public int Percent { get; set; }
    }
}
