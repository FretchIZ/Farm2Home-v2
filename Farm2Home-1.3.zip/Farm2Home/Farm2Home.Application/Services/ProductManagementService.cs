using System.Collections.Generic;
using System.Linq;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Application.Validators;
using Farm2Home.Domain.Entities;

namespace Farm2Home.Application.Services
{
    /// <summary>Cooperative-only listing management, always scoped to the signed-in user's cooperative.</summary>
    public class ProductManagementService
    {
        private readonly IProductRepository _products;
        private readonly IOrderRepository _orders;
        private readonly SessionService _session;

        public ProductManagementService(IProductRepository products, IOrderRepository orders, SessionService session)
        {
            _products = products; _orders = orders; _session = session;
        }

        private int CoopId { get { return _session.RequireCooperativeId(); } }

        public List<Product> GetListings() { return _products.GetByCooperative(CoopId); }

        public Product GetForEdit(int productId)
        {
            int coopId = CoopId;
            var p = _products.GetById(productId);
            if (p == null || p.CooperativeId != coopId) throw new BusinessException("Listing not found.");
            return p;
        }

        public int Save(ProductInput input)
        {
            int coopId = CoopId;
            var errors = ProductValidator.Validate(input);
            if (errors.Any()) throw BusinessException.FromErrors(errors);

            input.ProductName = input.ProductName.Trim();
            input.Description = input.Description.Trim();

            if (input.ProductId <= 0) return _products.Add(coopId, input);
            if (!_products.Update(coopId, input)) throw new BusinessException("Listing not found.");
            return input.ProductId;
        }

        public void Delete(int productId)
        {
            if (!_products.SoftDelete(CoopId, productId)) throw new BusinessException("Listing not found.");
        }

        public void UpdateStock(int productId, int stock)
        {
            int coopId = CoopId;
            if (stock < 0) throw new BusinessException("Stock cannot be negative.");
            if (!_products.UpdateStock(coopId, productId, stock)) throw new BusinessException("Listing not found.");
        }

        public CooperativeStats GetStats() { return _orders.GetStats(CoopId); }

        public List<DailySale> GetWeeklySales() { return _orders.GetDailySales(CoopId, 7); }
    }
}
