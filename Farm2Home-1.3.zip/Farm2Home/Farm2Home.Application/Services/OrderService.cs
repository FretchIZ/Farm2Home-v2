using System.Collections.Generic;
using System.Linq;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Application.Validators;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Application.Services
{
    public class OrderService
    {
        public const decimal DeliveryFeePerOrder = 60m;
        /// <summary>The saving a promo code gives on one cooperative's part of the cart (rounded to centavos).</summary>
        public static decimal DiscountFor(decimal subtotal, int percent)
        {
            return percent <= 0 ? 0m : System.Math.Round(subtotal * percent / 100m, 2, System.MidpointRounding.AwayFromZero);
        }

        private readonly IOrderRepository _orders;
        private readonly SessionService _session;

        public OrderService(IOrderRepository orders, SessionService session)
        {
            _orders = orders; _session = session;
        }

        private int ConsumerId { get { return _session.RequireRole(UserRole.Consumer).UserId; } }

        // ----- consumer -----
        public List<Order> PlaceOrders(CheckoutRequest request)
        {
            int userId = ConsumerId;
            var errors = CheckoutValidator.Validate(request);
            if (errors.Any()) throw BusinessException.FromErrors(errors);
            request.CustomerName = request.CustomerName.Trim();
            request.ContactNumber = request.ContactNumber.Trim();
            request.DeliveryAddress = request.DeliveryAddress.Trim();
            return _orders.PlaceOrders(userId, request, DeliveryFeePerOrder);
        }

        public Order GetMyOrder(int orderId)
        {
            int userId = ConsumerId;
            var o = _orders.GetById(orderId);
            if (o == null || o.CustomerId != userId) throw new BusinessException("Order not found.");
            return o;
        }

        public List<Order> GetMyOrders() { return _orders.GetByCustomer(ConsumerId); }

        public void CancelMyOrder(int orderId)
        {
            var o = GetMyOrder(orderId);
            if (o.OrderStatus != OrderStatus.Pending && o.OrderStatus != OrderStatus.Confirmed)
                throw new BusinessException("This order can no longer be cancelled.");
            _orders.Cancel(orderId);
        }

        // ----- cooperative -----
        public List<Order> GetCooperativeOrders() { return _orders.GetByCooperative(_session.RequireCooperativeId()); }

        /// <summary>Moves an order one step forward, or cancels it while still Pending/Confirmed.</summary>
        public void UpdateStatus(int orderId, OrderStatus newStatus)
        {
            int coopId = _session.RequireCooperativeId();
            var o = _orders.GetById(orderId);
            if (o == null || o.CooperativeId != coopId) throw new BusinessException("Order not found.");
            if (o.OrderStatus == OrderStatus.Delivered || o.OrderStatus == OrderStatus.Cancelled)
                throw new BusinessException("This order is already closed.");

            if (newStatus == OrderStatus.Cancelled)
            {
                if (o.OrderStatus > OrderStatus.Confirmed)
                    throw new BusinessException("An order being prepared or delivered cannot be cancelled.");
                _orders.Cancel(orderId);
                return;
            }
            if ((int)newStatus != (int)o.OrderStatus + 1)
                throw new BusinessException("Orders must move one step at a time.");
            _orders.UpdateStatus(orderId, newStatus);
        }
    }
}
