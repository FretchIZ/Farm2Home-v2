using System;
using System.Linq;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Application.Services
{
    /// <summary>Immutable snapshot of the signed-in user. Never holds the password or its hash.</summary>
    public sealed class SessionUser
    {
        public int UserId { get; }
        public string Email { get; }
        public string FullName { get; }
        public UserRole Role { get; }
        public int? CooperativeId { get; }
        public string ContactNumber { get; }
        public string DefaultAddress { get; }
        public DateTime LoginTime { get; }

        public SessionUser(User u)
        {
            UserId = u.UserId; Email = u.Email; FullName = u.FullName; Role = u.Role;
            CooperativeId = u.CooperativeId; ContactNumber = u.ContactNumber; DefaultAddress = u.DefaultAddress;
            LoginTime = DateTime.Now;
        }
    }

    /// <summary>Holds the current user for this app run and enforces role checks for services.</summary>
    public class SessionService
    {
        private SessionUser _current;

        public SessionUser CurrentUser { get { return _current; } }
        public bool IsLoggedIn { get { return _current != null; } }

        public void Start(User user) { _current = new SessionUser(user); }
        public void End() { _current = null; }

        public SessionUser RequireLogin()
        {
            var u = _current;
            if (u == null) throw new BusinessException("Please sign in to continue.");
            return u;
        }

        public SessionUser RequireRole(params UserRole[] roles)
        {
            var u = RequireLogin();
            if (!roles.Contains(u.Role))
                throw new BusinessException("You do not have permission to do that.");
            return u;
        }

        /// <summary>Requires a cooperative user and returns the cooperative they belong to.</summary>
        public int RequireCooperativeId()
        {
            var u = RequireRole(UserRole.Cooperative);
            if (!u.CooperativeId.HasValue)
                throw new BusinessException("Your account is not linked to a cooperative. Please contact support.");
            return u.CooperativeId.Value;
        }
    }
}
