using System.Collections.Generic;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;

namespace Farm2Home.Application.Services
{
    /// <summary>Read-only marketplace queries. Requires a signed-in user.</summary>
    public class CatalogService
    {
        private readonly IProductRepository _products;
        private readonly ICategoryRepository _categories;
        private readonly ICooperativeRepository _coops;
        private readonly SessionService _session;

        public CatalogService(IProductRepository products, ICategoryRepository categories,
                              ICooperativeRepository coops, SessionService session)
        {
            _products = products; _categories = categories; _coops = coops; _session = session;
        }

        public List<Product> Browse(ProductFilter filter)
        {
            _session.RequireLogin();
            return _products.Search(filter ?? new ProductFilter());
        }

        public Product GetProduct(int productId)
        {
            _session.RequireLogin();
            var p = _products.GetById(productId);
            if (p == null) throw new BusinessException("This product could not be found.");
            return p;
        }

        public List<Category> GetCategories() { _session.RequireLogin(); return _categories.GetAll(); }

        public List<Cooperative> GetCooperatives(string search = null)
        {
            _session.RequireLogin();
            return _coops.GetAll(search);
        }

        public Cooperative GetCooperative(int id)
        {
            _session.RequireLogin();
            var c = _coops.GetById(id);
            if (c == null) throw new BusinessException("This cooperative could not be found.");
            return c;
        }

        public List<Product> GetCooperativeProducts(int cooperativeId)
        {
            _session.RequireLogin();
            return _products.Search(new ProductFilter { CooperativeId = cooperativeId, InStockOnly = true });
        }
    }
}
