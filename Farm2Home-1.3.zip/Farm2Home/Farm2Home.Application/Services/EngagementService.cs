using System.Collections.Generic;
using System.Linq;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Application.Services
{
    /// <summary>Promo codes, following cooperatives, messages to cooperatives and product reviews. Every rule is enforced here.</summary>
    public class EngagementService
    {
        public const int MaxMessageLength = 500;
        public const int MaxCommentLength = 500;

        private readonly IEngagementRepository _repo;
        private readonly SessionService _session;
        private PromoInfo _promo;
        private int _promoUser;

        public EngagementService(IEngagementRepository repo, SessionService session) { _repo = repo; _session = session; }

        // ----- promo codes (consumer) -----
        /// <summary>The code the signed-in consumer applied in the cart, or null.</summary>
        public PromoInfo AppliedPromo
        {
            get
            {
                var u = _session.CurrentUser;
                return (u != null && _promo != null && _promoUser == u.UserId) ? _promo : null;
            }
        }

        public PromoInfo ApplyPromo(string code)
        {
            var u = _session.RequireRole(UserRole.Consumer);
            string c = (code ?? "").Trim().ToUpperInvariant();
            if (c.Length == 0) throw new BusinessException("Please enter a promo code.");
            int? pct = c.Length <= 20 ? _repo.GetPromoPercent(c) : null;
            if (!pct.HasValue) throw new BusinessException("That promo code isn't valid.");
            _promo = new PromoInfo { Code = c, Percent = pct.Value };
            _promoUser = u.UserId;
            return _promo;
        }

        public void ClearPromo() { _promo = null; }

        // ----- following (consumer) -----
        public bool IsFollowing(int cooperativeId)
        {
            return _repo.IsFollowing(_session.RequireRole(UserRole.Consumer).UserId, cooperativeId);
        }

        /// <summary>Follows or un-follows. Returns true when the person now follows the cooperative.</summary>
        public bool ToggleFollow(int cooperativeId)
        {
            int userId = _session.RequireRole(UserRole.Consumer).UserId;
            bool now = !_repo.IsFollowing(userId, cooperativeId);
            _repo.SetFollowing(userId, cooperativeId, now);
            return now;
        }

        // ----- messages -----
        public void SendMessage(int cooperativeId, string body)
        {
            var u = _session.RequireRole(UserRole.Consumer);
            string text = (body ?? "").Trim();
            if (text.Length == 0) throw new BusinessException("Please type a message first.");
            if (text.Length > MaxMessageLength) throw new BusinessException("Please keep your message under " + MaxMessageLength + " characters.");
            _repo.AddMessage(u.UserId, cooperativeId, text);
        }

        public List<CoopMessage> GetInbox() { return _repo.GetInbox(_session.RequireCooperativeId()); }
        public void MarkRead(int messageId) { _repo.MarkRead(_session.RequireCooperativeId(), messageId); }
        public int UnreadCount() { return _repo.UnreadCount(_session.RequireCooperativeId()); }

        // ----- reviews -----
        public List<Review> GetReviews(int productId) { _session.RequireLogin(); return _repo.GetReviews(productId); }

        /// <summary>Only a consumer who has received this product can review it.</summary>
        public bool CanReview(int productId)
        {
            var u = _session.CurrentUser;
            return u != null && u.Role == UserRole.Consumer && _repo.HasDeliveredOrder(u.UserId, productId);
        }

        public void SubmitReview(int productId, int rating, string comment)
        {
            var u = _session.RequireRole(UserRole.Consumer);
            if (rating < 1 || rating > 5) throw new BusinessException("Please choose 1 to 5 stars.");
            string text = (comment ?? "").Trim();
            if (text.Length > MaxCommentLength) throw new BusinessException("Please keep your review under " + MaxCommentLength + " characters.");
            if (!_repo.HasDeliveredOrder(u.UserId, productId))
                throw new BusinessException("You can review a product after your order with it has been delivered.");
            _repo.SaveReview(new Review { ProductId = productId, UserId = u.UserId, Rating = rating, Comment = text.Length == 0 ? null : text });
        }
    }
}
