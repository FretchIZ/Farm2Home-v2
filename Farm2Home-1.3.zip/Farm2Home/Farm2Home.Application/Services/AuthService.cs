using System;
using System.Collections.Generic;
using System.Linq;
using Farm2Home.Application.Interfaces;
using Farm2Home.Application.Validators;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Application.Services
{
    public class AuthService
    {
        private const int MaxAttempts = 5;
        private static readonly TimeSpan LockoutTime = TimeSpan.FromMinutes(5);

        private class Attempt { public int Count; public DateTime LockedUntil; }

        private readonly IUserRepository _users;
        private readonly IPasswordHasher _hasher;
        private readonly SessionService _session;
        private readonly Dictionary<string, Attempt> _attempts = new Dictionary<string, Attempt>();
        private readonly object _gate = new object();
        private readonly byte[] _dummyHash, _dummySalt;   // used so unknown emails cost the same time as wrong passwords

        public AuthService(IUserRepository users, IPasswordHasher hasher, SessionService session)
        {
            _users = users; _hasher = hasher; _session = session;
            _hasher.Hash("not-a-real-password", out _dummyHash, out _dummySalt);
        }

        /// <param name="accountType">The tab chosen on the sign-in screen; null accepts any account type.</param>
        public SessionUser Login(string email, string password, UserRole? accountType)
        {
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(email)) errors.Add("Email is required.");
            if (string.IsNullOrEmpty(password)) errors.Add("Password is required.");
            if (errors.Any()) throw BusinessException.FromErrors(errors);

            string key = EmailRules.Canonical(email);
            CheckLockout(key);

            var user = _users.GetByEmail(EmailRules.Normalize(email));
            bool ok;
            if (user == null || !user.IsActive)
            {
                _hasher.Verify(password, _dummyHash, _dummySalt);
                ok = false;
            }
            else ok = _hasher.Verify(password, user.PasswordHash, user.PasswordSalt);

            if (!ok) { RegisterFailure(key); throw new BusinessException("Incorrect email or password."); }

            // Password is correct from here on, so it is safe to tell them about a wrong account type.
            if (accountType.HasValue && user.Role != UserRole.Administrator && user.Role != accountType.Value)
                throw new BusinessException("This is a " + user.Role + " account. Please choose the \"" + user.Role + "\" tab to sign in.");

            lock (_gate) _attempts.Remove(key);
            _session.Start(user);
            return _session.CurrentUser;
        }

        public void Logout() { _session.End(); }

        /// <summary>Creates a Consumer account. Cooperative and admin accounts are created by an administrator.</summary>
        /// <returns>True when a new account was created. False when this mailbox already had an account and the same password was
        /// given (a repeated click or resubmission): nothing is created twice and nothing changes - that is what makes it safe to retry.</returns>
        public bool RegisterConsumer(string fullName, string email, string password, string contactNumber)
        {
            var errors = AccountValidator.ValidateRegistration(fullName, email, password, contactNumber);
            if (errors.Any()) throw BusinessException.FromErrors(errors);

            string normalized = EmailRules.Normalize(email);
            var existing = _users.GetByEmail(normalized);
            if (existing != null)
            {
                if (existing.IsActive && existing.Role == UserRole.Consumer && _hasher.Verify(password, existing.PasswordHash, existing.PasswordSalt)) return false;
                throw new BusinessException("An account with this email already exists. Please sign in, or use \"Forgot password?\".");
            }

            byte[] hash, salt;
            _hasher.Hash(password, out hash, out salt);
            _users.Create(new User
            {
                Email = normalized,
                FullName = fullName.Trim(),
                PasswordHash = hash,
                PasswordSalt = salt,
                Role = UserRole.Consumer,
                ContactNumber = string.IsNullOrWhiteSpace(contactNumber) ? null : contactNumber.Trim()
            });
            return true;
        }

        /// <summary>
        /// Forgot-password for an offline app: the person proves who they are with the contact number saved on the account,
        /// then chooses a new password. Failed tries count towards the same lock-out as sign-in.
        /// </summary>
        public void ResetPassword(string email, string contactNumber, string newPassword)
        {
            var emailProblem = EmailRules.Problem(email);
            if (emailProblem != null) throw new BusinessException(emailProblem);
            string key = "reset:" + EmailRules.Canonical(email);
            CheckLockout(key);

            var pwErrors = AccountValidator.ValidatePassword(newPassword);
            if (pwErrors.Any()) throw BusinessException.FromErrors(pwErrors);

            var user = _users.GetByEmail(EmailRules.Normalize(email));
            string given = Digits(contactNumber), saved = user == null ? "" : Digits(user.ContactNumber);
            bool ok = user != null && user.IsActive && given.Length >= 7 && saved.Length >= 7 && given == saved;
            if (!ok)
            {
                RegisterFailure(key);
                throw new BusinessException("We could not verify those details. Check the email and the contact number saved on your account.");
            }

            byte[] hash, salt;
            _hasher.Hash(newPassword, out hash, out salt);
            _users.UpdatePassword(user.UserId, hash, salt);
            lock (_gate) { _attempts.Remove(key); _attempts.Remove(EmailRules.Canonical(email)); }
        }

        private static string Digits(string s) { return new string((s ?? "").Where(char.IsDigit).ToArray()); }

        private void CheckLockout(string key)
        {
            lock (_gate)
            {
                Attempt a;
                if (_attempts.TryGetValue(key, out a) && a.LockedUntil > DateTime.UtcNow)
                {
                    int mins = (int)Math.Ceiling((a.LockedUntil - DateTime.UtcNow).TotalMinutes);
                    throw new BusinessException("Too many failed attempts. Please try again in " + mins + " minute(s).");
                }
            }
        }

        private void RegisterFailure(string key)
        {
            lock (_gate)
            {
                Attempt a;
                if (!_attempts.TryGetValue(key, out a)) { a = new Attempt(); _attempts[key] = a; }
                if (a.LockedUntil <= DateTime.UtcNow && a.LockedUntil != default(DateTime)) { a.Count = 0; a.LockedUntil = default(DateTime); }
                a.Count++;
                if (a.Count >= MaxAttempts) a.LockedUntil = DateTime.UtcNow + LockoutTime;
            }
        }
    }
}
