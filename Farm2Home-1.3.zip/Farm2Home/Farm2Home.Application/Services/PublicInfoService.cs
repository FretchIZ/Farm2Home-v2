using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;

namespace Farm2Home.Application.Services
{
    /// <summary>Totals that are safe to show on the sign-in screen (no personal data, no sign-in needed).</summary>
    public class PublicInfoService
    {
        private readonly ICooperativeRepository _coops;
        public PublicInfoService(ICooperativeRepository coops) { _coops = coops; }
        public PublicStats GetStats() { return _coops.GetPublicStats(); }
    }
}
