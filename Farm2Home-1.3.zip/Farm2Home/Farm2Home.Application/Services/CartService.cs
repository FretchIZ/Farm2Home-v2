using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Application.Services
{
    /// <summary>The signed-in consumer's cart. The user always comes from the session, never from a parameter.</summary>
    public class CartService
    {
        private readonly ICartRepository _cart;
        private readonly IProductRepository _products;
        private readonly SessionService _session;

        public CartService(ICartRepository cart, IProductRepository products, SessionService session)
        {
            _cart = cart; _products = products; _session = session;
        }

        private int UserId { get { return _session.RequireRole(UserRole.Consumer).UserId; } }

        public CartSummary GetCart() { return new CartSummary { Items = _cart.GetItems(UserId) }; }

        public void Add(int productId, int quantity)
        {
            int userId = UserId;
            if (quantity <= 0) throw new BusinessException("Please enter a valid quantity.");
            var p = _products.GetById(productId);
            if (p == null) throw new BusinessException("This product could not be found.");
            if (!p.InStock) throw new BusinessException(p.ProductName + " is currently unavailable.");

            int existing = _cart.GetQuantity(userId, productId);
            int total = existing + quantity;
            if (total > p.StockQuantity)
            {
                int canAdd = p.StockQuantity - existing;
                if (canAdd <= 0)
                    throw new BusinessException("You already have all " + p.StockQuantity + " available units in your cart.");
                throw new BusinessException("Only " + p.StockQuantity + " units are available. You can add " + canAdd + " more.");
            }
            _cart.SetItem(userId, productId, total);
        }

        public void SetQuantity(int productId, int quantity)
        {
            int userId = UserId;
            if (quantity <= 0) throw new BusinessException("Please enter a valid quantity.");
            var p = _products.GetById(productId);
            if (p == null || !p.InStock) throw new BusinessException("This product is currently unavailable.");
            if (quantity > p.StockQuantity)
                throw new BusinessException("Only " + p.StockQuantity + " units are available.");
            _cart.SetItem(userId, productId, quantity);
        }

        public void Remove(int productId) { _cart.RemoveItem(UserId, productId); }
        public void Clear() { _cart.Clear(UserId); }
    }
}
