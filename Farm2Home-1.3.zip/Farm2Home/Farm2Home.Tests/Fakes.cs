using System;
using System.Collections.Generic;
using System.Linq;
using Farm2Home.Application;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Application.Services;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Security;

namespace Farm2Home.Tests
{
    // In-memory stand-ins for the repositories, so business rules can be tested without a database.

    internal class FakeUsers : IUserRepository
    {
        public readonly List<User> Items = new List<User>();
        public User GetByEmail(string email) { string k = Farm2Home.Application.Validators.EmailRules.Canonical(email); return Items.FirstOrDefault(u => Farm2Home.Application.Validators.EmailRules.Canonical(u.Email) == k); }
        public int Create(User user)
        {
            if (GetByEmail(user.Email) != null) throw new BusinessException("An account with this email already exists.");
            user.UserId = Items.Count + 1; user.IsActive = true; Items.Add(user); return user.UserId;
        }
        public int CountUsers() { return Items.Count; }
        public void UpdatePassword(int userId, byte[] hash, byte[] salt) { var u = Items.First(x => x.UserId == userId); u.PasswordHash = hash; u.PasswordSalt = salt; }
    }

    internal class FakeProducts : IProductRepository
    {
        public readonly List<Product> Items = new List<Product>();
        public List<Product> Search(ProductFilter f)
        {
            IEnumerable<Product> q = Items.Where(p => !p.IsDeletedFlag());
            if (!string.IsNullOrWhiteSpace(f.Search)) q = q.Where(p => p.ProductName.IndexOf(f.Search, StringComparison.OrdinalIgnoreCase) >= 0);
            if (f.CooperativeId.HasValue) q = q.Where(p => p.CooperativeId == f.CooperativeId.Value);
            if (f.InStockOnly) q = q.Where(p => p.InStock);
            return q.ToList();
        }
        public List<Product> GetByCooperative(int id) { return Items.Where(p => p.CooperativeId == id).ToList(); }
        public Product GetById(int id) { return Items.FirstOrDefault(p => p.ProductId == id); }
        public int Add(int coopId, ProductInput i)
        {
            int id = Items.Count == 0 ? 1 : Items.Max(p => p.ProductId) + 1;
            Items.Add(new Product { ProductId = id, CooperativeId = coopId, CategoryId = i.CategoryId, ProductName = i.ProductName, Description = i.Description,
                Price = i.Price, Unit = i.Unit, StockQuantity = i.StockQuantity, IsAvailable = i.IsAvailable, CooperativeName = "Coop " + coopId });
            return id;
        }
        public bool Update(int coopId, ProductInput i)
        {
            var p = Items.FirstOrDefault(x => x.ProductId == i.ProductId && x.CooperativeId == coopId);
            if (p == null) return false;
            p.ProductName = i.ProductName; p.Price = i.Price; p.StockQuantity = i.StockQuantity; p.Unit = i.Unit; return true;
        }
        public bool SoftDelete(int coopId, int id)
        {
            var p = Items.FirstOrDefault(x => x.ProductId == id && x.CooperativeId == coopId);
            if (p == null) return false;
            p.IsAvailable = false; p.Description = "[deleted]"; return true;
        }
        public bool UpdateStock(int coopId, int id, int stock)
        {
            var p = Items.FirstOrDefault(x => x.ProductId == id && x.CooperativeId == coopId);
            if (p == null) return false;
            p.StockQuantity = stock; return true;
        }
    }

    internal static class ProductExt
    {
        public static bool IsDeletedFlag(this Product p) { return p.Description == "[deleted]"; }
    }

    internal class FakeCart : ICartRepository
    {
        private readonly FakeProducts _products;
        public readonly Dictionary<int, Dictionary<int, int>> Carts = new Dictionary<int, Dictionary<int, int>>();
        public FakeCart(FakeProducts products) { _products = products; }
        private Dictionary<int, int> Of(int u) { Dictionary<int, int> d; if (!Carts.TryGetValue(u, out d)) { d = new Dictionary<int, int>(); Carts[u] = d; } return d; }
        public List<CartItem> GetItems(int u) { return Of(u).Select(kv => new CartItem { ProductId = kv.Key, Quantity = kv.Value, Product = _products.GetById(kv.Key) }).ToList(); }
        public int GetQuantity(int u, int p) { int q; return Of(u).TryGetValue(p, out q) ? q : 0; }
        public void SetItem(int u, int p, int q) { Of(u)[p] = q; }
        public void RemoveItem(int u, int p) { Of(u).Remove(p); }
        public void Clear(int u) { Of(u).Clear(); }
    }

    internal class FakeOrders : IOrderRepository
    {
        public readonly List<Order> Items = new List<Order>();
        public int PlaceCalls, CancelCalls;
        public List<Order> PlaceOrders(int userId, CheckoutRequest r, decimal fee) { PlaceCalls++; return new List<Order>(); }
        public Order GetById(int id) { return Items.FirstOrDefault(o => o.OrderId == id); }
        public List<Order> GetByCustomer(int u) { return Items.Where(o => o.CustomerId == u).ToList(); }
        public List<Order> GetByCooperative(int c) { return Items.Where(o => o.CooperativeId == c).ToList(); }
        public void UpdateStatus(int id, OrderStatus s) { GetById(id).OrderStatus = s; }
        public void Cancel(int id) { CancelCalls++; GetById(id).OrderStatus = OrderStatus.Cancelled; }
        public CooperativeStats GetStats(int c) { return new CooperativeStats(); }
        public List<DailySale> GetDailySales(int c, int days) { return new List<DailySale>(); }
    }

    internal class FakeCategories : ICategoryRepository { public List<Category> GetAll() { return new List<Category>(); } }
    internal class FakeCoops : ICooperativeRepository
    {
        public List<Cooperative> GetAll(string s) { return new List<Cooperative>(); }
        public Cooperative GetById(int id) { return null; }
        public bool UpdateProfile(Cooperative c) { return false; }
        public PublicStats GetPublicStats() { return new PublicStats(); }
    }

    /// <summary>A complete service graph over the fakes, with five known accounts.</summary>
    internal class World
    {
        public const string Password = "Passw0rd!x";
        public readonly FakeUsers Users = new FakeUsers();
        public readonly FakeProducts Products = new FakeProducts();
        public readonly FakeCart CartRepo;
        public readonly FakeOrders OrderRepo = new FakeOrders();
        public readonly SessionService Session = new SessionService();
        public readonly AuthService Auth;
        public readonly CatalogService Catalog;
        public readonly CartService Cart;
        public readonly OrderService Orders;
        public readonly ProductManagementService Mgmt;

        public World()
        {
            var hasher = new Pbkdf2PasswordHasher();
            byte[] hash, salt;
            hasher.Hash(Password, out hash, out salt);
            Add("consumer@t.local", UserRole.Consumer, null, hash, salt);       // id 1
            Add("consumer2@t.local", UserRole.Consumer, null, hash, salt);      // id 2
            Add("coopa@t.local", UserRole.Cooperative, 1, hash, salt);          // id 3 -> cooperative 1
            Add("coopb@t.local", UserRole.Cooperative, 2, hash, salt);          // id 4 -> cooperative 2
            Add("admin@t.local", UserRole.Administrator, null, hash, salt);     // id 5

            CartRepo = new FakeCart(Products);
            Auth = new AuthService(Users, hasher, Session);
            Catalog = new CatalogService(Products, new FakeCategories(), new FakeCoops(), Session);
            Cart = new CartService(CartRepo, Products, Session);
            Orders = new OrderService(OrderRepo, Session);
            Mgmt = new ProductManagementService(Products, OrderRepo, Session);

            Products.Items.Add(new Product { ProductId = 1, CooperativeId = 1, ProductName = "Tomatoes", Price = 80m, Unit = "kg", StockQuantity = 5, IsAvailable = true, Description = "fresh tomatoes" });
            Products.Items.Add(new Product { ProductId = 2, CooperativeId = 2, ProductName = "Carrots", Price = 70m, Unit = "kg", StockQuantity = 0, IsAvailable = true, Description = "fresh carrots" });
        }

        private void Add(string email, UserRole role, int? coop, byte[] hash, byte[] salt)
        {
            Users.Create(new User { Email = email, FullName = email, Role = role, CooperativeId = coop, PasswordHash = hash, PasswordSalt = salt });
        }

        public void LoginAs(string email) { Auth.Logout(); Auth.Login(email, Password, null); }
    }
}
