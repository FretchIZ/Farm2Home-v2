using System;
using System.Linq;
using System.Text;
using Farm2Home.Application;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Validators;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Security;

namespace Farm2Home.Tests
{
    /// <summary>Business-rule tests that need no database. They run everywhere.</summary>
    internal static class UnitTests
    {
        private static ProductInput GoodProduct()
        {
            return new ProductInput { ProductName = "Organic Tomatoes", CategoryId = 1, Description = "Sweet organic tomatoes.", Price = 80m, Unit = "kg", StockQuantity = 10 };
        }

        public static void Run()
        {
            T.Group("Database start-up (SQLite)");
            T.Test("scripts are split on GO lines only (GOTO / GOLD are not split)", () =>
            {
                var b = Farm2Home.Infrastructure.Data.SqlScript.SplitBatches("A\nGO\nB\n  go  \nGOTO x\nGO 2\nGOLD");
                T.Eq(4, b.Count, "batch count"); T.True(b[2].StartsWith("GOTO"), "GOTO kept"); T.Eq("GOLD", b[3], "last batch");
            });
            T.Test("Schema.sql and Seed.sql are embedded in the Infrastructure assembly", () =>
            {
                string schema = Farm2Home.Infrastructure.Data.SqlScript.ReadEmbedded(Farm2Home.Infrastructure.Data.DatabaseInitializer.SchemaResource);
                string seed = Farm2Home.Infrastructure.Data.SqlScript.ReadEmbedded(Farm2Home.Infrastructure.Data.DatabaseInitializer.SeedResource);
                foreach (var t in Farm2Home.Infrastructure.Data.DatabaseInitializer.RequiredTables)
                    T.True(schema.Contains("CREATE TABLE IF NOT EXISTS " + t + " "), "Schema.sql has no table " + t);
                T.True(seed.Contains("INTO Products"), "Seed.sql has no products");
            });
            T.Test("the embedded scripts can never destroy data (no DROP / TRUNCATE / DELETE FROM statements)", () =>
            {
                foreach (var res in new[] { Farm2Home.Infrastructure.Data.DatabaseInitializer.SchemaResource, Farm2Home.Infrastructure.Data.DatabaseInitializer.SeedResource })
                {
                    string sql = System.Text.RegularExpressions.Regex.Replace(Farm2Home.Infrastructure.Data.SqlScript.ReadEmbedded(res), @"--.*", "");   // ignore comments
                    foreach (var bad in new[] { @"\bDROP\s+(TABLE|DATABASE|INDEX|COLUMN|CONSTRAINT|VIEW)\b", @"\bTRUNCATE\b", @"\bDELETE\s+FROM\b", @"\bREPLACE\s+INTO\b", @"\bINSERT\s+OR\s+REPLACE\b" })
                        T.True(!System.Text.RegularExpressions.Regex.IsMatch(sql, bad, System.Text.RegularExpressions.RegexOptions.IgnoreCase), res + " matches " + bad);
                }
            });
            T.Test("the database file path is read from the connection string", () =>
            {
                T.Eq(@"C:\x\f.db", Farm2Home.Infrastructure.Configuration.DbConfig.FilePathOf(@"Data Source=C:\x\f.db;Version=3;"), "path");
                T.True(Farm2Home.Infrastructure.Configuration.DbConfig.FilePathOf("nothing here") == null, "no path");
            });
            T.Test("passwords are redacted from anything that is logged", () =>
            {
                string r = Farm2Home.Infrastructure.Data.DatabaseInitializer.Redact("Server=s;Database=d;User ID=u;Password=TopSecret123;");
                T.True(!r.Contains("TopSecret123"), "password visible"); T.True(r.Contains("********"), "no mask");
            });
            T.Test("Describe() shows the exception type and message", () =>
            {
                string d = Farm2Home.Infrastructure.Data.DatabaseInitializer.Describe(new InvalidOperationException("outer", new System.IO.IOException("inner reason")));
                T.True(d.Contains("InvalidOperationException") && d.Contains("outer") && d.Contains("IOException") && d.Contains("inner reason"), d);
            });
            T.Test("friendly messages: missing engine files, no access, damaged file, locked, generic", () =>
            {
                T.True(Farm2Home.Infrastructure.Data.DatabaseInitializer.FriendlyMessage(new Exception("Unable to load DLL 'SQLite.Interop.dll'"), "x").Contains("engine files"), "interop");
                T.True(Farm2Home.Infrastructure.Data.DatabaseInitializer.FriendlyMessage(new UnauthorizedAccessException("denied"), "C:\\x.db").Contains("could not open"), "access");
                T.True(Farm2Home.Infrastructure.Data.DatabaseInitializer.FriendlyMessage(new Exception("file is not a database"), "x").Contains("damaged"), "damaged");
                T.True(Farm2Home.Infrastructure.Data.DatabaseInitializer.FriendlyMessage(new Exception("database is locked"), "x").Contains("in use"), "locked");
                T.True(Farm2Home.Infrastructure.Data.DatabaseInitializer.FriendlyMessage(new Exception("boom"), "x").Contains("could not open or prepare"), "generic");
            });
            T.Test("a missing or empty connection string is reported, not thrown", () =>
            {
                var r = Farm2Home.Infrastructure.Data.DatabaseInitializer.EnsureReady("this is not a connection string");
                T.True(!r.Success && !string.IsNullOrEmpty(r.UserMessage), "should fail cleanly");
            });

            T.Group("Password hashing");
            var hasher = new Pbkdf2PasswordHasher();
            T.Test("hash is never the plain password; hash 32 bytes, salt 32 bytes", () =>
            {
                byte[] h, s; hasher.Hash("Secret123", out h, out s);
                T.Eq(32, h.Length, "hash length"); T.Eq(32, s.Length, "salt length");
                T.True(!h.SequenceEqual(Encoding.UTF8.GetBytes("Secret123")), "hash equals plaintext");
            });
            T.Test("same password gets a different salt and hash each time", () =>
            {
                byte[] h1, s1, h2, s2; hasher.Hash("Secret123", out h1, out s1); hasher.Hash("Secret123", out h2, out s2);
                T.True(!s1.SequenceEqual(s2), "salts equal"); T.True(!h1.SequenceEqual(h2), "hashes equal");
            });
            T.Test("verify accepts the right password and rejects wrong/empty", () =>
            {
                byte[] h, s; hasher.Hash("Secret123", out h, out s);
                T.True(hasher.Verify("Secret123", h, s), "right password rejected");
                T.True(!hasher.Verify("secret123", h, s), "wrong case accepted");
                T.True(!hasher.Verify("", h, s), "empty accepted");
                T.True(!hasher.Verify("Secret123", null, s), "null hash accepted");
            });

            T.Group("Validation");
            T.Test("a valid product passes", () => T.Eq(0, ProductValidator.Validate(GoodProduct()).Count, "errors"));
            T.Test("empty product name rejected", () => { var p = GoodProduct(); p.ProductName = "  "; T.True(ProductValidator.Validate(p).Any(e => e.Contains("name")), "no name error"); });
            T.Test("price must be greater than zero", () => { var p = GoodProduct(); p.Price = 0; T.True(ProductValidator.Validate(p).Any(e => e.Contains("Price")), "no price error"); });
            T.Test("negative price rejected", () => { var p = GoodProduct(); p.Price = -5; T.True(ProductValidator.Validate(p).Count > 0, "accepted"); });
            T.Test("more than 2 decimal places in price rejected", () => { var p = GoodProduct(); p.Price = 85.555m; T.True(ProductValidator.Validate(p).Any(e => e.Contains("decimal")), "accepted"); });
            T.Test("negative stock rejected", () => { var p = GoodProduct(); p.StockQuantity = -1; T.True(ProductValidator.Validate(p).Any(e => e.Contains("Stock")), "accepted"); });
            T.Test("missing category rejected", () => { var p = GoodProduct(); p.CategoryId = 0; T.True(ProductValidator.Validate(p).Any(e => e.Contains("category")), "accepted"); });
            T.Test("missing or unknown unit rejected", () =>
            {
                var p = GoodProduct(); p.Unit = null; T.True(ProductValidator.Validate(p).Any(e => e.Contains("unit")), "null accepted");
                p.Unit = "bucket"; T.True(ProductValidator.Validate(p).Any(e => e.Contains("unit")), "unknown accepted");
            });
            T.Test("description too short / too long rejected", () =>
            {
                var p = GoodProduct(); p.Description = "short"; T.True(ProductValidator.Validate(p).Count > 0, "short accepted");
                p.Description = new string('x', 1001); T.True(ProductValidator.Validate(p).Count > 0, "long accepted");
            });
            T.Test("checkout: missing name/address, bad phone and bad payment method rejected", () =>
            {
                var ok = new CheckoutRequest { CustomerName = "Maria", ContactNumber = "0917 234 5678", DeliveryAddress = "12 Sampaguita St, Quezon City", PaymentMethod = "CashOnDelivery" };
                T.Eq(0, CheckoutValidator.Validate(ok).Count, "valid request errors");
                T.True(CheckoutValidator.Validate(new CheckoutRequest { CustomerName = "", ContactNumber = ok.ContactNumber, DeliveryAddress = ok.DeliveryAddress, PaymentMethod = "CashOnDelivery" }).Count > 0, "empty name accepted");
                T.True(CheckoutValidator.Validate(new CheckoutRequest { CustomerName = "M", ContactNumber = ok.ContactNumber, DeliveryAddress = "", PaymentMethod = "CashOnDelivery" }).Count > 0, "empty address accepted");
                T.True(CheckoutValidator.Validate(new CheckoutRequest { CustomerName = "M", ContactNumber = "abc", DeliveryAddress = ok.DeliveryAddress, PaymentMethod = "CashOnDelivery" }).Count > 0, "bad phone accepted");
                T.True(CheckoutValidator.Validate(new CheckoutRequest { CustomerName = "M", ContactNumber = ok.ContactNumber, DeliveryAddress = ok.DeliveryAddress, PaymentMethod = "Bitcoin" }).Count > 0, "bad payment accepted");
            });
            T.Test("registration: weak passwords and bad emails rejected", () =>
            {
                T.True(AccountValidator.ValidateRegistration("A", "a@b.co", "short1", null).Count > 0, "short accepted");
                T.True(AccountValidator.ValidateRegistration("A", "a@b.co", "onlyletters", null).Count > 0, "no digit accepted");
                T.True(AccountValidator.ValidateRegistration("A", "not-an-email", "Passw0rd!x", null).Count > 0, "bad email accepted");
                T.Eq(0, AccountValidator.ValidateRegistration("A", "a@b.co", "Passw0rd!x", null).Count, "good registration errors");
            });

            T.Group("Authentication");
            T.Test("valid consumer login succeeds and starts a session", () =>
            {
                var w = new World(); var u = w.Auth.Login("consumer@t.local", World.Password, UserRole.Consumer);
                T.Eq(UserRole.Consumer, u.Role, "role"); T.True(w.Session.IsLoggedIn, "no session");
            });
            T.Test("email is case-insensitive and trimmed", () => { var w = new World(); w.Auth.Login("  CONSUMER@T.LOCAL ", World.Password, UserRole.Consumer); });
            T.Test("wrong password rejected with a generic message", () =>
            {
                var w = new World(); T.Throws<BusinessException>(() => w.Auth.Login("consumer@t.local", "wrong-pass1", UserRole.Consumer), "Incorrect email or password");
                T.True(!w.Session.IsLoggedIn, "session started");
            });
            T.Test("unknown email gives the same generic message", () =>
            {
                var w = new World(); T.Throws<BusinessException>(() => w.Auth.Login("nobody@t.local", World.Password, null), "Incorrect email or password");
            });
            T.Test("empty email and empty password rejected with clear messages", () =>
            {
                var w = new World();
                T.Throws<BusinessException>(() => w.Auth.Login("", "", null), "Email is required");
                T.Throws<BusinessException>(() => w.Auth.Login("consumer@t.local", "", null), "Password is required");
            });
            T.Test("wrong account-type tab is refused only after the password is correct", () =>
            {
                var w = new World();
                T.Throws<BusinessException>(() => w.Auth.Login("coopa@t.local", World.Password, UserRole.Consumer), "Cooperative account");
                T.Throws<BusinessException>(() => w.Auth.Login("coopa@t.local", "bad-pass-1", UserRole.Consumer), "Incorrect email or password");
            });
            T.Test("administrator can sign in from either tab", () =>
            {
                var w = new World(); w.Auth.Login("admin@t.local", World.Password, UserRole.Consumer); w.Auth.Logout(); w.Auth.Login("admin@t.local", World.Password, UserRole.Cooperative);
            });
            T.Test("5 wrong passwords lock the account even for the right password", () =>
            {
                var w = new World();
                for (int i = 0; i < 5; i++) T.Throws<BusinessException>(() => w.Auth.Login("consumer@t.local", "wrong-pass" + i, null));
                T.Throws<BusinessException>(() => w.Auth.Login("consumer@t.local", World.Password, null), "Too many failed attempts");
            });
            T.Test("logout clears the session", () => { var w = new World(); w.LoginAs("consumer@t.local"); w.Auth.Logout(); T.True(w.Session.CurrentUser == null, "user still set"); });
            T.Test("registering creates a consumer; duplicate email is refused", () =>
            {
                var w = new World();
                w.Auth.RegisterConsumer("New Person", "new@t.local", "Passw0rd!x", "0917 000 0000");
                T.Eq(UserRole.Consumer, w.Users.GetByEmail("new@t.local").Role, "role");
                T.Throws<BusinessException>(() => w.Auth.RegisterConsumer("Dup", "NEW@t.local", "Different1pass", null), "already exists");
                T.True(w.Users.GetByEmail("new@t.local").PasswordHash.Length == 32, "password not hashed");
            });
            T.Test("registering twice with the same details is idempotent (one account, no error)", () =>
            {
                var w = new World();
                int before = w.Users.Items.Count;
                T.True(w.Auth.RegisterConsumer("Sam Dee", "sam.dee@gmail.com", "Passw0rd!x", null), "first call creates");
                T.True(!w.Auth.RegisterConsumer("Sam Dee", " SAM.DEE@Gmail.com ", "Passw0rd!x", null), "second call is a no-op");
                T.Eq(before + 1, w.Users.Items.Count, "exactly one new account");
            });
            T.Test("Gmail spellings are one mailbox (dots and +tags); other domains keep dots", () =>
            {
                var w = new World();
                w.Auth.RegisterConsumer("Sam Dee", "sam.dee@gmail.com", "Passw0rd!x", null);
                T.Throws<BusinessException>(() => w.Auth.RegisterConsumer("Other", "samdee+shop@gmail.com", "Another1pass", null), "already exists");
                w.Auth.RegisterConsumer("A B", "a.b@example.com", "Passw0rd!x", null);
                w.Auth.RegisterConsumer("AB", "ab@example.com", "Passw0rd!x", null);
                T.Eq("samdee@gmail.com", Farm2Home.Application.Validators.EmailRules.Canonical("Sam.Dee+x@GoogleMail.com"), "canonical");
            });
            T.Test("only real-looking email addresses are accepted", () =>
            {
                foreach (var bad in new[] { "", "plain", "a@b", "a@@b.com", "a b@c.com", "a..b@c.com", ".a@c.com", "a@-c.com", "a@c.c", "a@c.123", "a@gmial.com", "a@gmail.con" })
                    T.Throws<BusinessException>(() => new World().Auth.RegisterConsumer("Name", bad, "Passw0rd!x", null));
                foreach (var good in new[] { "fretchlucero10@gmail.com", "first.last+tag@sub.example.co.ph", "x_y-z@my-domain.org" })
                    T.True(Farm2Home.Application.Validators.EmailRules.IsValid(good), good);
            });

            T.Group("Authorization (services enforce roles)");
            T.Test("nobody signed in: every service is blocked", () =>
            {
                var w = new World();
                T.Throws<BusinessException>(() => w.Catalog.Browse(new ProductFilter()), "sign in");
                T.Throws<BusinessException>(() => w.Cart.GetCart(), "sign in");
                T.Throws<BusinessException>(() => w.Orders.GetMyOrders(), "sign in");
                T.Throws<BusinessException>(() => w.Mgmt.GetListings(), "sign in");
            });
            T.Test("consumer cannot use cooperative management or cooperative order functions", () =>
            {
                var w = new World(); w.LoginAs("consumer@t.local");
                T.Throws<BusinessException>(() => w.Mgmt.GetListings(), "permission");
                T.Throws<BusinessException>(() => w.Mgmt.Save(GoodProduct()), "permission");
                T.Throws<BusinessException>(() => w.Mgmt.Delete(1), "permission");
                T.Throws<BusinessException>(() => w.Orders.GetCooperativeOrders(), "permission");
                T.Throws<BusinessException>(() => w.Orders.UpdateStatus(1, OrderStatus.Confirmed), "permission");
            });
            T.Test("cooperative cannot use the cart or place orders", () =>
            {
                var w = new World(); w.LoginAs("coopa@t.local");
                T.Throws<BusinessException>(() => w.Cart.Add(1, 1), "permission");
                T.Throws<BusinessException>(() => w.Orders.PlaceOrders(new CheckoutRequest()), "permission");
            });
            T.Test("a cooperative cannot edit or delete another cooperative's product", () =>
            {
                var w = new World(); w.LoginAs("coopa@t.local");
                var edit = GoodProduct(); edit.ProductId = 2;     // product 2 belongs to cooperative 2
                T.Throws<BusinessException>(() => w.Mgmt.Save(edit), "not found");
                T.Throws<BusinessException>(() => w.Mgmt.Delete(2), "not found");
                T.Throws<BusinessException>(() => w.Mgmt.UpdateStock(2, 99), "not found");
                T.Throws<BusinessException>(() => w.Mgmt.GetForEdit(2), "not found");
            });
            T.Test("a consumer cannot read another consumer's order", () =>
            {
                var w = new World(); w.OrderRepo.Items.Add(new Order { OrderId = 10, CustomerId = 1, CooperativeId = 1, OrderStatus = OrderStatus.Pending });
                w.LoginAs("consumer2@t.local");
                T.Throws<BusinessException>(() => w.Orders.GetMyOrder(10), "not found");
                T.Throws<BusinessException>(() => w.Orders.CancelMyOrder(10), "not found");
            });

            T.Group("Products");
            T.Test("cooperative can add a product and it appears in the marketplace search", () =>
            {
                var w = new World(); w.LoginAs("coopa@t.local");
                int id = w.Mgmt.Save(GoodProduct());
                w.LoginAs("consumer@t.local");
                T.True(w.Catalog.Browse(new ProductFilter { Search = "Organic Tomatoes" }).Any(p => p.ProductId == id), "not found in search");
            });
            T.Test("invalid product is not saved", () =>
            {
                var w = new World(); w.LoginAs("coopa@t.local"); int before = w.Products.Items.Count;
                var bad = GoodProduct(); bad.Price = 0; bad.StockQuantity = -3;
                T.Throws<BusinessException>(() => w.Mgmt.Save(bad), "Price");
                T.Eq(before, w.Products.Items.Count, "product count");
            });
            T.Test("deleted product disappears from the marketplace", () =>
            {
                var w = new World(); w.LoginAs("coopa@t.local"); w.Mgmt.Delete(1);
                w.LoginAs("consumer@t.local");
                T.True(!w.Catalog.Browse(new ProductFilter()).Any(p => p.ProductId == 1), "still listed");
            });
            T.Test("negative stock update rejected", () => { var w = new World(); w.LoginAs("coopa@t.local"); T.Throws<BusinessException>(() => w.Mgmt.UpdateStock(1, -1), "negative"); });

            T.Group("Cart rules");
            T.Test("invalid quantities rejected (0, negative)", () =>
            {
                var w = new World(); w.LoginAs("consumer@t.local");
                T.Throws<BusinessException>(() => w.Cart.Add(1, 0), "valid quantity");
                T.Throws<BusinessException>(() => w.Cart.Add(1, -2), "valid quantity");
                T.Throws<BusinessException>(() => w.Cart.SetQuantity(1, 0), "valid quantity");
            });
            T.Test("cannot add more than the available stock (and says how many)", () =>
            {
                var w = new World(); w.LoginAs("consumer@t.local");
                T.Throws<BusinessException>(() => w.Cart.Add(1, 6), "Only 5");
                w.Cart.Add(1, 3);
                T.Throws<BusinessException>(() => w.Cart.Add(1, 3), "2 more");
                T.Eq(3, w.Cart.GetCart().Items.Single().Quantity, "cart quantity unchanged");
            });
            T.Test("adding the same product twice accumulates; totals recalculate", () =>
            {
                var w = new World(); w.LoginAs("consumer@t.local"); w.Cart.Add(1, 2); w.Cart.Add(1, 1);
                var c = w.Cart.GetCart(); T.Eq(3, c.ItemCount, "units"); T.Eq(240m, c.Subtotal, "subtotal");
                w.Cart.SetQuantity(1, 5); T.Eq(400m, w.Cart.GetCart().Subtotal, "subtotal after change");
                T.Throws<BusinessException>(() => w.Cart.SetQuantity(1, 6), "Only 5");
            });
            T.Test("out-of-stock product cannot be added", () => { var w = new World(); w.LoginAs("consumer@t.local"); T.Throws<BusinessException>(() => w.Cart.Add(2, 1), "unavailable"); });
            T.Test("unknown product cannot be added", () => { var w = new World(); w.LoginAs("consumer@t.local"); T.Throws<BusinessException>(() => w.Cart.Add(999, 1), "not be found"); });
            T.Test("remove and clear work; carts are per user", () =>
            {
                var w = new World(); w.LoginAs("consumer@t.local"); w.Cart.Add(1, 1); w.Cart.Remove(1); T.Eq(0, w.Cart.GetCart().Items.Count, "after remove");
                w.Cart.Add(1, 1); w.LoginAs("consumer2@t.local"); T.Eq(0, w.Cart.GetCart().Items.Count, "other user's cart");
                w.LoginAs("consumer@t.local"); w.Cart.Clear(); T.Eq(0, w.Cart.GetCart().Items.Count, "after clear");
            });

            T.Group("Checkout and order rules");
            T.Test("invalid checkout details never reach the database", () =>
            {
                var w = new World(); w.LoginAs("consumer@t.local");
                T.Throws<BusinessException>(() => w.Orders.PlaceOrders(new CheckoutRequest { CustomerName = "Maria", ContactNumber = "0917 234 5678", DeliveryAddress = "", PaymentMethod = "CashOnDelivery" }), "address");
                T.Eq(0, w.OrderRepo.PlaceCalls, "repository calls");
            });
            T.Test("cooperative must move an order one step at a time", () =>
            {
                var w = new World(); w.OrderRepo.Items.Add(new Order { OrderId = 10, CustomerId = 1, CooperativeId = 1, OrderStatus = OrderStatus.Pending });
                w.LoginAs("coopa@t.local");
                T.Throws<BusinessException>(() => w.Orders.UpdateStatus(10, OrderStatus.Preparing), "one step");
                w.Orders.UpdateStatus(10, OrderStatus.Confirmed); T.Eq(OrderStatus.Confirmed, w.OrderRepo.GetById(10).OrderStatus, "status");
            });
            T.Test("cooperative cannot touch another cooperative's order", () =>
            {
                var w = new World(); w.OrderRepo.Items.Add(new Order { OrderId = 10, CustomerId = 1, CooperativeId = 1, OrderStatus = OrderStatus.Pending });
                w.LoginAs("coopb@t.local");
                T.Throws<BusinessException>(() => w.Orders.UpdateStatus(10, OrderStatus.Confirmed), "not found");
            });
            T.Test("closed orders cannot be changed; preparing orders cannot be cancelled", () =>
            {
                var w = new World();
                w.OrderRepo.Items.Add(new Order { OrderId = 10, CustomerId = 1, CooperativeId = 1, OrderStatus = OrderStatus.Delivered });
                w.OrderRepo.Items.Add(new Order { OrderId = 11, CustomerId = 1, CooperativeId = 1, OrderStatus = OrderStatus.Preparing });
                w.LoginAs("coopa@t.local");
                T.Throws<BusinessException>(() => w.Orders.UpdateStatus(10, OrderStatus.Cancelled), "closed");
                T.Throws<BusinessException>(() => w.Orders.UpdateStatus(11, OrderStatus.Cancelled), "cannot be cancelled");
                w.LoginAs("consumer@t.local");
                T.Throws<BusinessException>(() => w.Orders.CancelMyOrder(11), "no longer be cancelled");
            });
            T.Test("a pending order can be cancelled by its customer", () =>
            {
                var w = new World(); w.OrderRepo.Items.Add(new Order { OrderId = 10, CustomerId = 1, CooperativeId = 1, OrderStatus = OrderStatus.Pending });
                w.LoginAs("consumer@t.local"); w.Orders.CancelMyOrder(10);
                T.Eq(1, w.OrderRepo.CancelCalls, "cancel calls");
            });
        }
    }
}
