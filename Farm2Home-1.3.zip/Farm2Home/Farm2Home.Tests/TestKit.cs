using System;
using System.Collections.Generic;

namespace Farm2Home.Tests
{
    /// <summary>A tiny test runner (no NuGet packages needed).</summary>
    internal static class T
    {
        public static int Passed, Failed, Skipped;
        public static readonly List<string> Failures = new List<string>();
        private static string _group = "";

        public static void Group(string name) { _group = name; Console.WriteLine(); Console.WriteLine("== " + name + " =="); }

        public static void Test(string name, Action body)
        {
            try { body(); Passed++; Console.WriteLine("  PASS  " + name); }
            catch (Exception ex)
            {
                Failed++;
                string msg = ex.GetType().Name + ": " + ex.Message;
                Failures.Add(_group + " / " + name + " -> " + msg);
                Console.WriteLine("  FAIL  " + name + "\n        " + msg);
            }
        }

        public static void Skip(string name, string reason)
        {
            Skipped++;
            Console.WriteLine("  SKIP  " + name + " (" + reason + ")");
        }

        public static void True(bool condition, string message = "condition was false")
        {
            if (!condition) throw new Exception(message);
        }

        public static void Eq<TV>(TV expected, TV actual, string what = "value")
        {
            if (!object.Equals(expected, actual))
                throw new Exception(what + ": expected <" + expected + "> but got <" + actual + ">");
        }

        /// <summary>Passes only if the action throws TEx (and the message contains 'contains', when given).</summary>
        public static void Throws<TEx>(Action action, string contains = null) where TEx : Exception
        {
            try { action(); }
            catch (Exception ex)
            {
                if (!(ex is TEx)) throw new Exception("expected " + typeof(TEx).Name + " but got " + ex.GetType().Name + ": " + ex.Message);
                if (contains != null && ex.Message.IndexOf(contains, StringComparison.OrdinalIgnoreCase) < 0)
                    throw new Exception("message <" + ex.Message + "> does not contain <" + contains + ">");
                return;
            }
            throw new Exception("expected " + typeof(TEx).Name + " but nothing was thrown");
        }
    }
}
