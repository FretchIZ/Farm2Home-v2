using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Farm2Home.UI;

namespace Farm2Home.Tests
{
    /// <summary>
    /// Colour tests: (1) the brand palette is unchanged except for the documented adjustment,
    /// (2) every text/background and component/background pair used by the UI meets WCAG 2.1 AA,
    /// (3) the pairs that cannot meet it are an explicit, reviewed list of exceptions.
    /// </summary>
    internal static class ContrastTests
    {
        // The colour values from the ORIGINAL design, copied from the first version of Theme.cs. Never edit these.
        private static readonly Dictionary<string, string> Original = new Dictionary<string, string>
        {
            {"Forest","#1F4E3D"},{"ForestHover","#286451"},{"Deep","#17342A"},{"TitleBar","#17342A"},{"IconGreen","#7A9B6A"},
            {"SidebarActive","#35604F"},{"SidebarText","#DCE9E1"},{"Moss","#676B3F"},{"MossLight","#E7EEE2"},{"Marigold","#E8A33D"},
            {"MarigoldHover","#F0B252"},{"MarigoldSoft","#FCEBD2"},{"MarigoldText","#B9761A"},{"OnMarigold","#3A2A0A"},
            {"Background","#F7F3EC"},{"Surface","#FFFFFF"},{"Border","#E8E3D8"},{"BorderStrong","#D6D0C2"},{"Ink","#1F2A24"},
            {"Muted","#5F6B62"},{"Danger","#B3312B"},{"DangerSoft","#F8E1DF"},{"Info","#2F4B9C"},{"InfoSoft","#E1E8F8"},{"Disabled","#E6E2D8"},
            {"NeutralBadge","#ECE8DE"},{"ToggleTrack","#EDEAE0"},{"UnreadTint","#FAF6E8"}
        };

        private sealed class Pair
        {
            public string Fg, Bg, Where; public double Min; public string Exception;
            public Pair(string fg, string bg, double min, string where, string exception = null) { Fg = fg; Bg = bg; Min = min; Where = where; Exception = exception; }
        }

        private static string V(string token) { return Palette.All.ContainsKey(token) ? Palette.All[token] : token; }

        // 4.5 = normal text, 3.0 = large text / icons / outlines and other component parts (WCAG 1.4.3, 1.4.11)
        private static readonly Pair[] Pairs =
        {
            new Pair("Ink","Background",4.5,"body text on page"), new Pair("Ink","Surface",4.5,"body text on card"),
            new Pair("Ink","MossLight",4.5,"text on green tint"), new Pair("Ink","MarigoldSoft",4.5,"text on amber tint"), new Pair("Ink","UnreadTint",4.5,"unread message"),
            new Pair("Muted","Background",4.5,"secondary text on page"), new Pair("Muted","Surface",4.5,"secondary text on card"),
            new Pair("Muted","MossLight",4.5,"secondary on green tint"), new Pair("Muted","MarigoldSoft",4.5,"secondary on amber tint"),
            new Pair("Muted","NeutralBadge",4.5,"neutral badge"), new Pair("Muted","UnreadTint",4.5,"muted on unread"),
            new Pair("Forest","Background",4.5,"links/headings on page"), new Pair("Forest","Surface",4.5,"links on card"), new Pair("Forest","MossLight",4.5,"ghost/selected chip"),
            new Pair("#FFFFFF","Forest",4.5,"primary button"), new Pair("#FFFFFF","ForestHover",4.5,"primary hover"), new Pair("#FFFFFF","Deep",4.5,"primary pressed"),
            new Pair("OnMarigold","Marigold",4.5,"accent button, nav badge, avatar"), new Pair("OnMarigold","MarigoldHover",4.5,"accent hover"),
            new Pair("MarigoldText","Surface",4.5,"accent text on card"), new Pair("MarigoldText","Background",4.5,"accent text on page"),
            new Pair("MarigoldText","MarigoldSoft",4.5,"warning badge / soft button"), new Pair("MarigoldText","UnreadTint",4.5,"New label"),
            new Pair("MarigoldHover","Forest",4.5,"hero eyebrow"),
            new Pair("SidebarText","Forest",4.5,"nav label"), new Pair("SidebarText","SidebarActive",4.5,"nav active"), new Pair("#FFFFFF","SidebarActive",4.5,"nav active label"),
            new Pair("#C8DCD0","Deep",4.5,"title bar buttons"), new Pair("#E1EEE6","Forest",4.5,"sign-in subtitle"), new Pair("#D7E8DE","Forest",4.5,"sign-in figures"), new Pair("#E6F0EA","Forest",4.5,"hero text"),
            new Pair("Danger","DangerSoft",4.5,"error badge"), new Pair("Danger","Surface",4.5,"error text"), new Pair("Info","InfoSoft",4.5,"info badge"),
            new Pair("Moss","MossLight",4.5,"moss badge"), new Pair("#FFFFFF","Danger",4.5,"error toast / danger button"),
            // component parts that must be seen (3:1)
            new Pair("Muted","Surface",3.0,"input outline, empty star, off switch on card (ControlBorder)"), new Pair("Muted","Background",3.0,"input outline on page"),
            new Pair("Forest","Surface",3.0,"focus ring, ticked box, selected segment on card"), new Pair("Forest","Background",3.0,"focus ring on page"),
            new Pair("#FFFFFF","Forest",3.0,"focus ring (inner) on primary button / sidebar"), new Pair("#FFFFFF","SidebarActive",3.0,"sidebar focus ring on active item"),
            new Pair("Forest","Marigold",3.0,"focus ring on accent button"),
            new Pair("MarigoldText","Surface",3.0,"filled star outline"),
            new Pair("Marigold","Forest",3.0,"active nav bar"), new Pair("Danger","Background",3.0,"error outline"),

            // ---- reviewed exceptions: these are expected NOT to reach the ratio ----
            new Pair("Muted","Disabled",4.5,"disabled button label","Inactive component: exempt from WCAG 1.4.3; stays visibly different (grey fill, no hover)."),
            new Pair("Border","Surface",3.0,"card hairline","Decorative container edge; content inside is identified by its own text and borders."),
            new Pair("BorderStrong","Background",3.0,"divider / hover card edge","Decorative divider; not the only cue for any control."),
            new Pair("IconGreen","Background",3.0,"placeholder artwork icon","Decorative placeholder picture; the product name and text label carry the meaning."),
            new Pair("IconGreen","MossLight",3.0,"upload tile icon","Icon sits above a text label that says the same thing."),
            new Pair("Marigold","Surface",3.0,"decorative accent shapes","Decoration only; the '+' glyph on the add chip uses MarigoldText."),
            new Pair("ToggleTrack","Surface",3.0,"segmented-toggle track","Selected segment is outlined in Forest (9.5:1) and every segment has a text label."),
        };

        public static void Run()
        {
            T.Group("Colour accessibility and brand identity");

            T.Test("every original brand colour keeps its original value, except documented adjustments", () =>
            {
                var changed = Original.Where(kv => !string.Equals(kv.Value, Palette.All[kv.Key], StringComparison.OrdinalIgnoreCase)).Select(kv => kv.Key).OrderBy(k => k).ToArray();
                var documented = Palette.Adjustments.Select(a => a.Token).OrderBy(k => k).ToArray();
                T.Eq(string.Join(",", documented), string.Join(",", changed), "changed colours vs documented adjustments");
                T.Eq(Original.Count, Palette.All.Count, "no extra colours were introduced");
            });

            T.Test("the only adjusted colour keeps its hue and stays close to the original", () =>
            {
                foreach (var a in Palette.Adjustments)
                {
                    double h0 = Hue(a.Original), h1 = Hue(a.Adjusted);
                    T.True(Math.Abs(h0 - h1) < 3.0, a.Token + " hue moved too far");
                    T.True(Palette.Luminance(a.Original) - Palette.Luminance(a.Adjusted) < 0.12, a.Token + " changed more than needed");
                    T.True(!string.IsNullOrWhiteSpace(a.Reason), a.Token + " has a documented reason");
                }
                T.True(Palette.Adjustments.Length <= 1, "adjustments stay minimal");
            });

            T.Test("text and component colours meet WCAG 2.1 AA (4.5:1 text, 3:1 components)", () =>
            {
                var failures = Pairs.Where(p => p.Exception == null && Palette.Contrast(V(p.Fg), V(p.Bg)) < p.Min)
                                    .Select(p => p.Fg + " on " + p.Bg + " (" + p.Where + ") = " + Palette.Contrast(V(p.Fg), V(p.Bg)).ToString("0.00", CultureInfo.InvariantCulture) + ", needs " + p.Min).ToArray();
                T.True(failures.Length == 0, string.Join("; ", failures));
            });

            T.Test("documented exceptions are real exceptions and each has a written reason", () =>
            {
                foreach (var p in Pairs.Where(x => x.Exception != null))
                {
                    T.True(p.Exception.Length > 20, p.Where + " needs a written reason");
                    T.True(Palette.Contrast(V(p.Fg), V(p.Bg)) < p.Min, p.Fg + " on " + p.Bg + " now passes; move it out of the exception list");
                }
            });

            T.Test("the original amber text colour did fail, so the adjustment is justified", () =>
            {
                T.True(Palette.Contrast(Palette.MarigoldTextOriginal, Palette.Surface) < 4.5, "original on card");
                T.True(Palette.Contrast(Palette.MarigoldTextOriginal, Palette.MarigoldSoft) < 4.5, "original on tint");
            });

            T.Test("contrast maths matches the WCAG reference values", () =>
            {
                T.True(Math.Abs(Palette.Contrast("#000000", "#FFFFFF") - 21.0) < 0.01, "black on white is 21:1");
                T.True(Math.Abs(Palette.Contrast("#777777", "#FFFFFF") - 4.48) < 0.02, "#777 on white is 4.48:1");
            });
        }

        private static double Hue(string hex)
        {
            string h = hex.TrimStart('#');
            double r = int.Parse(h.Substring(0, 2), NumberStyles.HexNumber) / 255.0, g = int.Parse(h.Substring(2, 2), NumberStyles.HexNumber) / 255.0, b = int.Parse(h.Substring(4, 2), NumberStyles.HexNumber) / 255.0;
            double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b)), d = max - min;
            if (d == 0) return 0;
            double hue = max == r ? ((g - b) / d) % 6 : (max == g ? (b - r) / d + 2 : (r - g) / d + 4);
            hue *= 60; return hue < 0 ? hue + 360 : hue;
        }
    }
}
