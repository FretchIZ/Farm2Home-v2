using System;

namespace Farm2Home.Tests
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            Console.WriteLine("Farm2Home tests");
            ContrastTests.Run();
            UnitTests.Run();
            if (Array.IndexOf(args, "--unit-only") >= 0) T.Skip("SQL Server integration tests", "--unit-only");
            else IntegrationTests.Run();

            Console.WriteLine();
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("Passed: " + T.Passed + "   Failed: " + T.Failed + "   Skipped: " + T.Skipped);
            foreach (var f in T.Failures) Console.WriteLine("  FAILED: " + f);
            return T.Failed == 0 ? 0 : 1;
        }
    }
}
