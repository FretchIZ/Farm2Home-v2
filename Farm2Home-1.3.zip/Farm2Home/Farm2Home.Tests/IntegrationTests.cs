using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using Farm2Home.Application;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Services;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Data;
using Farm2Home.Infrastructure.Repositories;
using Farm2Home.Infrastructure.Security;

namespace Farm2Home.Tests
{
    /// <summary>One user's complete service graph over the real repositories (each has its own session).</summary>
    internal class Env
    {
        public string Email;
        public SessionService Session = new SessionService();
        public AuthService Auth;
        public CatalogService Catalog;
        public CartService Cart;
        public OrderService Orders;
        public ProductManagementService Mgmt;

        public static Env Create(string cs)
        {
            var db = new Db(cs);
            var products = new ProductRepository(db);
            var orders = new OrderRepository(db);
            var e = new Env();
            e.Auth = new AuthService(new UserRepository(db), new Pbkdf2PasswordHasher(), e.Session);
            e.Catalog = new CatalogService(products, new CategoryRepository(db), new CooperativeRepository(db), e.Session);
            e.Cart = new CartService(new CartRepository(db), products, e.Session);
            e.Orders = new OrderService(orders, e.Session);
            e.Mgmt = new ProductManagementService(products, orders, e.Session);
            return e;
        }
    }

    /// <summary>Tests against a real SQLite database file (a temporary file, created fresh and deleted afterwards).</summary>
    internal static class IntegrationTests
    {
        private static string _path, _cs;
        private static Db _db;
        private static int _counter;
        private static byte[] _hash, _salt;

        private static CheckoutRequest Req()
        {
            return new CheckoutRequest { CustomerName = "Test Buyer", ContactNumber = "0917 234 5678", DeliveryAddress = "Blk 4 Lot 12, Sampaguita St., Holy Spirit, Quezon City", PaymentMethod = "CashOnDelivery" };
        }

        // ---------------- setup helpers ----------------
        private static void DeleteFiles()
        {
            foreach (var suffix in new[] { "", "-wal", "-shm", "-journal" })
                try { if (File.Exists(_path + suffix)) File.Delete(_path + suffix); } catch { }
        }

        private static string MakeUser(string email, UserRole role, int? coopId)
        {
            new UserRepository(_db).Create(new User { Email = email, FullName = email, Role = role, CooperativeId = coopId, PasswordHash = _hash, PasswordSalt = _salt });
            return email;
        }

        private static Env LoginAs(string email)
        {
            var e = Env.Create(_cs); e.Email = email; e.Auth.Login(email, World.Password, null); return e;
        }

        private static Env NewConsumer() { return LoginAs(MakeUser("c" + (++_counter) + "@t.local", UserRole.Consumer, null)); }
        private static Env Coop1() { return LoginAs("coop1@t.local"); }
        private static Env Coop2() { return LoginAs("coop2@t.local"); }

        private static int NewProduct(Env coop, string name, decimal price, int stock)
        {
            return coop.Mgmt.Save(new ProductInput { ProductName = name, CategoryId = 1, Description = "Test product description", Price = price, Unit = "kg", StockQuantity = stock });
        }

        private static int Stock(int productId) { return _db.Scalar<int>("SELECT StockQuantity FROM Products WHERE ProductId=@i", Db.P("@i", productId)); }
        private static int Count(string sql, params DbParameter[] ps) { return _db.Scalar<int>(sql, ps); }
        private static int OrdersFor(string email) { return Count("SELECT COUNT(*) FROM Orders o JOIN Users u ON u.UserId=o.CustomerId WHERE u.Email=@e", Db.P("@e", email)); }

        // ---------------- the tests ----------------
        public static void Run()
        {
            _path = Path.Combine(Path.GetTempPath(), "farm2home_test_" + Guid.NewGuid().ToString("N") + ".db");
            _cs = "Data Source=" + _path + ";Version=3;";

            T.Group("SQLite integration (" + _path + ")");
            var setup = DatabaseInitializer.EnsureReady(_cs);
            if (!setup.Success)
            {
                T.Failed++;
                T.Failures.Add("SQLite integration / setup -> " + setup.UserMessage + " | " + setup.Technical);
                Console.WriteLine("  FAIL  database setup: " + setup.Technical);
                return;
            }
            try { RunAll(); } finally { DeleteFiles(); }
        }

        private static void RunAll()
        {
            _db = new Db(_cs);
            new Pbkdf2PasswordHasher().Hash(World.Password, out _hash, out _salt);
            MakeUser("coop1@t.local", UserRole.Cooperative, 1);
            MakeUser("coop2@t.local", UserRole.Cooperative, 2);

            T.Test("schema and seed data are in place (3 cooperatives, 5 categories, 10 products)", () =>
            {
                T.Eq(3, Count("SELECT COUNT(*) FROM Cooperatives"), "cooperatives");
                T.Eq(5, Count("SELECT COUNT(*) FROM Categories"), "categories");
                T.Eq(10, Count("SELECT COUNT(*) FROM Products"), "products");
            });
            T.Test("schema and seed scripts can be run again without errors or duplicate data", () =>
            {
                _db.Execute(SqlScript.ReadEmbedded(DatabaseInitializer.SchemaResource));
                _db.Execute(SqlScript.ReadEmbedded(DatabaseInitializer.SeedResource));
                T.Eq(3, Count("SELECT COUNT(*) FROM Cooperatives"), "cooperatives"); T.Eq(10, Count("SELECT COUNT(*) FROM Products"), "products");
                T.Eq(3, Count("SELECT COUNT(*) FROM Roles"), "roles"); T.Eq(5, Count("SELECT COUNT(*) FROM Categories"), "categories");
            });
            T.Test("passwords are stored only as hash + salt (no plaintext column)", () =>
            {
                T.Eq(0, Count("SELECT COUNT(*) FROM pragma_table_info('Users') WHERE name='Password'"), "plaintext column");
                T.Eq(32, Count("SELECT length(PasswordHash) FROM Users WHERE Email='coop1@t.local'"), "hash bytes");
                T.Eq(32, Count("SELECT length(PasswordSalt) FROM Users WHERE Email='coop1@t.local'"), "salt bytes");
            });
            T.Test("database CHECK constraints reject negative stock and zero price", () =>
            {
                T.Throws<DbException>(() => _db.Execute("INSERT INTO Products (CooperativeId,CategoryId,ProductName,Description,Price,Unit,StockQuantity) VALUES (1,1,'x','desc desc desc',5,'kg',-1)"));
                T.Throws<DbException>(() => _db.Execute("INSERT INTO Products (CooperativeId,CategoryId,ProductName,Description,Price,Unit,StockQuantity) VALUES (1,1,'x','desc desc desc',0,'kg',1)"));
            });

            // ----- search / filter / sort -----
            T.Test("search by product name, cooperative name and category name", () =>
            {
                var c = NewConsumer();
                T.True(c.Catalog.Browse(new ProductFilter { Search = "Tomatoes" }).Any(p => p.ProductName == "Organic Tomatoes"), "by product");
                var byCoop = c.Catalog.Browse(new ProductFilter { Search = "Benguet" });
                T.True(byCoop.Count > 0 && byCoop.All(p => p.CooperativeId == 1), "by cooperative");
                var byCat = c.Catalog.Browse(new ProductFilter { Search = "Fruits" });
                T.True(byCat.Count > 0 && byCat.All(p => p.CategoryName == "Fruits"), "by category");
            });
            T.Test("category, cooperative, price-range and in-stock filters change the results", () =>
            {
                var c = NewConsumer();
                T.True(c.Catalog.Browse(new ProductFilter { CategoryId = 2 }).All(p => p.CategoryId == 2), "category");
                T.True(c.Catalog.Browse(new ProductFilter { CooperativeId = 3 }).All(p => p.CooperativeId == 3), "cooperative");
                var priced = c.Catalog.Browse(new ProductFilter { MinPrice = 50, MaxPrice = 60 });
                T.True(priced.Count > 0 && priced.All(p => p.Price >= 50 && p.Price <= 60), "price range");
                var coop = Coop1(); NewProduct(coop, "ZZ Sold Out", 10m, 0);
                T.True(c.Catalog.Browse(new ProductFilter { Search = "ZZ Sold Out" }).Count == 1, "listed when out of stock");
                T.True(c.Catalog.Browse(new ProductFilter { Search = "ZZ Sold Out", InStockOnly = true }).Count == 0, "in-stock filter");
            });
            T.Test("sorting: price low-high, price high-low, name A-Z", () =>
            {
                var c = NewConsumer();
                var asc = c.Catalog.Browse(new ProductFilter { Sort = ProductSort.PriceLowToHigh }).Select(p => p.Price).ToList();
                T.True(asc.SequenceEqual(asc.OrderBy(x => x)), "ascending");
                var desc = c.Catalog.Browse(new ProductFilter { Sort = ProductSort.PriceHighToLow }).Select(p => p.Price).ToList();
                T.True(desc.SequenceEqual(desc.OrderByDescending(x => x)), "descending");
                var names = c.Catalog.Browse(new ProductFilter { Sort = ProductSort.NameAToZ }).Select(p => p.ProductName).ToList();
                T.True(names.SequenceEqual(names.OrderBy(x => x, StringComparer.OrdinalIgnoreCase)), "name");
            });
            T.Test("SQL-injection style searches return nothing and damage nothing", () =>
            {
                var c = NewConsumer(); int before = Count("SELECT COUNT(*) FROM Products");
                foreach (var s in new[] { "' OR 1=1 --", "'; DROP TABLE Products; --", "%", "_", "[a-z]", "\\" })
                    T.Eq(0, c.Catalog.Browse(new ProductFilter { Search = s }).Count, "results for <" + s + ">");
                T.Eq(before, Count("SELECT COUNT(*) FROM Products"), "product count");
            });

            // ----- cart -----
            T.Test("cart persists across a fresh login (survives restart)", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Cart Persist", 20m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 2);
                var again = LoginAs(c.Email);
                T.Eq(2, again.Cart.GetCart().Items.Single(i => i.ProductId == pid).Quantity, "quantity");
            });
            T.Test("cart rejects invalid quantities and more than the stock", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Cart Limits", 20m, 4);
                var c = NewConsumer();
                T.Throws<BusinessException>(() => c.Cart.Add(pid, 0), "valid quantity");
                T.Throws<BusinessException>(() => c.Cart.Add(pid, 5), "Only 4");
                c.Cart.Add(pid, 4);
                T.Throws<BusinessException>(() => c.Cart.Add(pid, 1), "all 4");
            });

            // ----- checkout -----
            T.Test("successful checkout: order saved, price snapshot, stock reduced, cart cleared, order number format", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Checkout", 80m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 3);
                var orders = c.Orders.PlaceOrders(Req());
                T.Eq(1, orders.Count, "orders");
                var o = orders[0];
                T.True(Regex.IsMatch(o.OrderNumber, @"^FH-\d{4}-\d{6}$"), "order number " + o.OrderNumber);
                T.Eq("Unpaid", o.PaymentStatus, "payment status"); T.Eq(OrderStatus.Pending, o.OrderStatus, "order status");
                T.Eq(240m, o.Subtotal, "subtotal"); T.Eq(60m, o.DeliveryFee, "delivery fee"); T.Eq(300m, o.Total, "total");
                T.Eq(80m, o.Items.Single().UnitPrice, "unit price"); T.Eq(7, Stock(pid), "stock");
                T.Eq(0, c.Cart.GetCart().Items.Count, "cart items");
                T.Eq(1, Count("SELECT COUNT(*) FROM Deliveries WHERE OrderId=@i", Db.P("@i", o.OrderId)), "delivery row");
            });
            T.Test("orders survive a restart (read back through a brand-new service graph)", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Persist Order", 30m, 5);
                var c = NewConsumer(); c.Cart.Add(pid, 1); var placed = c.Orders.PlaceOrders(Req())[0];
                var again = LoginAs(c.Email); var o = again.Orders.GetMyOrder(placed.OrderId);
                T.Eq(placed.OrderNumber, o.OrderNumber, "order number"); T.Eq("Test Buyer", o.CustomerName, "customer"); T.Eq(1, o.Items.Count, "items");
            });
            T.Test("a cart with two cooperatives becomes two orders", () =>
            {
                int p1 = NewProduct(Coop1(), "ZZ Multi A", 10m, 5), p2 = NewProduct(Coop2(), "ZZ Multi B", 20m, 5);
                var c = NewConsumer(); c.Cart.Add(p1, 1); c.Cart.Add(p2, 2);
                var orders = c.Orders.PlaceOrders(Req());
                T.Eq(2, orders.Count, "orders"); T.Eq(2, orders.Select(o => o.CooperativeId).Distinct().Count(), "cooperatives");
                T.Eq(120m, orders.Sum(o => o.DeliveryFee), "delivery fees");
            });
            T.Test("missing address / invalid phone: nothing is created", () =>
            {
                int pid = NewProduct(Coop1(), "ZZ Bad Checkout", 10m, 5);
                var c = NewConsumer(); c.Cart.Add(pid, 1);
                var bad = Req(); bad.DeliveryAddress = "";
                T.Throws<BusinessException>(() => c.Orders.PlaceOrders(bad), "address");
                bad = Req(); bad.ContactNumber = "abc";
                T.Throws<BusinessException>(() => c.Orders.PlaceOrders(bad), "contact");
                T.Eq(0, OrdersFor(c.Email), "orders"); T.Eq(5, Stock(pid), "stock"); T.Eq(1, c.Cart.GetCart().Items.Count, "cart intact");
            });
            T.Test("empty cart cannot be checked out", () =>
            {
                var c = NewConsumer(); T.Throws<BusinessException>(() => c.Orders.PlaceOrders(Req()), "empty");
            });
            T.Test("stock changed after adding to cart: checkout is refused, nothing changes", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Stock Race", 10m, 5);
                var c = NewConsumer(); c.Cart.Add(pid, 5);
                coop.Mgmt.UpdateStock(pid, 2);
                T.Throws<BusinessException>(() => c.Orders.PlaceOrders(Req()), "Insufficient stock");
                T.Eq(0, OrdersFor(c.Email), "orders"); T.Eq(2, Stock(pid), "stock"); T.Eq(1, c.Cart.GetCart().Items.Count, "cart intact");
            });
            T.Test("TRANSACTION ROLLBACK: a failure in the middle of checkout leaves no partial order, stock or cart change", () =>
            {
                var coop = Coop1(); int p1 = NewProduct(coop, "ZZ Rollback A", 10m, 5), p2 = NewProduct(coop, "ZZ Rollback B", 10m, 5);
                var c = NewConsumer(); c.Cart.Add(p1, 2); c.Cart.Add(p2, 2);
                int ordersBefore = Count("SELECT COUNT(*) FROM Orders");
                _db.Execute("CREATE TRIGGER trg_test_fail BEFORE INSERT ON OrderItems WHEN NEW.ProductId = " + p2 + " BEGIN SELECT RAISE(ABORT, 'simulated failure'); END");
                try
                {
                    T.Throws<DbException>(() => c.Orders.PlaceOrders(Req()), "simulated failure");
                }
                finally { _db.Execute("DROP TRIGGER trg_test_fail"); }
                T.Eq(ordersBefore, Count("SELECT COUNT(*) FROM Orders"), "orders after rollback");
                T.Eq(5, Stock(p1), "stock A"); T.Eq(5, Stock(p2), "stock B");
                T.Eq(2, c.Cart.GetCart().Items.Count, "cart intact");
                T.Eq(0, Count("SELECT COUNT(*) FROM OrderItems WHERE ProductId IN (" + p1 + "," + p2 + ")"), "order items");
                c.Orders.PlaceOrders(Req());   // and checkout works again afterwards
            });
            T.Test("two buyers race for the last unit: exactly one wins, stock never goes negative", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Last Unit", 10m, 1);
                var a = NewConsumer(); var b = NewConsumer(); a.Cart.Add(pid, 1); b.Cart.Add(pid, 1);
                int wins = 0; var gate = new ManualResetEvent(false);
                Action<Env> go = e =>
                {
                    gate.WaitOne();
                    try { e.Orders.PlaceOrders(Req()); Interlocked.Increment(ref wins); } catch (BusinessException) { }
                };
                var t1 = new Thread(() => go(a)); var t2 = new Thread(() => go(b));
                t1.Start(); t2.Start(); gate.Set(); t1.Join(); t2.Join();
                T.Eq(1, wins, "successful orders"); T.Eq(0, Stock(pid), "stock");
                T.Eq(1, Count("SELECT COUNT(*) FROM OrderItems WHERE ProductId=@p", Db.P("@p", pid)), "order items");
            });

            // ----- history & status -----
            T.Test("order keeps the price paid even after the listing price changes", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Price History", 80m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 1); var o = c.Orders.PlaceOrders(Req())[0];
                var edit = coop.Mgmt.GetForEdit(pid);
                coop.Mgmt.Save(new ProductInput { ProductId = pid, ProductName = edit.ProductName, CategoryId = edit.CategoryId, Description = edit.Description, Price = 120m, Unit = edit.Unit, StockQuantity = Stock(pid) });
                T.Eq(80m, c.Orders.GetMyOrder(o.OrderId).Items.Single().UnitPrice, "unit price in history");
                T.Eq(80m, c.Orders.GetMyOrder(o.OrderId).Total - 60m, "total");
            });
            T.Test("deleting a listing keeps old orders readable and hides it from the marketplace", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Delete Me", 15m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 1); var o = c.Orders.PlaceOrders(Req())[0];
                coop.Mgmt.Delete(pid);
                T.Eq(0, c.Catalog.Browse(new ProductFilter { Search = "ZZ Delete Me" }).Count, "still listed");
                T.Eq("ZZ Delete Me", c.Orders.GetMyOrder(o.OrderId).Items.Single().ProductName, "history");
            });
            T.Test("a product removed while in a cart is shown as unavailable, blocks checkout, and can be removed", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Vanishing", 15m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 1); coop.Mgmt.Delete(pid);
                var line = c.Cart.GetCart().Items.Single();
                T.True(!line.Product.InStock, "should be unavailable");
                T.Throws<BusinessException>(() => c.Orders.PlaceOrders(Req()), "no longer available");
                c.Cart.Remove(pid); T.Eq(0, c.Cart.GetCart().Items.Count, "cart after remove");
            });
            T.Test("customer can cancel a pending order and the stock comes back", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Cancel", 10m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 3); var o = c.Orders.PlaceOrders(Req())[0];
                T.Eq(7, Stock(pid), "stock after order");
                c.Orders.CancelMyOrder(o.OrderId);
                var after = c.Orders.GetMyOrder(o.OrderId);
                T.Eq(OrderStatus.Cancelled, after.OrderStatus, "status"); T.Eq("Cancelled", after.PaymentStatus, "payment status"); T.Eq(10, Stock(pid), "stock restored");
                T.Throws<BusinessException>(() => c.Orders.CancelMyOrder(o.OrderId), "no longer be cancelled");
                T.Eq(10, Stock(pid), "stock not restored twice");
            });
            T.Test("order status flows one step at a time to Delivered; COD becomes Paid; wrong users are blocked", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Flow", 10m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 1); var o = c.Orders.PlaceOrders(Req())[0];
                T.Throws<BusinessException>(() => coop.Orders.UpdateStatus(o.OrderId, OrderStatus.Preparing), "one step");
                T.Throws<BusinessException>(() => Coop2().Orders.UpdateStatus(o.OrderId, OrderStatus.Confirmed), "not found");
                T.Throws<BusinessException>(() => c.Orders.UpdateStatus(o.OrderId, OrderStatus.Confirmed), "permission");
                coop.Orders.UpdateStatus(o.OrderId, OrderStatus.Confirmed);
                coop.Orders.UpdateStatus(o.OrderId, OrderStatus.Preparing);
                T.Throws<BusinessException>(() => c.Orders.CancelMyOrder(o.OrderId), "no longer be cancelled");
                coop.Orders.UpdateStatus(o.OrderId, OrderStatus.ReadyForDelivery);
                coop.Orders.UpdateStatus(o.OrderId, OrderStatus.OutForDelivery);
                T.Eq("Unpaid", c.Orders.GetMyOrder(o.OrderId).PaymentStatus, "unpaid before delivery");
                coop.Orders.UpdateStatus(o.OrderId, OrderStatus.Delivered);
                var done = c.Orders.GetMyOrder(o.OrderId);
                T.Eq(OrderStatus.Delivered, done.OrderStatus, "status"); T.Eq("Paid", done.PaymentStatus, "payment status");
                T.Throws<BusinessException>(() => coop.Orders.UpdateStatus(o.OrderId, OrderStatus.Confirmed), "closed");
            });
            T.Test("a consumer cannot read another consumer's order", () =>
            {
                int pid = NewProduct(Coop1(), "ZZ Privacy", 10m, 5);
                var a = NewConsumer(); a.Cart.Add(pid, 1); var o = a.Orders.PlaceOrders(Req())[0];
                T.Throws<BusinessException>(() => NewConsumer().Orders.GetMyOrder(o.OrderId), "not found");
            });

            // ----- cooperative -----
            T.Test("cooperative adds a product: it appears in the marketplace; edit and stock update persist", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Coop Add", 55m, 12);
                var c = NewConsumer();
                T.Eq(1, c.Catalog.Browse(new ProductFilter { Search = "ZZ Coop Add" }).Count, "listed");
                coop.Mgmt.Save(new ProductInput { ProductId = pid, ProductName = "ZZ Coop Add v2", CategoryId = 2, Description = "Edited description text", Price = 60m, Unit = "kg", StockQuantity = 12 });
                var p = c.Catalog.GetProduct(pid); T.Eq("ZZ Coop Add v2", p.ProductName, "name"); T.Eq(60m, p.Price, "price"); T.Eq(2, p.CategoryId, "category");
                coop.Mgmt.UpdateStock(pid, 33); T.Eq(33, Stock(pid), "stock");
            });
            T.Test("invalid listings are rejected and not saved", () =>
            {
                var coop = Coop1(); int before = Count("SELECT COUNT(*) FROM Products");
                T.Throws<BusinessException>(() => coop.Mgmt.Save(new ProductInput { ProductName = "", CategoryId = 1, Description = "Valid description", Price = 5m, Unit = "kg", StockQuantity = 1 }), "name");
                T.Throws<BusinessException>(() => coop.Mgmt.Save(new ProductInput { ProductName = "x", CategoryId = 1, Description = "Valid description", Price = 0m, Unit = "kg", StockQuantity = 1 }), "Price");
                T.Throws<BusinessException>(() => coop.Mgmt.Save(new ProductInput { ProductName = "x", CategoryId = 1, Description = "Valid description", Price = 5m, Unit = "kg", StockQuantity = -1 }), "Stock");
                T.Throws<BusinessException>(() => coop.Mgmt.Save(new ProductInput { ProductName = "x", CategoryId = 0, Description = "Valid description", Price = 5m, Unit = "kg", StockQuantity = 1 }), "category");
                T.Eq(before, Count("SELECT COUNT(*) FROM Products"), "product count");
            });
            T.Test("a cooperative cannot change another cooperative's product", () =>
            {
                int pid = NewProduct(Coop1(), "ZZ Not Yours", 10m, 5); var other = Coop2();
                T.Throws<BusinessException>(() => other.Mgmt.Save(new ProductInput { ProductId = pid, ProductName = "Hijacked", CategoryId = 1, Description = "Valid description", Price = 1m, Unit = "kg", StockQuantity = 1 }), "not found");
                T.Throws<BusinessException>(() => other.Mgmt.Delete(pid), "not found");
                T.Throws<BusinessException>(() => other.Mgmt.UpdateStock(pid, 999), "not found");
                T.Eq(5, Stock(pid), "stock"); T.Eq(10m, Coop1().Mgmt.GetForEdit(pid).Price, "price");
            });
            T.Test("dashboard numbers match the database", () =>
            {
                var coop = Coop1(); var s = coop.Mgmt.GetStats();
                T.Eq(Count("SELECT COUNT(*) FROM Products WHERE CooperativeId=1 AND IsDeleted=0"), s.TotalProducts, "total products");
                T.Eq(Count("SELECT COUNT(*) FROM Products WHERE CooperativeId=1 AND IsDeleted=0 AND IsAvailable=1 AND StockQuantity>0"), s.ActiveListings, "active");
                T.Eq(Count("SELECT COUNT(*) FROM Orders WHERE CooperativeId=1 AND OrderStatus=1"), s.PendingOrders, "pending");
                T.Eq(Count("SELECT COUNT(*) FROM Orders WHERE CooperativeId=1 AND OrderStatus=6"), s.CompletedOrders, "completed");
                T.Eq(_db.Scalar<decimal>("SELECT COALESCE(SUM(Total),0) FROM Orders WHERE CooperativeId=1 AND OrderStatus=6"), s.TotalSales, "sales");
            });
            T.Test("cooperative sees only its own orders", () =>
            {
                T.True(Coop1().Orders.GetCooperativeOrders().All(o => o.CooperativeId == 1), "coop1");
                T.True(Coop2().Orders.GetCooperativeOrders().All(o => o.CooperativeId == 2), "coop2");
            });
            T.Test("DatabaseInitializer creates a missing database file + tables + seed, and a second run keeps all data", () =>
            {
                string p2 = Path.Combine(Path.GetTempPath(), "farm2home_init_" + Guid.NewGuid().ToString("N") + ".db");
                string cs2 = "Data Source=" + p2 + ";Version=3;";
                try
                {
                    var first = DatabaseInitializer.EnsureReady(cs2);
                    T.True(first.Success, first.UserMessage + " | " + first.Technical);
                    T.True(first.CreatedDatabase, "should have created the database");
                    T.True(File.Exists(p2), "file exists");
                    var db = new Db(cs2);
                    T.Eq(10, db.Scalar<int>("SELECT COUNT(*) FROM Products"), "products after first run");
                    T.Eq(3, db.Scalar<int>("SELECT COUNT(*) FROM Cooperatives"), "cooperatives after first run");
                    T.Eq(5, db.Scalar<int>("SELECT COUNT(*) FROM Categories"), "categories after first run");
                    db.Execute("INSERT INTO Cooperatives (Name, Location) VALUES ('ZZ Keep Me', 'Nowhere')");
                    db.Execute("DELETE FROM Products WHERE ProductName = 'Organic Tomatoes'");
                    var second = DatabaseInitializer.EnsureReady(cs2);
                    T.True(second.Success && !second.CreatedDatabase, "second run should not recreate");
                    T.Eq(1, db.Scalar<int>("SELECT COUNT(*) FROM Cooperatives WHERE Name='ZZ Keep Me'"), "existing data kept");
                    T.Eq(0, db.Scalar<int>("SELECT COUNT(*) FROM Products WHERE ProductName = 'Organic Tomatoes'"), "seed must not run again on an existing database");
                }
                finally { foreach (var sfx in new[] { "", "-wal", "-shm" }) try { File.Delete(p2 + sfx); } catch { } }
            });
            T.Test("a missing table is added to an existing database without touching its data", () =>
            {
                string p3 = Path.Combine(Path.GetTempPath(), "farm2home_mig_" + Guid.NewGuid().ToString("N") + ".db");
                string cs3 = "Data Source=" + p3 + ";Version=3;";
                try
                {
                    T.True(DatabaseInitializer.EnsureReady(cs3).Success, "first");
                    var db = new Db(cs3);
                    db.Execute("DROP TABLE Deliveries");
                    var r = DatabaseInitializer.EnsureReady(cs3);
                    T.True(r.Success, r.Technical);
                    T.Eq(1, db.Scalar<int>("SELECT COUNT(*) FROM sqlite_master WHERE name='Deliveries'"), "table restored");
                    T.Eq(10, db.Scalar<int>("SELECT COUNT(*) FROM Products"), "data untouched");
                }
                finally { foreach (var sfx in new[] { "", "-wal", "-shm" }) try { File.Delete(p3 + sfx); } catch { } }
            });
            T.Test("a file that is not a database is reported clearly and is never deleted", () =>
            {
                string p4 = Path.Combine(Path.GetTempPath(), "farm2home_bad_" + Guid.NewGuid().ToString("N") + ".db");
                try
                {
                    File.WriteAllText(p4, "this is definitely not a sqlite database file, just text padding padding padding padding padding padding padding");
                    var r = DatabaseInitializer.EnsureReady("Data Source=" + p4 + ";Version=3;");
                    T.True(!r.Success, "should fail");
                    T.True(r.UserMessage.Contains("damaged") || r.UserMessage.Contains("could not open"), r.UserMessage);
                    T.True(File.Exists(p4), "the file must still exist");
                }
                finally { try { File.Delete(p4); } catch { } }
            });

            T.Test("an older database with a different Products table is kept as a backup and a working one is started (the 'no such column: ProductName' crash)", () =>
            {
                string p5 = Path.Combine(Path.GetTempPath(), "farm2home_old_" + Guid.NewGuid().ToString("N") + ".db");
                string cs5 = "Data Source=" + p5 + ";Version=3;";
                string[] backups = new string[0];
                try
                {
                    var old = new Db(cs5);
                    old.Execute("CREATE TABLE Roles (RoleId INTEGER PRIMARY KEY AUTOINCREMENT, RoleName TEXT NOT NULL UNIQUE)");
                    old.Execute("INSERT INTO Roles (RoleName) VALUES ('Consumer')");
                    old.Execute("CREATE TABLE Products (ProductId INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Price NUMERIC NOT NULL)");
                    old.Execute("INSERT INTO Products (Name, Price) VALUES ('Old tomato', 5)");
                    Db.ReleaseFiles();
                    var r = DatabaseInitializer.EnsureReady(cs5);
                    T.True(r.Success, r.UserMessage + " | " + r.Technical);
                    backups = Directory.GetFiles(Path.GetTempPath(), Path.GetFileName(p5) + ".bak-*");
                    T.True(backups.Length == 1, "old file must be kept as a backup, found " + backups.Length);
                    T.Eq(10, new Db(cs5).Scalar<int>("SELECT COUNT(*) FROM Products WHERE ProductName IS NOT NULL"), "fresh seeded products");
                    Db.ReleaseFiles();
                    T.Eq(1, new Db("Data Source=" + backups[0] + ";Version=3;").Scalar<int>("SELECT COUNT(*) FROM Products WHERE Name = 'Old tomato'"), "old data still in the backup");
                }
                finally
                {
                    Db.ReleaseFiles();
                    foreach (var sfx in new[] { "", "-wal", "-shm" }) try { File.Delete(p5 + sfx); } catch { }
                    foreach (var b in backups) foreach (var sfx in new[] { "", "-wal", "-shm" }) try { File.Delete(b + sfx); } catch { }
                }
            });
            T.Test("an older database that only lacks a column gets it added and keeps all its data", () =>
            {
                string p6 = Path.Combine(Path.GetTempPath(), "farm2home_col_" + Guid.NewGuid().ToString("N") + ".db");
                string cs6 = "Data Source=" + p6 + ";Version=3;";
                try
                {
                    T.True(DatabaseInitializer.EnsureReady(cs6).Success, "first");
                    var db = new Db(cs6);
                    db.Execute("DROP INDEX IF EXISTS UX_Users_CanonicalEmail");
                    db.Execute("ALTER TABLE Users DROP COLUMN CanonicalEmail");
                    db.Execute("ALTER TABLE Products DROP COLUMN HarvestInfo");
                    var r = DatabaseInitializer.EnsureReady(cs6);
                    T.True(r.Success, r.UserMessage + " | " + r.Technical);
                    T.Eq(10, db.Scalar<int>("SELECT COUNT(*) FROM Products"), "products kept");
                    db.Execute("SELECT HarvestInfo, 1 FROM Products LIMIT 1");
                    db.Execute("SELECT CanonicalEmail FROM Users LIMIT 1");
                    T.True(Directory.GetFiles(Path.GetTempPath(), Path.GetFileName(p6) + ".bak-*").Length == 0, "no backup needed");
                }
                finally { foreach (var sfx in new[] { "", "-wal", "-shm" }) try { File.Delete(p6 + sfx); } catch { } }
            });
            T.Test("registered accounts persist in SQLite, survive a restart, and registering twice is idempotent", () =>
            {
                string p7 = Path.Combine(Path.GetTempPath(), "farm2home_reg_" + Guid.NewGuid().ToString("N") + ".db");
                string cs7 = "Data Source=" + p7 + ";Version=3;";
                try
                {
                    T.True(DatabaseInitializer.EnsureReady(cs7).Success, "setup");
                    var a = Env.Create(cs7);
                    T.True(a.Auth.RegisterConsumer("Fretch Lucero", "Fretch.Lucero10@Gmail.com", "Passw0rd!x", "0917 555 0199"), "created");
                    T.True(!Env.Create(cs7).Auth.RegisterConsumer("Fretch Lucero", "fretchlucero10@gmail.com", "Passw0rd!x", null), "same mailbox + password: no-op");
                    T.Throws<BusinessException>(() => Env.Create(cs7).Auth.RegisterConsumer("Someone Else", "fretchlucero10+x@gmail.com", "Other1234pass", null), "already exists");
                    var db = new Db(cs7);
                    T.Eq(1, db.Scalar<int>("SELECT COUNT(*) FROM Users WHERE CanonicalEmail = 'fretchlucero10@gmail.com'"), "exactly one row");
                    T.Eq("fretch.lucero10@gmail.com", db.Scalar<string>("SELECT Email FROM Users WHERE CanonicalEmail = 'fretchlucero10@gmail.com'"), "stored lower-case");
                    Db.ReleaseFiles();
                    T.True(DatabaseInitializer.EnsureReady(cs7).Success, "restart");
                    var again = Env.Create(cs7);                              // a new process would start like this
                    again.Auth.Login("fretchlucero10@gmail.com", "Passw0rd!x", UserRole.Consumer);
                    T.Eq("Fretch Lucero", again.Session.CurrentUser.FullName, "signed in after restart");
                }
                finally { foreach (var sfx in new[] { "", "-wal", "-shm" }) try { File.Delete(p7 + sfx); } catch { } }
            });

            // ----- features shown in the wireframes -----
            T.Test("chosen delivery time slot is saved with the order and read back", () =>
            {
                int pid = NewProduct(Coop1(), "ZZ Slot", 10m, 5);
                var c = NewConsumer(); c.Cart.Add(pid, 1);
                var req = Req(); req.DeliverySlot = "Tomorrow, 8\u201310 AM";
                var o = c.Orders.PlaceOrders(req)[0];
                T.Eq("Tomorrow, 8\u201310 AM", LoginAs(c.Email).Orders.GetMyOrder(o.OrderId).Delivery.Notes, "slot");
            });
            T.Test("organic-only filter hides produce from non-certified cooperatives", () =>
            {
                var c = NewConsumer();
                int before = c.Catalog.Browse(new ProductFilter { CooperativeId = 3, OrganicOnly = true }).Count;
                T.True(before > 0, "organic coop has products");
                _db.Execute("UPDATE Cooperatives SET IsOrganicCertified = 0 WHERE CooperativeId = 3");
                try { T.Eq(0, c.Catalog.Browse(new ProductFilter { CooperativeId = 3, OrganicOnly = true }).Count, "after un-certifying"); }
                finally { _db.Execute("UPDATE Cooperatives SET IsOrganicCertified = 1 WHERE CooperativeId = 3"); }
            });
            T.Test("sign-in screen totals match the database (no sign-in needed)", () =>
            {
                var stats = new PublicInfoService(new CooperativeRepository(_db)).GetStats();
                T.Eq(Count("SELECT COUNT(*) FROM Cooperatives WHERE IsActive=1"), stats.Cooperatives, "cooperatives");
                T.Eq(Count("SELECT COUNT(*) FROM Products WHERE IsDeleted=0 AND IsAvailable=1"), stats.Products, "products");
            });
            T.Test("cooperative profile shows established year, member-farmers and hectares from the database", () =>
            {
                var c = NewConsumer().Catalog.GetCooperative(1);
                T.Eq(2004, c.EstablishedYear.GetValueOrDefault(), "established"); T.Eq(212, c.MemberFarmers.GetValueOrDefault(), "members"); T.Eq(340, c.HectaresFarmed.GetValueOrDefault(), "hectares");
            });
            T.Test("weekly sales chart data: 7 days ending today, counts new orders, ignores cancelled ones", () =>
            {
                var coop = Coop2(); int pid = NewProduct(coop, "ZZ Chart", 100m, 10);
                var before = coop.Mgmt.GetWeeklySales();
                T.Eq(7, before.Count, "days"); T.Eq(DateTime.Now.Date, before.Last().Date, "last day is today");
                var c = NewConsumer(); c.Cart.Add(pid, 2); var o = c.Orders.PlaceOrders(Req())[0];     // 200 + 60 delivery
                T.Eq(before.Last().Total + o.Total, coop.Mgmt.GetWeeklySales().Last().Total, "today after order");
                c.Orders.CancelMyOrder(o.OrderId);
                T.Eq(before.Last().Total, coop.Mgmt.GetWeeklySales().Last().Total, "today after cancel");
            });
            T.Test("dashboard: month sales and customers reached match the database", () =>
            {
                var coop = Coop1(); int pid = NewProduct(coop, "ZZ Month", 10m, 10);
                var c = NewConsumer(); c.Cart.Add(pid, 1); c.Orders.PlaceOrders(Req());
                var s = coop.Mgmt.GetStats();
                T.Eq(Count("SELECT COUNT(DISTINCT CustomerId) FROM Orders WHERE CooperativeId=1 AND OrderStatus<>7"), s.CustomersReached, "customers");
                T.True(s.MonthSales >= 70m, "month sales includes the new order");
            });
        }
    }
}
