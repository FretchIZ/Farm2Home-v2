using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Farm2Home.Infrastructure.Configuration;

namespace Farm2Home.Infrastructure.Data
{
    public sealed class DatabaseSetupResult
    {
        public bool Success { get; set; }
        public bool CreatedDatabase { get; set; }
        public string Server { get; set; }           // always "SQLite"
        public string Database { get; set; }         // the database file
        public string UserMessage { get; set; }      // friendly, shown to the user
        public string Technical { get; set; }        // exception type and message (never a password)
        public string Summary { get; set; }          // e.g. "Categories=5, Products=10, Cooperatives=3"
        public long Milliseconds { get; set; }
    }

    /// <summary>Reads the .sql files from inside the assembly. Statements are separated by semicolons; a "GO" line is also understood.</summary>
    public static class SqlScript
    {
        public static List<string> SplitBatches(string script)
        {
            return Regex.Split(script ?? "", @"^\s*GO\s*\d*\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase)
                        .Select(b => b.Trim()).Where(b => b.Length > 0).ToList();
        }

        public static string ReadEmbedded(string logicalName)
        {
            using (var s = typeof(SqlScript).Assembly.GetManifestResourceStream(logicalName))
            {
                if (s == null) throw new FileNotFoundException("Embedded database script not found: " + logicalName);
                using (var r = new StreamReader(s, System.Text.Encoding.UTF8)) return r.ReadToEnd();
            }
        }
    }

    /// <summary>
    /// Makes sure the SQLite database file exists and has every table before the app starts. A new file is created and seeded.
    /// An existing file is only checked (and missing tables added); nothing is ever dropped, truncated or overwritten.
    /// </summary>
    public static class DatabaseInitializer
    {
        public const string SchemaResource = "Farm2Home.Database.Schema.sql";
        public const string SeedResource = "Farm2Home.Database.Seed.sql";

        public static readonly string[] RequiredTables =
            { "Roles", "Cooperatives", "Users", "Categories", "Products", "Carts", "CartItems", "Orders", "OrderItems", "Deliveries",
              "PromoCodes", "Follows", "Messages", "Reviews" };

        public static volatile string LastProgress = "Starting\u2026";

        public static DatabaseSetupResult EnsureReady()
        {
            string cs;
            try { cs = DbConfig.ConfiguredConnectionString; }
            catch (Exception ex)
            {
                new FileLogger().Error(ex, "Reading the connection string failed");
                return new DatabaseSetupResult
                {
                    Server = "SQLite",
                    UserMessage = "Farm2Home could not read its database settings (Farm2Home.exe.config).",
                    Technical = Describe(ex)
                };
            }
            return EnsureReady(cs);
        }

        public static DatabaseSetupResult EnsureReady(string connectionString)
        {
            var result = Prepare(connectionString);
            // Safety net: a file from some older version that the column check could not explain. Keep it as a backup and start fresh.
            if (!result.Success && result.Technical != null &&
                (result.Technical.IndexOf("no such column", StringComparison.OrdinalIgnoreCase) >= 0 ||
                 result.Technical.IndexOf("has no column named", StringComparison.OrdinalIgnoreCase) >= 0))
            {
                string path = DbConfig.FilePathOf(connectionString);
                try
                {
                    string moved = SchemaMigrator.MoveAside(path);
                    if (moved != null)
                    {
                        new FileLogger().Info("Database did not match this version (" + result.Technical + "). Kept as " + moved + " and started a new one.");
                        result = Prepare(connectionString);
                    }
                }
                catch (Exception ex) { new FileLogger().Error(ex, "Could not move the old database aside"); }
            }
            return result;
        }

        private static DatabaseSetupResult Prepare(string connectionString)
        {
            var log = new FileLogger();
            var sw = Stopwatch.StartNew();
            var result = new DatabaseSetupResult { Server = "SQLite" };
            string path = DbConfig.FilePathOf(connectionString);
            result.Database = path;
            try
            {
                if (string.IsNullOrWhiteSpace(path))
                    throw new InvalidOperationException("The connection string has no 'Data Source' file path.");

                string dir = Path.GetDirectoryName(Path.GetFullPath(path));
                if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                string upgradeNote = SchemaMigrator.Upgrade(connectionString, path);      // repairs/keeps an older file; never deletes it
                if (upgradeNote != null) log.Info(upgradeNote);
                bool brandNew = !File.Exists(path) || new FileInfo(path).Length == 0;
                LastProgress = brandNew ? "Creating your local database\u2026" : "Opening your local database\u2026";

                using (var c = Db.Connect(connectionString))
                {
                    TryExec(c, "PRAGMA journal_mode = WAL;");                 // faster, and readers never block the writer

                    {                                                                       // idempotent: IF NOT EXISTS everywhere, a few milliseconds
                        bool complete = false;
                        LastProgress = "Preparing tables\u2026";
                        using (var tx = c.BeginTransaction())
                        {
                            Db.ExecTx(c, tx, SqlScript.ReadEmbedded(SchemaResource));
                            if (Db.ScalarTx<int>(c, tx, "SELECT COUNT(*) FROM Roles") == 0 || (Db.ScalarTx<int>(c, tx, "SELECT COUNT(*) FROM Products") == 0 && Db.ScalarTx<int>(c, tx, "SELECT COUNT(*) FROM Cooperatives") == 0))
                            {
                                LastProgress = "Adding sample produce\u2026";
                                Db.ExecTx(c, tx, SqlScript.ReadEmbedded(SeedResource));
                            }
                            tx.Commit();
                        }
                        result.CreatedDatabase = brandNew;
                        BackfillCanonicalEmails(c);
                    }

                    var missing = RequiredTables.Where(t => !TableExists(c, t)).ToList();
                    if (missing.Count > 0) throw new InvalidOperationException("Tables are still missing after setup: " + string.Join(", ", missing));

                    result.Summary = "Categories=" + Db.ScalarTx<int>(c, null, "SELECT COUNT(*) FROM Categories") +
                                     ", Products=" + Db.ScalarTx<int>(c, null, "SELECT COUNT(*) FROM Products") +
                                     ", Cooperatives=" + Db.ScalarTx<int>(c, null, "SELECT COUNT(*) FROM Cooperatives");
                }

                DbConfig.SetEffective(connectionString);
                result.Success = true;
                sw.Stop();
                result.Milliseconds = sw.ElapsedMilliseconds;
                log.Info("Database ready (" + (result.CreatedDatabase ? "created" : "opened") + ", " + result.Milliseconds + " ms): " + path + " | " + result.Summary);
                LastProgress = "Ready";
            }
            catch (Exception ex)
            {
                sw.Stop();
                result.Milliseconds = sw.ElapsedMilliseconds;
                result.Technical = Describe(ex);
                result.UserMessage = FriendlyMessage(ex, path);
                log.Error(ex, "Database setup failed for " + path + " | " + Redact(connectionString));
            }
            return result;
        }

        /// <summary>Accounts saved by an older version get the same-mailbox key, so Gmail spellings cannot duplicate them.</summary>
        private static void BackfillCanonicalEmails(DbConnection c)
        {
            var rows = Db.QueryTx(c, null, "SELECT UserId, Email FROM Users WHERE CanonicalEmail IS NULL", r => new[] { r.S("UserId"), r.S("Email") });
            foreach (var row in rows)
                try { Db.ExecTx(c, null, "UPDATE Users SET CanonicalEmail = @k WHERE UserId = @id", Db.P("@k", Farm2Home.Application.Validators.EmailRules.Canonical(row[1])), Db.P("@id", int.Parse(row[0]))); }
                catch (DbException) { /* two old accounts that are the same Gmail mailbox: leave the second one as it is */ }
        }

        private static bool TableExists(DbConnection c, string table)
        {
            return Db.ScalarTx<int>(c, null, "SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = @n", Db.P("@n", table)) > 0;
        }

        private static void TryExec(DbConnection c, string sql)
        {
            try { using (var cmd = c.CreateCommand()) { cmd.CommandText = sql; cmd.ExecuteScalar(); } } catch { /* optional tuning only */ }
        }

        public static string Describe(Exception ex)
        {
            var parts = new List<string>();
            for (var e = ex; e != null; e = e.InnerException) parts.Add(e.GetType().Name + ": " + e.Message);
            return string.Join(" -> ", parts);
        }

        public static string Redact(string connectionString)
        {
            return Regex.Replace(connectionString ?? "", @"(Password|Pwd)\s*=\s*[^;]*", "$1=********", RegexOptions.IgnoreCase);
        }

        public static string FriendlyMessage(Exception ex, string path)
        {
            string text = ex == null ? "" : Describe(ex);
            if (text.IndexOf("Unable to load DLL", StringComparison.OrdinalIgnoreCase) >= 0 ||
                text.IndexOf("SQLite.Interop", StringComparison.OrdinalIgnoreCase) >= 0 ||
                text.IndexOf("DllNotFound", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Farm2Home's database engine files are missing next to Farm2Home.exe (x86 and x64 folders with SQLite.Interop.dll).\n" +
                       "Rebuild the solution in Visual Studio so the SQLite package is restored, then start Farm2Home again.";
            if (ex is UnauthorizedAccessException || text.IndexOf("unable to open", StringComparison.OrdinalIgnoreCase) >= 0 ||
                text.IndexOf("access", StringComparison.OrdinalIgnoreCase) >= 0 && text.IndexOf("denied", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Farm2Home could not open its database file:\n" + path + "\nCheck that the folder exists and that you are allowed to write to it.";
            if (text.IndexOf("not a database", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("malformed", StringComparison.OrdinalIgnoreCase) >= 0)
                return "The database file looks damaged:\n" + path + "\nFarm2Home will not delete it. Rename or move that file and start again to get a fresh sample database.";
            if (text.IndexOf("locked", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("busy", StringComparison.OrdinalIgnoreCase) >= 0)
                return "The database is in use by another program. Close other copies of Farm2Home and try again.";
            return "Farm2Home could not open or prepare its database.\nThe technical details were saved to the log file.";
        }
    }
}
