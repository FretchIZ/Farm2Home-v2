using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Globalization;
#if MONO_SQLITE
using SQLiteConnection = Mono.Data.Sqlite.SqliteConnection;
using SQLiteParameter = Mono.Data.Sqlite.SqliteParameter;
#else
using System.Data.SQLite;
#endif

namespace Farm2Home.Infrastructure.Data
{
    /// <summary>Thin ADO.NET helper over SQLite. All values travel as parameters, never string-concatenated.</summary>
    public sealed class Db
    {
        private readonly string _connectionString;
        public Db(string connectionString) { _connectionString = connectionString; }

        /// <summary>Opens a connection with foreign keys on and a busy-wait so two writers never fail instantly.</summary>
        public static DbConnection Connect(string connectionString)
        {
            var c = new SQLiteConnection(connectionString);
            c.Open();
            try
            {
                using (var cmd = c.CreateCommand())
                {
                    cmd.CommandText = "PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 10000;";
                    cmd.ExecuteNonQuery();
                }
            }
            catch { c.Dispose(); throw; }
            return c;
        }

        public DbConnection Open() { return Connect(_connectionString); }

        /// <summary>Lets go of every open handle on the database file so it can be renamed.</summary>
        public static void ReleaseFiles()
        {
#if !MONO_SQLITE
            SQLiteConnection.ClearAllPools();
#endif
            GC.Collect(); GC.WaitForPendingFinalizers();
        }

        public static DbParameter P(string name, object value)
        {
            if (value == null) value = DBNull.Value;
            else if (value is decimal) value = (double)(decimal)value;                 // stored as a number, read back as decimal
            else if (value is DateTime) value = ((DateTime)value).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
            else if (value is bool) value = ((bool)value) ? 1 : 0;
            return new SQLiteParameter(name, value);
        }

        private static DbCommand Cmd(DbConnection c, DbTransaction t, string sql, DbParameter[] ps)
        {
            var cmd = c.CreateCommand();
            cmd.Transaction = t;
            cmd.CommandText = sql;
            cmd.CommandTimeout = 30;
            if (ps != null) foreach (var p in ps) cmd.Parameters.Add(p);
            return cmd;
        }

        // ---- own connection ----
        public List<T> Query<T>(string sql, Func<IDataRecord, T> map, params DbParameter[] ps)
        {
            using (var c = Open()) return QueryTx(c, null, sql, map, ps);
        }

        public T Scalar<T>(string sql, params DbParameter[] ps)
        {
            using (var c = Open()) return ScalarTx<T>(c, null, sql, ps);
        }

        public int Execute(string sql, params DbParameter[] ps)
        {
            using (var c = Open()) return ExecTx(c, null, sql, ps);
        }

        // ---- caller-supplied connection/transaction ----
        public static List<T> QueryTx<T>(DbConnection c, DbTransaction t, string sql, Func<IDataRecord, T> map, params DbParameter[] ps)
        {
            var list = new List<T>();
            using (var cmd = Cmd(c, t, sql, ps))
            using (var r = cmd.ExecuteReader())
                while (r.Read()) list.Add(map(r));
            return list;
        }

        public static T ScalarTx<T>(DbConnection c, DbTransaction t, string sql, params DbParameter[] ps)
        {
            using (var cmd = Cmd(c, t, sql, ps))
            {
                object v = cmd.ExecuteScalar();
                if (v == null || v == DBNull.Value) return default(T);
                return (T)Convert.ChangeType(v, typeof(T), CultureInfo.InvariantCulture);
            }
        }

        public static int ExecTx(DbConnection c, DbTransaction t, string sql, params DbParameter[] ps)
        {
            using (var cmd = Cmd(c, t, sql, ps)) return cmd.ExecuteNonQuery();
        }

        /// <summary>True when the exception is a UNIQUE/PRIMARY KEY violation.</summary>
        public static bool IsUniqueViolation(Exception ex)
        {
            return ex is DbException && ex.Message.IndexOf("UNIQUE", StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }

    /// <summary>Null-safe column readers.</summary>
    public static class Rd
    {
        public static string S(this IDataRecord r, string col)
        {
            int i = r.GetOrdinal(col);
            return r.IsDBNull(i) ? null : Convert.ToString(r.GetValue(i), CultureInfo.InvariantCulture);
        }
        public static int I(this IDataRecord r, string col) { return Convert.ToInt32(r[col], CultureInfo.InvariantCulture); }
        public static int? IN(this IDataRecord r, string col)
        {
            int i = r.GetOrdinal(col);
            return r.IsDBNull(i) ? (int?)null : Convert.ToInt32(r.GetValue(i), CultureInfo.InvariantCulture);
        }
        public static decimal D(this IDataRecord r, string col) { return Convert.ToDecimal(r[col], CultureInfo.InvariantCulture); }
        public static double F(this IDataRecord r, string col) { return Convert.ToDouble(r[col], CultureInfo.InvariantCulture); }
        public static bool B(this IDataRecord r, string col) { return Convert.ToInt64(r[col], CultureInfo.InvariantCulture) != 0; }
        public static DateTime T(this IDataRecord r, string col)
        {
            object v = r[col];
            if (v is DateTime) return (DateTime)v;
            return DateTime.Parse(Convert.ToString(v, CultureInfo.InvariantCulture), CultureInfo.InvariantCulture, DateTimeStyles.None);
        }
    }
}
