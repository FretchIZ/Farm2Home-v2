using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;

namespace Farm2Home.Infrastructure.Data
{
    /// <summary>
    /// Brings an existing database file up to the current schema without losing data.
    /// A throw-away in-memory copy of the current schema is the reference. Missing columns are added in place.
    /// A table that cannot be repaired in place (a required column that has no default) is replaced only when it is empty;
    /// otherwise the whole file is renamed to *.bak-yyyyMMdd-HHmmss (never deleted) and a fresh database is started.
    /// </summary>
    internal static class SchemaMigrator
    {
        private class Col { public string Name, Type, Default; public bool NotNull, Pk; }

        /// <returns>A short note when something was changed (for the log), otherwise null.</returns>
        public static string Upgrade(string connectionString, string path)
        {
            if (!File.Exists(path) || new FileInfo(path).Length == 0) return null;

            Dictionary<string, List<Col>> reference;
            using (var mem = Db.Connect("Data Source=:memory:"))
            {
                Db.ExecTx(mem, null, SqlScript.ReadEmbedded(DatabaseInitializer.SchemaResource));
                reference = ReadAll(mem);
            }

            var notes = new List<string>();
            bool needBackup = false;
            using (var c = Db.Connect(connectionString))
            {
                Db.ExecTx(c, null, "PRAGMA foreign_keys = OFF;");
                var actual = ReadAll(c);
                foreach (var table in reference.Keys)
                {
                    List<Col> have;
                    if (!actual.TryGetValue(table, out have)) continue;             // missing tables are created by the schema script
                    var missing = reference[table].Where(r => !have.Any(h => string.Equals(h.Name, r.Name, StringComparison.OrdinalIgnoreCase))).ToList();
                    if (missing.Count == 0) continue;

                    bool fixable = missing.All(m => !m.Pk && (!m.NotNull || (m.Default != null && IsConstant(m.Default))));
                    if (fixable)
                    {
                        foreach (var m in missing)
                        {
                            string def = m.Default != null && IsConstant(m.Default) ? " DEFAULT " + m.Default : "";
                            string nn = m.NotNull && def.Length > 0 ? " NOT NULL" : "";
                            Db.ExecTx(c, null, "ALTER TABLE \"" + table + "\" ADD COLUMN \"" + m.Name + "\" " + (string.IsNullOrEmpty(m.Type) ? "" : m.Type) + nn + def);
                            notes.Add("added " + table + "." + m.Name);
                        }
                    }
                    else if (Db.ScalarTx<int>(c, null, "SELECT COUNT(*) FROM \"" + table + "\"") == 0)
                    {
                        Db.ExecTx(c, null, "DROP TABLE \"" + table + "\"");              // nothing in it to lose; the schema script recreates it
                        notes.Add("recreated empty table " + table);
                    }
                    else { needBackup = true; notes.Add(table + " is missing " + string.Join(", ", missing.Select(m => m.Name))); }
                }
            }

            if (!needBackup) return notes.Count == 0 ? null : "Upgraded database: " + string.Join("; ", notes);

            string backup = MoveAside(path);
            return "Old database was from an older version of Farm2Home (" + string.Join("; ", notes) + "). It was kept as " + backup + " and a new database was started.";
        }

        /// <summary>Renames the database file (and its -wal/-shm) to *.bak-yyyyMMdd-HHmmss. Nothing is deleted.</summary>
        public static string MoveAside(string path)
        {
            if (!File.Exists(path)) return null;
            Db.ReleaseFiles();
            string backup = path + ".bak-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
            for (int i = 2; File.Exists(backup); i++) backup = path + ".bak-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + i;
            File.Move(path, backup);
            foreach (var ext in new[] { "-wal", "-shm" })
                if (File.Exists(path + ext)) File.Move(path + ext, backup + ext);
            return backup;
        }

        private static bool IsConstant(string d)
        {
            d = d.Trim();
            return !(d.StartsWith("(") || d.IndexOf("datetime", StringComparison.OrdinalIgnoreCase) >= 0 || d.IndexOf("current_", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static Dictionary<string, List<Col>> ReadAll(DbConnection c)
        {
            var result = new Dictionary<string, List<Col>>(StringComparer.OrdinalIgnoreCase);
            var tables = Db.QueryTx(c, null, "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'", r => r.S("name"));
            foreach (var t in tables)
                result[t] = Db.QueryTx(c, null, "PRAGMA table_info(\"" + t + "\")", r => new Col
                {
                    Name = r.S("name"), Type = r.S("type"), NotNull = r.I("notnull") == 1, Default = r.S("dflt_value"), Pk = r.I("pk") > 0
                });
            return result;
        }
    }
}
