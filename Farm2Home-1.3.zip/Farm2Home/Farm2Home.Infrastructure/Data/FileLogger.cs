using System;
using System.IO;
using Farm2Home.Application.Interfaces;

namespace Farm2Home.Infrastructure.Data
{
    /// <summary>Writes technical details to %LocalAppData%\Farm2Home\logs\app.log. Never throws.</summary>
    public class FileLogger : IAppLogger
    {
        private static readonly object Gate = new object();
        private readonly string _path;

        /// <summary>Where technical details are written, e.g. C:\Users\you\AppData\Local\Farm2Home\logs\app.log</summary>
        public static string LogFilePath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Farm2Home", "logs", "app.log"); }
        }

        public FileLogger()
        {
            _path = LogFilePath;
            try { Directory.CreateDirectory(Path.GetDirectoryName(_path)); } catch { }
        }

        public void Info(string message) { Write("INFO ", message); }
        public void Error(Exception ex, string context) { Write("ERROR", context + Environment.NewLine + ex); }

        private void Write(string level, string text)
        {
            try
            {
                lock (Gate)
                    File.AppendAllText(_path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " [" + level + "] " + text + Environment.NewLine);
            }
            catch { /* logging must never crash the app */ }
        }
    }
}
