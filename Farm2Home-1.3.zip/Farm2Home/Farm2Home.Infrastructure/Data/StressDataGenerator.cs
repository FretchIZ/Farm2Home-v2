using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Globalization;
using System.Linq;

namespace Farm2Home.Infrastructure.Data
{
    /// <summary>How much fake data to add. The defaults are many times bigger than a real small marketplace.</summary>
    public sealed class StressProfile
    {
        public int Cooperatives { get; set; } = 60;
        public int ProductsPerCooperative { get; set; } = 40;
        public int Consumers { get; set; } = 400;
        public int Orders { get; set; } = 6000;
        public int Reviews { get; set; } = 8000;
        public int Messages { get; set; } = 600;
        /// <summary>Share of all orders that go to the demo cooperative and the demo consumer, so their screens are the heaviest.</summary>
        public int DemoCooperativeOrderPercent { get; set; } = 35;
        public int DemoConsumerOrderPercent { get; set; } = 4;
    }

    /// <summary>
    /// Fills a database with a LARGE amount of realistic-looking data so page speed can be measured at scale (used by the
    /// self-test and the performance tests). Never used in normal operation. Everything runs in one transaction and uses parameters.
    /// </summary>
    public static class StressDataGenerator
    {
        private static readonly string[] Produce =
        {
            "Tomatoes", "Carrots", "Lettuce", "Spinach", "Eggplant", "Cucumber", "Sweet Potato", "Calamansi", "Bananas", "Corn",
            "Cabbage", "Mango", "Pineapple", "Papaya", "Okra", "String Beans", "Squash", "Ginger", "Garlic", "Onions",
            "Rice", "Cacao Beans", "Coffee Beans", "Coconut", "Pechay", "Radish", "Bitter Gourd", "Pomelo", "Jackfruit", "Taro"
        };
        private static readonly string[] Style = { "Organic", "Fresh", "Native", "Premium", "Highland", "Farm-picked", "Sun-ripened", "Heirloom" };
        private static readonly string[] Units = { "kg", "g", "piece", "bundle", "sack", "dozen", "liter" };
        private static readonly string[] Cities = { "Cebu City", "Davao City", "Quezon City", "Baguio", "Iloilo", "Cagayan de Oro", "Bacolod", "Tagaytay", "Lipa", "Dumaguete" };
        private static readonly string[] First = { "Maria", "Juan", "Ana", "Jose", "Rosa", "Pedro", "Lea", "Carlo", "Mica", "Noel", "Tess", "Ramon" };
        private static readonly string[] Last = { "Santos", "Reyes", "Cruz", "Bautista", "Garcia", "Mendoza", "Torres", "Ramos", "Flores", "Aquino" };

        private static string Ts(DateTime utc) { return utc.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture); }

        /// <returns>A one-line summary such as "added 60 cooperatives, 2400 products, ...".</returns>
        public static string Generate(string connectionString, StressProfile p)
        {
            p = p ?? new StressProfile();
            var sw = Stopwatch.StartNew();
            var rnd = new Random(20260616);
            var now = DateTime.UtcNow;

            using (var c = Db.Connect(connectionString))
            using (var tx = c.BeginTransaction())
            {
                int consumerRole = Db.ScalarTx<int>(c, tx, "SELECT RoleId FROM Roles WHERE RoleName = 'Consumer'");
                var categories = Db.QueryTx(c, tx, "SELECT CategoryId FROM Categories", r => r.I("CategoryId"));
                int demoCoop = Db.ScalarTx<int>(c, tx, "SELECT CooperativeId FROM Users WHERE Email = 'coop@farm2home.local'");
                if (demoCoop == 0) demoCoop = Db.ScalarTx<int>(c, tx, "SELECT MIN(CooperativeId) FROM Cooperatives");
                int demoConsumer = Db.ScalarTx<int>(c, tx, "SELECT UserId FROM Users WHERE Email = 'consumer@farm2home.local'");

                // ---- cooperatives
                var coopIds = new List<int>();
                int baseCoop = Db.ScalarTx<int>(c, tx, "SELECT COALESCE(MAX(CooperativeId), 0) FROM Cooperatives");
                for (int i = 1; i <= p.Cooperatives; i++)
                {
                    int id = Db.ScalarTx<int>(c, tx, @"INSERT INTO Cooperatives (Name, Description, Location, ContactEmail, ContactPhone, IsOrganicCertified, IsActive, EstablishedYear, MemberFarmers, HectaresFarmed)
                        VALUES (@n, @d, @l, @e, @p, @o, 1, @y, @m, @h) RETURNING CooperativeId",
                        Db.P("@n", "Stress Test Growers Coop " + (baseCoop + i)), Db.P("@d", "Generated cooperative number " + i + " for speed testing."),
                        Db.P("@l", "Brgy. " + i + ", " + Cities[i % Cities.Length]), Db.P("@e", "coop" + i + "@stress.test"), Db.P("@p", "0917-000-" + (1000 + i)),
                        Db.P("@o", rnd.Next(100) < 70), Db.P("@y", 1990 + rnd.Next(30)), Db.P("@m", 20 + rnd.Next(300)), Db.P("@h", 10 + rnd.Next(500)));
                    coopIds.Add(id);
                }
                var allCoops = Db.QueryTx(c, tx, "SELECT CooperativeId FROM Cooperatives", r => r.I("CooperativeId"));

                // ---- products (the demo cooperative gets three times as many)
                var productsByCoop = new Dictionary<int, List<int>>();
                var priceByProduct = new Dictionary<int, decimal>();
                var nameByProduct = new Dictionary<int, string>();
                var allProducts = new List<int>();
                int productCounter = 0;
                foreach (int coopId in coopIds.Concat(new[] { demoCoop }))
                {
                    int count = coopId == demoCoop ? p.ProductsPerCooperative * 3 : p.ProductsPerCooperative;
                    var list = productsByCoop.ContainsKey(coopId) ? productsByCoop[coopId] : (productsByCoop[coopId] = new List<int>());
                    for (int i = 0; i < count; i++)
                    {
                        productCounter++;
                        string name = Style[rnd.Next(Style.Length)] + " " + Produce[rnd.Next(Produce.Length)] + " #" + productCounter;
                        decimal price = Math.Round(20m + rnd.Next(0, 38000) / 100m, 2);
                        int stock = rnd.Next(100) < 12 ? 0 : rnd.Next(1, 300);
                        int id = Db.ScalarTx<int>(c, tx, @"INSERT INTO Products (CooperativeId, CategoryId, ProductName, Description, Price, Unit, StockQuantity, IsAvailable, HarvestInfo, CreatedAt)
                            VALUES (@co, @ca, @n, @d, @pr, @u, @s, @a, @h, @t) RETURNING ProductId",
                            Db.P("@co", coopId), Db.P("@ca", categories[rnd.Next(categories.Count)]), Db.P("@n", name),
                            Db.P("@d", "Generated listing used for speed testing. Picked fresh and packed by the cooperative."),
                            Db.P("@pr", price), Db.P("@u", Units[rnd.Next(Units.Length)]), Db.P("@s", stock), Db.P("@a", rnd.Next(100) < 92),
                            Db.P("@h", "Harvested this week"), Db.P("@t", Ts(now.AddMinutes(-rnd.Next(0, 60 * 24 * 90)))));
                        list.Add(id); allProducts.Add(id); priceByProduct[id] = price; nameByProduct[id] = name;
                    }
                }

                // ---- consumers (they cannot sign in: the hash is a placeholder)
                var users = new List<int>();
                byte[] fake = new byte[32];
                for (int i = 1; i <= p.Consumers; i++)
                {
                    string mail = "stress" + i + "@example.test";
                    int uid = Db.ScalarTx<int>(c, tx, @"INSERT INTO Users (Email, CanonicalEmail, FullName, PasswordHash, PasswordSalt, RoleId, ContactNumber, DefaultAddress)
                        VALUES (@e, @e, @n, @h, @h, @r, @p, @a) RETURNING UserId",
                        Db.P("@e", mail), Db.P("@n", First[rnd.Next(First.Length)] + " " + Last[rnd.Next(Last.Length)]), Db.P("@h", fake), Db.P("@r", consumerRole),
                        Db.P("@p", "0917-555-" + (1000 + i)), Db.P("@a", i + " Mabini St., Brgy. Poblacion, " + Cities[i % Cities.Length]));
                    users.Add(uid);
                }
                var buyers = demoConsumer > 0 ? users.Concat(new[] { demoConsumer }).ToList() : users;

                // ---- follows
                foreach (int u in users)
                    for (int k = 0; k < 3; k++)
                        Db.ExecTx(c, tx, "INSERT OR IGNORE INTO Follows (UserId, CooperativeId) VALUES (@u, @c)", Db.P("@u", u), Db.P("@c", allCoops[rnd.Next(allCoops.Count)]));

                // ---- orders + items + deliveries
                int[] weights = { 12, 8, 6, 4, 5, 55, 10 };    // Pending..Cancelled
                for (int n = 0; n < p.Orders; n++)
                {
                    int coopId = rnd.Next(100) < p.DemoCooperativeOrderPercent ? demoCoop : coopIds[rnd.Next(coopIds.Count)];
                    int buyer = (demoConsumer > 0 && rnd.Next(100) < p.DemoConsumerOrderPercent) ? demoConsumer : buyers[rnd.Next(buyers.Count)];
                    var pool = productsByCoop[coopId];
                    int lines = 1 + rnd.Next(4);
                    var chosen = Enumerable.Range(0, lines).Select(_ => pool[rnd.Next(pool.Count)]).Distinct().ToList();
                    decimal sub = 0; var qty = new Dictionary<int, int>();
                    foreach (int pid in chosen) { int q = 1 + rnd.Next(5); qty[pid] = q; sub += priceByProduct[pid] * q; }
                    int status = Pick(rnd, weights) + 1;
                    DateTime when = now.AddMinutes(-rnd.Next(0, 60 * 24 * 120));
                    int orderId = Db.ScalarTx<int>(c, tx, @"INSERT INTO Orders (OrderNumber, CustomerId, CooperativeId, OrderDate, Subtotal, DeliveryFee, Discount, Total, PaymentMethod, PaymentStatus, OrderStatus, CustomerName, DeliveryAddress, ContactNumber)
                        VALUES (@num, @cu, @co, @dt, @sub, 60, 0, @tot, 'CashOnDelivery', @ps, @st, @nm, @ad, @ph) RETURNING OrderId",
                        Db.P("@num", "TMPS" + n), Db.P("@cu", buyer), Db.P("@co", coopId), Db.P("@dt", Ts(when)), Db.P("@sub", sub), Db.P("@tot", sub + 60m),
                        Db.P("@ps", status == 6 ? "Paid" : status == 7 ? "Cancelled" : "Unpaid"), Db.P("@st", status),
                        Db.P("@nm", First[rnd.Next(First.Length)] + " " + Last[rnd.Next(Last.Length)]), Db.P("@ad", n + " Mabini St., Brgy. Poblacion, " + Cities[n % Cities.Length]),
                        Db.P("@ph", "0917-555-" + (1000 + n % 9000)));
                    foreach (int pid in chosen)
                        Db.ExecTx(c, tx, "INSERT INTO OrderItems (OrderId, ProductId, ProductName, Quantity, UnitPrice, Subtotal) VALUES (@o, @p, @n, @q, @u, @s)",
                            Db.P("@o", orderId), Db.P("@p", pid), Db.P("@n", nameByProduct[pid]), Db.P("@q", qty[pid]), Db.P("@u", priceByProduct[pid]), Db.P("@s", priceByProduct[pid] * qty[pid]));
                    Db.ExecTx(c, tx, "INSERT INTO Deliveries (OrderId, Status) VALUES (@o, @s)", Db.P("@o", orderId), Db.P("@s", status));
                }
                Db.ExecTx(c, tx, "UPDATE Orders SET OrderNumber = 'FH-' || strftime('%Y', OrderDate) || '-' || substr('000000' || OrderId, -6) WHERE OrderNumber LIKE 'TMPS%'");

                // ---- reviews (unique per product + person; duplicates are skipped)
                for (int i = 0; i < p.Reviews; i++)
                    Db.ExecTx(c, tx, "INSERT OR IGNORE INTO Reviews (ProductId, UserId, Rating, Comment, CreatedAt) VALUES (@p, @u, @r, @c, @t)",
                        Db.P("@p", allProducts[rnd.Next(allProducts.Count)]), Db.P("@u", buyers[rnd.Next(buyers.Count)]), Db.P("@r", 3 + rnd.Next(3)),
                        Db.P("@c", rnd.Next(100) < 60 ? "Fresh and good value." : null), Db.P("@t", Ts(now.AddMinutes(-rnd.Next(0, 60 * 24 * 100)))));

                // ---- messages to cooperatives (most to the demo cooperative)
                for (int i = 0; i < p.Messages; i++)
                    Db.ExecTx(c, tx, "INSERT INTO Messages (FromUserId, CooperativeId, Body, IsRead, CreatedAt) VALUES (@f, @c, @b, @r, @t)",
                        Db.P("@f", users[rnd.Next(users.Count)]), Db.P("@c", rnd.Next(100) < 60 ? demoCoop : allCoops[rnd.Next(allCoops.Count)]),
                        Db.P("@b", "Hello! Do you still have this in stock for the weekend? Message number " + i + "."), Db.P("@r", rnd.Next(100) < 70), Db.P("@t", Ts(now.AddMinutes(-rnd.Next(0, 60 * 24 * 60)))));

                tx.Commit();
            }
            sw.Stop();
            return "added " + p.Cooperatives + " cooperatives, ~" + (p.Cooperatives * p.ProductsPerCooperative + p.ProductsPerCooperative * 3) + " products, " + p.Consumers + " customers, " +
                   p.Orders + " orders, up to " + p.Reviews + " reviews and " + p.Messages + " messages in " + sw.ElapsedMilliseconds + " ms";
        }

        private static int Pick(Random rnd, int[] weights)
        {
            int roll = rnd.Next(weights.Sum()), acc = 0;
            for (int i = 0; i < weights.Length; i++) { acc += weights[i]; if (roll < acc) return i; }
            return weights.Length - 1;
        }
    }
}
