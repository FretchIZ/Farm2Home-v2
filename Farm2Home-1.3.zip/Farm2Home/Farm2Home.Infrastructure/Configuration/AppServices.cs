using System;
using Farm2Home.Application.Interfaces;
using Farm2Home.Application.Services;
using Farm2Home.Infrastructure.Data;
using Farm2Home.Infrastructure.Repositories;
using Farm2Home.Infrastructure.Security;

namespace Farm2Home.Infrastructure.Configuration
{
    /// <summary>Composition root: wires repositories into services once. The UI only talks to these services.</summary>
    public static class AppServices
    {
        private static bool _ready;

        public static IAppLogger Logger { get; private set; }
        public static SessionService Session { get; private set; }
        public static AuthService Auth { get; private set; }
        public static PublicInfoService PublicInfo { get; private set; }
        public static CatalogService Catalog { get; private set; }
        public static CartService Cart { get; private set; }
        public static OrderService Orders { get; private set; }
        public static ProductManagementService ProductManagement { get; private set; }
        public static EngagementService Engagement { get; private set; }

        public static void Initialize()
        {
            if (_ready) return;

            var db = new Db(DbConfig.ConnectionString);
            var products = new ProductRepository(db);
            var categories = new CategoryRepository(db);
            var coops = new CooperativeRepository(db);
            var cart = new CartRepository(db);
            var orders = new OrderRepository(db);
            var users = new UserRepository(db);
            var engagement = new EngagementRepository(db);
            var hasher = new Pbkdf2PasswordHasher();

            Logger = new FileLogger();
            Session = new SessionService();
            Auth = new AuthService(users, hasher, Session);
            PublicInfo = new PublicInfoService(coops);
            Catalog = new CatalogService(products, categories, coops, Session);
            Cart = new CartService(cart, products, Session);
            Orders = new OrderService(orders, Session);
            ProductManagement = new ProductManagementService(products, orders, Session);
            Engagement = new EngagementService(engagement, Session);

            if (DemoDataSeeder.SeedIfEmpty(users, coops, hasher)) DemoDataSeeder.SeedSampleReviews(users, products, engagement);
            _ready = true;
        }

        /// <summary>Quick startup check so a missing database gives a friendly message instead of a crash.</summary>
        public static bool CanConnect(out string userMessage)
        {
            try
            {
                using (var c = Db.Connect(DbConfig.ConnectionString)) { }
                userMessage = null;
                return true;
            }
            catch (Exception ex)
            {
                new FileLogger().Error(ex, "Database connection check failed: " + DatabaseInitializer.Describe(ex));
                userMessage = "Farm2Home could not reach its database. Please make sure the database has been created, then try again.";
                return false;
            }
        }
    }
}
