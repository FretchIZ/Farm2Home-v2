using System;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;

namespace Farm2Home.Infrastructure.Configuration
{
    public static class DbConfig
    {
        private static string _effective;

        /// <summary>Override for tests or portable installs: set FARM2HOME_DB to a full file path.</summary>
        public const string EnvVariable = "FARM2HOME_DB";

        /// <summary>The connection string as written in App.config. "{LocalAppData}" is replaced by the user's local app-data folder.</summary>
        public static string ConfiguredConnectionString
        {
            get
            {
                string over = Environment.GetEnvironmentVariable(EnvVariable);
                if (!string.IsNullOrWhiteSpace(over)) return "Data Source=" + over + ";Version=3;";

                var cs = ConfigurationManager.ConnectionStrings["Farm2Home"];
                if (cs == null || string.IsNullOrWhiteSpace(cs.ConnectionString))
                    throw new ConfigurationErrorsException("Connection string 'Farm2Home' is missing from Farm2Home.exe.config (App.config).");
                return cs.ConnectionString.Replace("{LocalAppData}",
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
            }
        }

        public static string ConnectionString
        {
            get { return _effective ?? ConfiguredConnectionString; }
        }

        public static void SetEffective(string connectionString) { _effective = connectionString; }

        /// <summary>The database file path inside a connection string, or null if it cannot be found.</summary>
        public static string FilePathOf(string connectionString)
        {
            var m = Regex.Match(connectionString ?? "", @"(?:Data Source|DataSource|Filename)\s*=\s*([^;]+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim().Trim('"') : null;
        }

        public static string DatabasePath { get { return FilePathOf(ConnectionString); } }
    }
}
