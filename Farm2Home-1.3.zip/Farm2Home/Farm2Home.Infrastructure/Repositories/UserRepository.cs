using System;
using System.Data;
using System.Data.Common;
using System.Linq;
using Farm2Home.Application;
using Farm2Home.Application.Interfaces;
using Farm2Home.Application.Validators;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Data;
using static Farm2Home.Infrastructure.Data.Db;

namespace Farm2Home.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly Db _db;
        public UserRepository(Db db) { _db = db; }

        private static User Map(IDataRecord r)
        {
            return new User
            {
                UserId = r.I("UserId"),
                Email = r.S("Email"),
                FullName = r.S("FullName"),
                PasswordHash = (byte[])r["PasswordHash"],
                PasswordSalt = (byte[])r["PasswordSalt"],
                Role = (UserRole)Enum.Parse(typeof(UserRole), r.S("RoleName")),
                CooperativeId = r.IN("CooperativeId"),
                ContactNumber = r.S("ContactNumber"),
                DefaultAddress = r.S("DefaultAddress"),
                IsActive = r.B("IsActive")
            };
        }

        public User GetByEmail(string email)
        {
            return _db.Query(@"
SELECT u.UserId, u.Email, u.FullName, u.PasswordHash, u.PasswordSalt, r.RoleName,
       u.CooperativeId, u.ContactNumber, u.DefaultAddress, u.IsActive
FROM Users u JOIN Roles r ON r.RoleId = u.RoleId
WHERE u.Email = @e OR u.CanonicalEmail = @k
ORDER BY (u.Email = @e) DESC LIMIT 1", Map, P("@e", EmailRules.Normalize(email)), P("@k", EmailRules.Canonical(email))).FirstOrDefault();
        }

        public int Create(User u)
        {
            try
            {
                return _db.Scalar<int>(@"
INSERT INTO Users (Email, CanonicalEmail, FullName, PasswordHash, PasswordSalt, RoleId, CooperativeId, ContactNumber, DefaultAddress)
VALUES (@e, @k, @n, @h, @s, (SELECT RoleId FROM Roles WHERE RoleName = @role), @c, @p, @a)
RETURNING UserId",
                    P("@e", EmailRules.Normalize(u.Email)), P("@k", EmailRules.Canonical(u.Email)), P("@n", u.FullName), P("@h", u.PasswordHash), P("@s", u.PasswordSalt),
                    P("@role", u.Role.ToString()), P("@c", u.CooperativeId), P("@p", u.ContactNumber), P("@a", u.DefaultAddress));
            }
            catch (DbException ex) when (Db.IsUniqueViolation(ex))
            {
                throw new BusinessException("An account with this email already exists.");
            }
        }

        public void UpdatePassword(int userId, byte[] hash, byte[] salt)
        {
            _db.Execute("UPDATE Users SET PasswordHash = @h, PasswordSalt = @s, FailedLogins = 0 WHERE UserId = @id",
                P("@h", hash), P("@s", salt), P("@id", userId));
        }

        public int CountUsers() { return _db.Scalar<int>("SELECT COUNT(*) FROM Users"); }
    }
}
