using System.Collections.Generic;
using System.Data;
using System.Linq;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Data;
using static Farm2Home.Infrastructure.Data.Db;

namespace Farm2Home.Infrastructure.Repositories
{
    public class EngagementRepository : IEngagementRepository
    {
        private readonly Db _db;
        public EngagementRepository(Db db) { _db = db; }

        // ----- promo codes -----
        public int? GetPromoPercent(string code)
        {
            int pct = _db.Scalar<int>("SELECT Percent FROM PromoCodes WHERE Code = @c AND IsActive = 1", P("@c", code));
            return pct > 0 ? pct : (int?)null;
        }

        // ----- follows -----
        public bool IsFollowing(int userId, int cooperativeId)
        {
            return _db.Scalar<int>("SELECT COUNT(*) FROM Follows WHERE UserId = @u AND CooperativeId = @c", P("@u", userId), P("@c", cooperativeId)) > 0;
        }

        public void SetFollowing(int userId, int cooperativeId, bool follow)
        {
            if (follow)
                _db.Execute("INSERT OR IGNORE INTO Follows (UserId, CooperativeId) VALUES (@u, @c)", P("@u", userId), P("@c", cooperativeId));
            else
                _db.Execute("DELETE FROM Follows WHERE UserId = @u AND CooperativeId = @c", P("@u", userId), P("@c", cooperativeId));
        }

        // ----- messages -----
        public int AddMessage(int fromUserId, int cooperativeId, string body)
        {
            return _db.Scalar<int>("INSERT INTO Messages (FromUserId, CooperativeId, Body) VALUES (@u, @c, @b) RETURNING MessageId",
                P("@u", fromUserId), P("@c", cooperativeId), P("@b", body));
        }

        public List<CoopMessage> GetInbox(int cooperativeId)
        {
            return _db.Query(@"SELECT m.MessageId, m.FromUserId, u.FullName, m.CooperativeId, m.Body, m.IsRead, m.CreatedAt
                FROM Messages m JOIN Users u ON u.UserId = m.FromUserId
                WHERE m.CooperativeId = @c ORDER BY m.CreatedAt DESC, m.MessageId DESC",
                r => new CoopMessage
                {
                    MessageId = r.I("MessageId"), FromUserId = r.I("FromUserId"), FromName = r.S("FullName"),
                    CooperativeId = r.I("CooperativeId"), Body = r.S("Body"), IsRead = r.B("IsRead"),
                    CreatedAt = System.DateTime.SpecifyKind(r.T("CreatedAt"), System.DateTimeKind.Utc).ToLocalTime()
                }, P("@c", cooperativeId));
        }

        public void MarkRead(int cooperativeId, int messageId)
        {
            _db.Execute("UPDATE Messages SET IsRead = 1 WHERE MessageId = @m AND CooperativeId = @c", P("@m", messageId), P("@c", cooperativeId));
        }

        public int UnreadCount(int cooperativeId)
        {
            return _db.Scalar<int>("SELECT COUNT(*) FROM Messages WHERE CooperativeId = @c AND IsRead = 0", P("@c", cooperativeId));
        }

        // ----- reviews -----
        public List<Review> GetReviews(int productId)
        {
            return _db.Query(@"SELECT rv.ReviewId, rv.ProductId, rv.UserId, u.FullName, rv.Rating, rv.Comment, rv.CreatedAt
                FROM Reviews rv JOIN Users u ON u.UserId = rv.UserId
                WHERE rv.ProductId = @p ORDER BY rv.CreatedAt DESC, rv.ReviewId DESC",
                r => new Review
                {
                    ReviewId = r.I("ReviewId"), ProductId = r.I("ProductId"), UserId = r.I("UserId"), UserName = r.S("FullName"),
                    Rating = r.I("Rating"), Comment = r.S("Comment"),
                    CreatedAt = System.DateTime.SpecifyKind(r.T("CreatedAt"), System.DateTimeKind.Utc).ToLocalTime()
                }, P("@p", productId));
        }

        public bool HasDeliveredOrder(int userId, int productId)
        {
            return _db.Scalar<int>(@"SELECT COUNT(*) FROM OrderItems oi JOIN Orders o ON o.OrderId = oi.OrderId
                WHERE o.CustomerId = @u AND oi.ProductId = @p AND o.OrderStatus = 6", P("@u", userId), P("@p", productId)) > 0;
        }

        public void SaveReview(Review review)
        {
            _db.Execute(@"INSERT INTO Reviews (ProductId, UserId, Rating, Comment) VALUES (@p, @u, @r, @c)
                ON CONFLICT (ProductId, UserId) DO UPDATE SET Rating = excluded.Rating, Comment = excluded.Comment, CreatedAt = datetime('now')",
                P("@p", review.ProductId), P("@u", review.UserId), P("@r", review.Rating), P("@c", review.Comment));
        }
    }
}
