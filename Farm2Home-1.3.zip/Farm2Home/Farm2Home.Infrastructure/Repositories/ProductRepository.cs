using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Data;
using static Farm2Home.Infrastructure.Data.Db;

namespace Farm2Home.Infrastructure.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private const string Select = @"
SELECT p.ProductId, p.CooperativeId, p.CategoryId, p.ProductName, p.Description, p.Price, p.Unit,
       p.StockQuantity, p.IsAvailable, p.ImagePath, p.HarvestInfo, p.CreatedAt,
       c.Name AS CooperativeName, c.Location AS CooperativeLocation, k.CategoryName,
       (SELECT COALESCE(AVG(rv.Rating), 0) FROM Reviews rv WHERE rv.ProductId = p.ProductId) AS AvgRating,
       (SELECT COUNT(*) FROM Reviews rv WHERE rv.ProductId = p.ProductId) AS ReviewCount
FROM Products p
JOIN Cooperatives c ON c.CooperativeId = p.CooperativeId
JOIN Categories  k ON k.CategoryId = p.CategoryId ";

        private readonly Db _db;
        public ProductRepository(Db db) { _db = db; }

        /// <summary>Column mapping shared with CartRepository.</summary>
        internal static Product Map(IDataRecord r)
        {
            return new Product
            {
                ProductId = r.I("ProductId"),
                CooperativeId = r.I("CooperativeId"),
                CategoryId = r.I("CategoryId"),
                ProductName = r.S("ProductName"),
                Description = r.S("Description"),
                Price = r.D("Price"),
                Unit = r.S("Unit"),
                StockQuantity = r.I("StockQuantity"),
                IsAvailable = r.B("IsAvailable"),
                ImagePath = r.S("ImagePath"),
                HarvestInfo = r.S("HarvestInfo"),
                CreatedAt = r.T("CreatedAt"),
                CooperativeName = r.S("CooperativeName"),
                CooperativeLocation = r.S("CooperativeLocation"),
                CategoryName = r.S("CategoryName"),
                AvgRating = r.F("AvgRating"),
                ReviewCount = r.I("ReviewCount")
            };
        }

        /// <summary>Builds a %text% pattern with LIKE wildcards in the input escaped.</summary>
        internal static string Like(string text)
        {
            string t = text.Trim().Replace(@"\", @"\\").Replace("%", @"\%").Replace("_", @"\_").Replace("[", @"\[");
            return "%" + t + "%";
        }

        public List<Product> Search(ProductFilter f)
        {
            var sql = new StringBuilder();
            var ps = new List<DbParameter>();

            sql.Append(Select);

            // Only fixed SQL fragments are appended below; all values are parameters.
            sql.Append("WHERE p.IsDeleted = 0 AND c.IsActive = 1 ");

            if (!string.IsNullOrWhiteSpace(f.Search))
            {
                sql.Append(@"AND (p.ProductName LIKE @s ESCAPE '\' OR c.Name LIKE @s ESCAPE '\' OR k.CategoryName LIKE @s ESCAPE '\') ");
                ps.Add(P("@s", Like(f.Search)));
            }
            if (f.CategoryId.HasValue) { sql.Append("AND p.CategoryId = @cat "); ps.Add(P("@cat", f.CategoryId.Value)); }
            if (f.CooperativeId.HasValue) { sql.Append("AND p.CooperativeId = @coop "); ps.Add(P("@coop", f.CooperativeId.Value)); }
            if (f.InStockOnly) sql.Append("AND p.IsAvailable = 1 AND p.StockQuantity > 0 ");
            if (f.OrganicOnly) sql.Append("AND c.IsOrganicCertified = 1 ");
            if (f.MinPrice.HasValue) { sql.Append("AND p.Price >= @min "); ps.Add(P("@min", f.MinPrice.Value)); }
            if (f.MaxPrice.HasValue) { sql.Append("AND p.Price <= @max "); ps.Add(P("@max", f.MaxPrice.Value)); }

            switch (f.Sort)
            {
                case ProductSort.PriceLowToHigh: sql.Append("ORDER BY p.Price ASC, p.ProductName"); break;
                case ProductSort.PriceHighToLow: sql.Append("ORDER BY p.Price DESC, p.ProductName"); break;
                case ProductSort.NameAToZ: sql.Append("ORDER BY p.ProductName ASC"); break;
                default: sql.Append("ORDER BY p.CreatedAt DESC, p.ProductId DESC"); break;
            }
            if (f.Take.HasValue) { sql.Append(" LIMIT @take"); ps.Add(P("@take", f.Take.Value)); }
            return _db.Query(sql.ToString(), Map, ps.ToArray());
        }

        public List<Product> GetByCooperative(int cooperativeId)
        {
            return _db.Query(Select + "WHERE p.CooperativeId = @c AND p.IsDeleted = 0 ORDER BY p.ProductName",
                Map, P("@c", cooperativeId));
        }

        public Product GetById(int productId)
        {
            return _db.Query(Select + "WHERE p.ProductId = @id AND p.IsDeleted = 0", Map, P("@id", productId)).FirstOrDefault();
        }

        public int Add(int cooperativeId, ProductInput i)
        {
            return _db.Scalar<int>(@"
INSERT INTO Products (CooperativeId, CategoryId, ProductName, Description, Price, Unit, StockQuantity, IsAvailable, ImagePath, HarvestInfo)
VALUES (@coop, @cat, @name, @desc, @price, @unit, @stock, @avail, @img, @harvest)
RETURNING ProductId",
                P("@coop", cooperativeId), P("@cat", i.CategoryId), P("@name", i.ProductName), P("@desc", i.Description),
                P("@price", i.Price), P("@unit", i.Unit), P("@stock", i.StockQuantity), P("@avail", i.IsAvailable),
                P("@img", i.ImagePath), P("@harvest", i.HarvestInfo));
        }

        public bool Update(int cooperativeId, ProductInput i)
        {
            return _db.Execute(@"
UPDATE Products
SET CategoryId=@cat, ProductName=@name, Description=@desc, Price=@price, Unit=@unit,
    StockQuantity=@stock, IsAvailable=@avail, ImagePath=@img, HarvestInfo=@harvest, UpdatedAt=datetime('now')
WHERE ProductId=@id AND CooperativeId=@coop AND IsDeleted=0",
                P("@id", i.ProductId), P("@coop", cooperativeId), P("@cat", i.CategoryId), P("@name", i.ProductName),
                P("@desc", i.Description), P("@price", i.Price), P("@unit", i.Unit), P("@stock", i.StockQuantity),
                P("@avail", i.IsAvailable), P("@img", i.ImagePath), P("@harvest", i.HarvestInfo)) == 1;
        }

        public bool SoftDelete(int cooperativeId, int productId)
        {
            return _db.Execute(@"UPDATE Products SET IsDeleted=1, IsAvailable=0, UpdatedAt=datetime('now')
                WHERE ProductId=@id AND CooperativeId=@coop AND IsDeleted=0",
                P("@id", productId), P("@coop", cooperativeId)) == 1;
        }

        public bool UpdateStock(int cooperativeId, int productId, int stock)
        {
            return _db.Execute(@"UPDATE Products SET StockQuantity=@s, UpdatedAt=datetime('now')
                WHERE ProductId=@id AND CooperativeId=@coop AND IsDeleted=0",
                P("@s", stock), P("@id", productId), P("@coop", cooperativeId)) == 1;
        }
    }
}
