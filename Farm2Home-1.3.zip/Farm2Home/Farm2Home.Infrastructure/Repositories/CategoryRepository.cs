using System.Collections.Generic;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Data;

namespace Farm2Home.Infrastructure.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly Db _db;
        public CategoryRepository(Db db) { _db = db; }

        public List<Category> GetAll()
        {
            return _db.Query("SELECT CategoryId, CategoryName FROM Categories ORDER BY CategoryId",
                r => new Category { CategoryId = r.I("CategoryId"), CategoryName = r.S("CategoryName") });
        }
    }
}
