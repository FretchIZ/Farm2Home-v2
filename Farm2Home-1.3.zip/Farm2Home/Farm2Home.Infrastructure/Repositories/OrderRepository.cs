using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using Farm2Home.Application;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Data;
using static Farm2Home.Infrastructure.Data.Db;

namespace Farm2Home.Infrastructure.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly Db _db;
        public OrderRepository(Db db) { _db = db; }

        private class CartLine
        {
            public int ProductId; public int Quantity; public string ProductName;
            public decimal Price; public int Stock; public bool Available; public bool Deleted; public int CooperativeId;
        }

        // ------------------------------------------------------------------
        // Checkout: ONE transaction. Any failure rolls everything back.
        // ------------------------------------------------------------------
        public List<Order> PlaceOrders(int userId, CheckoutRequest req, decimal deliveryFee)
        {
            var orderIds = new List<int>();

            using (var c = _db.Open())
            using (var tx = c.BeginTransaction())
            {
                try
                {
                    // Take SQLite's write lock first, so nobody else can change stock while we check it.
                    ExecTx(c, tx, "UPDATE Carts SET UpdatedAt = datetime('now') WHERE UserId = @u", P("@u", userId));

                    var lines = QueryTx(c, tx, @"
SELECT ci.ProductId, ci.Quantity, p.ProductName, p.Price, p.StockQuantity, p.IsAvailable, p.IsDeleted, p.CooperativeId
FROM Carts ct
JOIN CartItems ci ON ci.CartId = ct.CartId
JOIN Products AS p ON p.ProductId = ci.ProductId
WHERE ct.UserId = @u
ORDER BY ci.ProductId",
                        r => new CartLine
                        {
                            ProductId = r.I("ProductId"), Quantity = r.I("Quantity"), ProductName = r.S("ProductName"),
                            Price = r.D("Price"), Stock = r.I("StockQuantity"), Available = r.B("IsAvailable"),
                            Deleted = r.B("IsDeleted"), CooperativeId = r.I("CooperativeId")
                        }, P("@u", userId));

                    if (lines.Count == 0) throw new BusinessException("Your cart is empty.");

                    // A promo code is checked again here, so it cannot be faked from the screen.
                    string promoCode = null; int promoPercent = 0;
                    if (!string.IsNullOrWhiteSpace(req.PromoCode))
                    {
                        promoCode = req.PromoCode.Trim().ToUpperInvariant();
                        promoPercent = ScalarTx<int>(c, tx, "SELECT Percent FROM PromoCodes WHERE Code = @c AND IsActive = 1", P("@c", promoCode));
                        if (promoPercent <= 0) throw new BusinessException("That promo code isn't valid.");
                    }

                    foreach (var l in lines)
                    {
                        if (l.Deleted || !l.Available)
                            throw new BusinessException(l.ProductName + " is no longer available. Please remove it from your cart.");
                        if (l.Quantity > l.Stock)
                            throw new BusinessException(l.Stock <= 0
                                ? l.ProductName + " is sold out."
                                : "Insufficient stock for " + l.ProductName + ". Only " + l.Stock + " units are currently available.");
                    }

                    foreach (var group in lines.GroupBy(l => l.CooperativeId))
                    {
                        decimal subtotal = group.Sum(l => l.Price * l.Quantity);
                        decimal discount = Farm2Home.Application.Services.OrderService.DiscountFor(subtotal, promoPercent);
                        string tempNumber = "TMP" + Guid.NewGuid().ToString("N").Substring(0, 17);

                        int orderId = ScalarTx<int>(c, tx, @"
INSERT INTO Orders (OrderNumber, CustomerId, CooperativeId, Subtotal, DeliveryFee, Discount, PromoCode, Total, PaymentMethod,
                   PaymentStatus, OrderStatus, CustomerName, DeliveryAddress, ContactNumber)
VALUES (@num, @cust, @coop, @sub, @fee, @disc, @promo, @total, @pm, 'Unpaid', 1, @name, @addr, @phone)
RETURNING OrderId",
                            P("@num", tempNumber), P("@cust", userId), P("@coop", group.Key), P("@sub", subtotal),
                            P("@fee", deliveryFee), P("@disc", discount), P("@promo", discount > 0 ? promoCode : null),
                            P("@total", subtotal - discount + deliveryFee), P("@pm", req.PaymentMethod),
                            P("@name", req.CustomerName), P("@addr", req.DeliveryAddress), P("@phone", req.ContactNumber));

                        ExecTx(c, tx, @"UPDATE Orders
                            SET OrderNumber = 'FH-' || strftime('%Y', OrderDate) || '-' || substr('000000' || OrderId, -6)
                            WHERE OrderId = @id", P("@id", orderId));

                        foreach (var l in group)
                        {
                            ExecTx(c, tx, @"INSERT INTO OrderItems (OrderId, ProductId, ProductName, Quantity, UnitPrice, Subtotal)
                                VALUES (@o, @p, @n, @q, @price, @sub)",
                                P("@o", orderId), P("@p", l.ProductId), P("@n", l.ProductName), P("@q", l.Quantity),
                                P("@price", l.Price), P("@sub", l.Price * l.Quantity));

                            int updated = ExecTx(c, tx, @"UPDATE Products
                                SET StockQuantity = StockQuantity - @q, UpdatedAt = datetime('now')
                                WHERE ProductId = @p AND StockQuantity >= @q",
                                P("@q", l.Quantity), P("@p", l.ProductId));
                            if (updated != 1)
                                throw new BusinessException("Insufficient stock for " + l.ProductName + ". Please review your cart.");
                        }

                        ExecTx(c, tx, "INSERT INTO Deliveries (OrderId, Status, Notes) VALUES (@o, 1, @n)", P("@o", orderId),
                            P("@n", string.IsNullOrWhiteSpace(req.DeliverySlot) ? null : req.DeliverySlot.Trim()));
                        orderIds.Add(orderId);
                    }

                    ExecTx(c, tx, @"DELETE FROM CartItems WHERE CartId IN (SELECT CartId FROM Carts WHERE UserId = @u)", P("@u", userId));

                    tx.Commit();
                }
                catch (DbException ex) when (ex.Message.IndexOf("locked", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                             ex.Message.IndexOf("busy", StringComparison.OrdinalIgnoreCase) >= 0)   // another writer held the lock: nothing was saved
                {
                    try { tx.Rollback(); } catch { }
                    throw new BusinessException("The store is busy right now. Please try placing your order again.");
                }
                catch
                {
                    try { tx.Rollback(); } catch { /* connection already broken or already rolled back */ }
                    throw;
                }
            }

            return orderIds.Select(GetById).ToList();
        }

        // ------------------------------------------------------------------
        // Reads
        // ------------------------------------------------------------------
        private const string OrderSelect = @"
SELECT o.OrderId, o.OrderNumber, o.CustomerId, o.CooperativeId, c.Name AS CooperativeName, o.OrderDate,
       o.Subtotal, o.DeliveryFee, o.Discount, o.PromoCode, o.Total, o.PaymentMethod, o.PaymentStatus, o.OrderStatus,
       o.CustomerName, o.DeliveryAddress, o.ContactNumber
FROM Orders o JOIN Cooperatives c ON c.CooperativeId = o.CooperativeId ";

        private static Order MapOrder(IDataRecord r)
        {
            return new Order
            {
                OrderId = r.I("OrderId"), OrderNumber = r.S("OrderNumber"), CustomerId = r.I("CustomerId"),
                CooperativeId = r.I("CooperativeId"), CooperativeName = r.S("CooperativeName"),
                OrderDate = DateTime.SpecifyKind(r.T("OrderDate"), DateTimeKind.Utc).ToLocalTime(),
                Subtotal = r.D("Subtotal"), DeliveryFee = r.D("DeliveryFee"), Discount = r.D("Discount"), PromoCode = r.S("PromoCode"), Total = r.D("Total"),
                PaymentMethod = r.S("PaymentMethod"), PaymentStatus = r.S("PaymentStatus"),
                OrderStatus = (OrderStatus)r.I("OrderStatus"),
                CustomerName = r.S("CustomerName"), DeliveryAddress = r.S("DeliveryAddress"), ContactNumber = r.S("ContactNumber")
            };
        }

        private static OrderItem MapItem(IDataRecord r)
        {
            return new OrderItem
            {
                OrderItemId = r.I("OrderItemId"), OrderId = r.I("OrderId"), ProductId = r.I("ProductId"),
                ProductName = r.S("ProductName"), Quantity = r.I("Quantity"),
                UnitPrice = r.D("UnitPrice"), Subtotal = r.D("Subtotal")
            };
        }

        /// <param name="condition">A constant SQL fragment chosen in this class (never user input), using @p.</param>
        private List<Order> Load(string condition, int id)
        {
            var orders = _db.Query(OrderSelect + "WHERE " + condition + " ORDER BY o.OrderDate DESC, o.OrderId DESC", MapOrder, P("@p", id));
            if (orders.Count == 0) return orders;

            var items = _db.Query(@"SELECT oi.OrderItemId, oi.OrderId, oi.ProductId, oi.ProductName, oi.Quantity, oi.UnitPrice, oi.Subtotal
                FROM OrderItems oi JOIN Orders o ON o.OrderId = oi.OrderId WHERE " + condition, MapItem, P("@p", id));
            var byOrder = items.ToLookup(i => i.OrderId);
            foreach (var o in orders) o.Items = byOrder[o.OrderId].ToList();
            return orders;
        }

        public Order GetById(int orderId)
        {
            var o = Load("o.OrderId = @p", orderId).FirstOrDefault();
            if (o == null) return null;
            o.Delivery = _db.Query("SELECT DeliveryId, OrderId, Status, UpdatedAt, Notes FROM Deliveries WHERE OrderId = @p",
                r => new Delivery
                {
                    DeliveryId = r.I("DeliveryId"), OrderId = r.I("OrderId"), Status = (OrderStatus)r.I("Status"),
                    UpdatedAt = r.T("UpdatedAt"), Notes = r.S("Notes")
                }, P("@p", orderId)).FirstOrDefault();
            return o;
        }

        public List<Order> GetByCustomer(int userId) { return Load("o.CustomerId = @p", userId); }
        public List<Order> GetByCooperative(int cooperativeId) { return Load("o.CooperativeId = @p", cooperativeId); }

        // ------------------------------------------------------------------
        // Status changes
        // ------------------------------------------------------------------
        private const string StatusSql = @"
UPDATE Orders SET OrderStatus = @s,
    PaymentStatus = CASE WHEN @s = 6 AND PaymentMethod = 'CashOnDelivery' THEN 'Paid'
                         WHEN @s = 7 AND PaymentStatus = 'Unpaid' THEN 'Cancelled'
                         ELSE PaymentStatus END
WHERE OrderId = @id;
UPDATE Deliveries SET Status = @s, UpdatedAt = datetime('now') WHERE OrderId = @id;";

        public void UpdateStatus(int orderId, OrderStatus status)
        {
            _db.Execute(StatusSql, P("@s", (int)status), P("@id", orderId));
        }

        public void Cancel(int orderId)
        {
            using (var c = _db.Open())
            using (var tx = c.BeginTransaction())
            {
                try
                {
                    ExecTx(c, tx, "UPDATE Orders SET OrderStatus = OrderStatus WHERE OrderId = @id", P("@id", orderId));   // take the write lock
                    int current = ScalarTx<int>(c, tx, "SELECT OrderStatus FROM Orders WHERE OrderId = @id", P("@id", orderId));
                    if (current != (int)OrderStatus.Pending && current != (int)OrderStatus.Confirmed)
                        throw new BusinessException("This order can no longer be cancelled.");

                    ExecTx(c, tx, @"UPDATE Products
                        SET StockQuantity = StockQuantity + (SELECT SUM(oi.Quantity) FROM OrderItems oi WHERE oi.OrderId = @id AND oi.ProductId = Products.ProductId),
                            UpdatedAt = datetime('now')
                        WHERE ProductId IN (SELECT ProductId FROM OrderItems WHERE OrderId = @id)", P("@id", orderId));
                    ExecTx(c, tx, StatusSql, P("@s", (int)OrderStatus.Cancelled), P("@id", orderId));
                    tx.Commit();
                }
                catch
                {
                    try { tx.Rollback(); } catch { }
                    throw;
                }
            }
        }

        // ------------------------------------------------------------------
        // Dashboard numbers
        // ------------------------------------------------------------------
        public CooperativeStats GetStats(int cooperativeId)
        {
            var stats = _db.Query(@"
SELECT
 (SELECT COUNT(*) FROM Products WHERE CooperativeId = @c AND IsDeleted = 0) AS TotalProducts,
 (SELECT COUNT(*) FROM Products WHERE CooperativeId = @c AND IsDeleted = 0 AND IsAvailable = 1 AND StockQuantity > 0) AS ActiveListings,
 (SELECT COUNT(*) FROM Orders WHERE CooperativeId = @c AND OrderStatus = 1) AS PendingOrders,
 (SELECT COUNT(*) FROM Orders WHERE CooperativeId = @c AND OrderStatus = 6) AS CompletedOrders,
 (SELECT COALESCE(SUM(Total), 0) FROM Orders WHERE CooperativeId = @c AND OrderStatus = 6) AS TotalSales,
 (SELECT COALESCE(SUM(Total), 0) FROM Orders WHERE CooperativeId = @c AND OrderStatus <> 7 AND OrderDate >= @month) AS MonthSales,
 (SELECT COUNT(DISTINCT CustomerId) FROM Orders WHERE CooperativeId = @c AND OrderStatus <> 7) AS Customers",
                r => new CooperativeStats
                {
                    TotalProducts = r.I("TotalProducts"), ActiveListings = r.I("ActiveListings"),
                    PendingOrders = r.I("PendingOrders"), CompletedOrders = r.I("CompletedOrders"),
                    TotalSales = r.D("TotalSales"), MonthSales = r.D("MonthSales"), CustomersReached = r.I("Customers")
                }, P("@c", cooperativeId), P("@month", new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToUniversalTime())).First();
            return stats;
        }

        public List<DailySale> GetDailySales(int cooperativeId, int days)
        {
            DateTime today = DateTime.Now.Date;
            DateTime firstLocal = today.AddDays(-(days - 1));
            var rows = _db.Query("SELECT OrderDate, Total FROM Orders WHERE CooperativeId = @c AND OrderStatus <> 7 AND OrderDate >= @since",
                r => new { When = DateTime.SpecifyKind(r.T("OrderDate"), DateTimeKind.Utc).ToLocalTime(), Total = r.D("Total") },
                P("@c", cooperativeId), P("@since", firstLocal.ToUniversalTime()));
            var result = new List<DailySale>();
            for (int i = 0; i < days; i++)
            {
                DateTime d = firstLocal.AddDays(i);
                result.Add(new DailySale { Date = d, Total = rows.Where(x => x.When.Date == d).Sum(x => x.Total) });
            }
            return result;
        }
    }
}
