using System.Collections.Generic;
using System.Data;
using System.Linq;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Data;
using static Farm2Home.Infrastructure.Data.Db;

namespace Farm2Home.Infrastructure.Repositories
{
    public class CooperativeRepository : ICooperativeRepository
    {
        private const string Select = @"
SELECT c.CooperativeId, c.Name, c.Description, c.Location, c.ContactEmail, c.ContactPhone,
       c.ImagePath, c.IsOrganicCertified, c.IsActive, c.EstablishedYear, c.MemberFarmers, c.HectaresFarmed,
       (SELECT COUNT(*) FROM Products p
         WHERE p.CooperativeId = c.CooperativeId AND p.IsDeleted = 0 AND p.IsAvailable = 1) AS ProductCount,
       (SELECT COALESCE(AVG(rv.Rating), 0) FROM Reviews rv JOIN Products rp ON rp.ProductId = rv.ProductId WHERE rp.CooperativeId = c.CooperativeId) AS AvgRating,
       (SELECT COUNT(*) FROM Reviews rv JOIN Products rp ON rp.ProductId = rv.ProductId WHERE rp.CooperativeId = c.CooperativeId) AS ReviewCount,
       (SELECT COUNT(*) FROM Follows f WHERE f.CooperativeId = c.CooperativeId) AS FollowerCount
FROM Cooperatives c ";

        private readonly Db _db;
        public CooperativeRepository(Db db) { _db = db; }

        private static Cooperative Map(IDataRecord r)
        {
            return new Cooperative
            {
                CooperativeId = r.I("CooperativeId"),
                Name = r.S("Name"),
                Description = r.S("Description"),
                Location = r.S("Location"),
                ContactEmail = r.S("ContactEmail"),
                ContactPhone = r.S("ContactPhone"),
                ImagePath = r.S("ImagePath"),
                IsOrganicCertified = r.B("IsOrganicCertified"),
                IsActive = r.B("IsActive"),
                ProductCount = r.I("ProductCount"),
                EstablishedYear = r.IN("EstablishedYear"),
                MemberFarmers = r.IN("MemberFarmers"),
                HectaresFarmed = r.IN("HectaresFarmed"),
                AvgRating = r.F("AvgRating"),
                ReviewCount = r.I("ReviewCount"),
                FollowerCount = r.I("FollowerCount")
            };
        }

        public List<Cooperative> GetAll(string search)
        {
            if (string.IsNullOrWhiteSpace(search))
                return _db.Query(Select + "WHERE c.IsActive = 1 ORDER BY c.Name", Map);

            return _db.Query(Select + @"WHERE c.IsActive = 1
                AND (c.Name LIKE @s ESCAPE '\' OR c.Location LIKE @s ESCAPE '\') ORDER BY c.Name",
                Map, P("@s", ProductRepository.Like(search)));
        }

        public Cooperative GetById(int id)
        {
            return _db.Query(Select + "WHERE c.CooperativeId = @id AND c.IsActive = 1", Map, P("@id", id)).FirstOrDefault();
        }

        public PublicStats GetPublicStats()
        {
            return _db.Query(@"SELECT
 (SELECT COUNT(*) FROM Cooperatives WHERE IsActive = 1) AS Coops,
 (SELECT COUNT(*) FROM Products WHERE IsDeleted = 0 AND IsAvailable = 1) AS Prods",
                r => new PublicStats { Cooperatives = r.I("Coops"), Products = r.I("Prods") }).First();
        }

        public bool UpdateProfile(Cooperative c)
        {
            return _db.Execute(@"UPDATE Cooperatives SET Name=@n, Description=@d, Location=@l,
                ContactEmail=@e, ContactPhone=@p, ImagePath=@i WHERE CooperativeId=@id",
                P("@n", c.Name), P("@d", c.Description), P("@l", c.Location), P("@e", c.ContactEmail),
                P("@p", c.ContactPhone), P("@i", c.ImagePath), P("@id", c.CooperativeId)) == 1;
        }
    }
}
