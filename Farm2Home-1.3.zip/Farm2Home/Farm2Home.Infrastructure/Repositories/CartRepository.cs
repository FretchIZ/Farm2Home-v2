using System.Collections.Generic;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Data;
using static Farm2Home.Infrastructure.Data.Db;

namespace Farm2Home.Infrastructure.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly Db _db;
        public CartRepository(Db db) { _db = db; }

        public List<CartItem> GetItems(int userId)
        {
            return _db.Query(@"
SELECT ci.Quantity,
       p.ProductId, p.CooperativeId, p.CategoryId, p.ProductName, p.Description, p.Price, p.Unit,
       p.StockQuantity, p.IsAvailable, p.ImagePath, p.HarvestInfo, p.CreatedAt,
       c.Name AS CooperativeName, c.Location AS CooperativeLocation, k.CategoryName,
       (SELECT COALESCE(AVG(rv.Rating), 0) FROM Reviews rv WHERE rv.ProductId = p.ProductId) AS AvgRating,
       (SELECT COUNT(*) FROM Reviews rv WHERE rv.ProductId = p.ProductId) AS ReviewCount
FROM Carts ct
JOIN CartItems ci ON ci.CartId = ct.CartId
JOIN Products p ON p.ProductId = ci.ProductId
JOIN Cooperatives c ON c.CooperativeId = p.CooperativeId
JOIN Categories k ON k.CategoryId = p.CategoryId
WHERE ct.UserId = @u
ORDER BY ci.CartItemId",
                r =>
                {
                    var product = ProductRepository.Map(r);
                    return new CartItem { ProductId = product.ProductId, Quantity = r.I("Quantity"), Product = product };
                }, P("@u", userId));
        }

        public int GetQuantity(int userId, int productId)
        {
            return _db.Scalar<int>(@"SELECT COALESCE(SUM(ci.Quantity), 0)
                FROM Carts ct JOIN CartItems ci ON ci.CartId = ct.CartId
                WHERE ct.UserId = @u AND ci.ProductId = @p", P("@u", userId), P("@p", productId));
        }

        public void SetItem(int userId, int productId, int quantity)
        {
            _db.Execute(@"
INSERT OR IGNORE INTO Carts (UserId) VALUES (@u);
INSERT INTO CartItems (CartId, ProductId, Quantity)
    SELECT CartId, @p, @q FROM Carts WHERE UserId = @u
    ON CONFLICT (CartId, ProductId) DO UPDATE SET Quantity = excluded.Quantity;
UPDATE Carts SET UpdatedAt = datetime('now') WHERE UserId = @u;",
                P("@u", userId), P("@p", productId), P("@q", quantity));
        }

        public void RemoveItem(int userId, int productId)
        {
            _db.Execute(@"DELETE FROM CartItems WHERE ProductId = @p
                AND CartId IN (SELECT CartId FROM Carts WHERE UserId = @u)", P("@u", userId), P("@p", productId));
        }

        public void Clear(int userId)
        {
            _db.Execute(@"DELETE FROM CartItems WHERE CartId IN (SELECT CartId FROM Carts WHERE UserId = @u)", P("@u", userId));
        }
    }
}
