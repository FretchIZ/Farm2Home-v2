using System.Security.Cryptography;
using Farm2Home.Application.Interfaces;

namespace Farm2Home.Infrastructure.Security
{
    /// <summary>PBKDF2 (HMAC-SHA256) with a random 32-byte salt per password. Available on .NET Framework 4.7.2+.</summary>
    public class Pbkdf2PasswordHasher : IPasswordHasher
    {
        private const int Iterations = 120000;
        private const int SaltSize = 32;
        private const int HashSize = 32;

        public void Hash(string password, out byte[] hash, out byte[] salt)
        {
            salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            hash = Derive(password, salt);
        }

        public bool Verify(string password, byte[] hash, byte[] salt)
        {
            if (hash == null || salt == null) return false;
            return ConstantTimeEquals(Derive(password, salt), hash);
        }

        private static byte[] Derive(string password, byte[] salt)
        {
            using (var kdf = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256))
                return kdf.GetBytes(HashSize);
        }

        private static bool ConstantTimeEquals(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
