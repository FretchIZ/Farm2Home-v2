using System.Configuration;
using System.Linq;
using Farm2Home.Application.Interfaces;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Infrastructure.Security
{
    /// <summary>Development/demo credentials. Passwords are hashed before they reach the database.
    /// Turn off with SeedDemoAccounts=false in App.config for any real deployment.</summary>
    public static class DemoAccounts
    {
        public const string ConsumerEmail = "consumer@farm2home.local";
        public const string CooperativeEmail = "coop@farm2home.local";
        public const string AdminEmail = "admin@farm2home.local";
        public const string Password = "Farm2Home@2026";
    }

    public static class DemoDataSeeder
    {
        private static byte[][][] _pre; private static int _preIdx;
        /// <returns>True when the demo accounts were just created.</returns>
        public static bool SeedIfEmpty(IUserRepository users, ICooperativeRepository coops, IPasswordHasher hasher)
        {
            if (!string.Equals(ConfigurationManager.AppSettings["SeedDemoAccounts"], "true", System.StringComparison.OrdinalIgnoreCase)) return false;
            if (users.CountUsers() > 0) return false;

            var firstCoop = coops.GetAll(null).FirstOrDefault();

            // Password hashing is deliberately slow, so hash the five demo passwords side by side (first run only).
            var hashes = new byte[5][]; var salts = new byte[5][];
            System.Threading.Tasks.Parallel.For(0, 5, i => { byte[] h, sl; hasher.Hash(DemoAccounts.Password, out h, out sl); hashes[i] = h; salts[i] = sl; });
            _pre = new[] { 0, 1, 2, 3, 4 }.Select(i => new[] { hashes[i], salts[i] }).ToArray(); _preIdx = 0;

            Add(users, hasher, DemoAccounts.ConsumerEmail, "Maria Clara", UserRole.Consumer, null,
                "0917-555-0101", "12 Sampaguita St., Brgy. Commonwealth, Quezon City, Metro Manila");
            if (firstCoop != null)
                Add(users, hasher, DemoAccounts.CooperativeEmail, firstCoop.Name + " (Manager)", UserRole.Cooperative,
                    firstCoop.CooperativeId, "0917-555-0102", null);
            Add(users, hasher, DemoAccounts.AdminEmail, "Farm2Home Admin", UserRole.Administrator, null, null, null);
            Add(users, hasher, "juan@farm2home.local", "Juan Dela Cruz", UserRole.Consumer, null, "0917-555-0103", "45 Mabini St., Brgy. Poblacion, Cebu City, Cebu");
            Add(users, hasher, "ana@farm2home.local", "Ana Reyes", UserRole.Consumer, null, "0917-555-0104", "8 Rizal Ave., Brgy. San Roque, Davao City, Davao del Sur");
            return true;
        }

        /// <summary>Sample customer reviews so a brand-new demo database does not look empty. Real users add their own after delivery.</summary>
        public static void SeedSampleReviews(IUserRepository users, IProductRepository products, IEngagementRepository engagement)
        {
            var reviewers = new[] { DemoAccounts.ConsumerEmail, "juan@farm2home.local", "ana@farm2home.local" }
                .Select(users.GetByEmail).Where(u => u != null).ToList();
            var comments = new[] { "Fresh and sweet, arrived the next day.", "Great quality, will order again.", "Good value for the price.", "Crisp and clean. Loved it.", null };
            var all = products.Search(new Farm2Home.Application.DTOs.ProductFilter()).OrderBy(p => p.ProductId).ToList();
            for (int i = 0; i < all.Count; i++)
            {
                if (i % 4 == 3) continue;                                          // leave some products unrated
                for (int r = 0; r < reviewers.Count; r++)
                {
                    if ((i + r) % 3 == 2) continue;
                    engagement.SaveReview(new Review { ProductId = all[i].ProductId, UserId = reviewers[r].UserId, Rating = 4 + ((i + r) % 2), Comment = comments[(i * 2 + r) % comments.Length] });
                }
            }
        }

        private static void Add(IUserRepository users, IPasswordHasher hasher, string email, string name,
                                UserRole role, int? coopId, string phone, string address)
        {
            byte[] hash, salt;
            if (_pre != null && _preIdx < _pre.Length) { hash = _pre[_preIdx][0]; salt = _pre[_preIdx][1]; _preIdx++; }
            else hasher.Hash(DemoAccounts.Password, out hash, out salt);
            users.Create(new User
            {
                Email = email, FullName = name, PasswordHash = hash, PasswordSalt = salt, Role = role,
                CooperativeId = coopId, ContactNumber = phone, DefaultAddress = address
            });
        }
    }
}
