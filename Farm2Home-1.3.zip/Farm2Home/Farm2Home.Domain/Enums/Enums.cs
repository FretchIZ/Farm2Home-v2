namespace Farm2Home.Domain.Enums
{
    public enum UserRole { Consumer = 1, Cooperative = 2, Administrator = 3 }

    public enum OrderStatus
    {
        Pending = 1,
        Confirmed = 2,
        Preparing = 3,
        ReadyForDelivery = 4,
        OutForDelivery = 5,
        Delivered = 6,
        Cancelled = 7
    }
}
