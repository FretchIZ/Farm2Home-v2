using System;
using System.Collections.Generic;
using Farm2Home.Domain.Enums;

namespace Farm2Home.Domain.Entities
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }

    public class Cooperative
    {
        public int CooperativeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public string ContactEmail { get; set; }
        public string ContactPhone { get; set; }
        public string ImagePath { get; set; }
        public bool IsOrganicCertified { get; set; }
        public bool IsActive { get; set; }
        public int ProductCount { get; set; }
        public int? EstablishedYear { get; set; }
        public int? MemberFarmers { get; set; }
        public int? HectaresFarmed { get; set; }
        public double AvgRating { get; set; }          // from real customer reviews of this cooperative's products
        public int ReviewCount { get; set; }
        public int FollowerCount { get; set; }
    }

    public class Product
    {
        public int ProductId { get; set; }
        public int CooperativeId { get; set; }
        public int CategoryId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string Unit { get; set; }
        public int StockQuantity { get; set; }
        public bool IsAvailable { get; set; }
        public string ImagePath { get; set; }
        public string HarvestInfo { get; set; }
        public DateTime CreatedAt { get; set; }

        // Joined display fields
        public string CooperativeName { get; set; }
        public string CooperativeLocation { get; set; }
        public string CategoryName { get; set; }

        // From customer reviews (0 reviews = not rated yet)
        public double AvgRating { get; set; }
        public int ReviewCount { get; set; }

        public bool InStock { get { return IsAvailable && StockQuantity > 0; } }
    }

    public class CartItem
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public Product Product { get; set; }
        public decimal Subtotal { get { return Product == null ? 0m : Product.Price * Quantity; } }
    }

    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Subtotal { get; set; }
    }

    public class Delivery
    {
        public int DeliveryId { get; set; }
        public int OrderId { get; set; }
        public OrderStatus Status { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string Notes { get; set; }
    }

    public class Order
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public int CustomerId { get; set; }
        public int CooperativeId { get; set; }
        public string CooperativeName { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal Subtotal { get; set; }
        public decimal DeliveryFee { get; set; }
        public decimal Discount { get; set; }          // promo code saving (0 when none)
        public string PromoCode { get; set; }
        public decimal Total { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string CustomerName { get; set; }
        public string DeliveryAddress { get; set; }
        public string ContactNumber { get; set; }
        public List<OrderItem> Items { get; set; } = new List<OrderItem>();
        public Delivery Delivery { get; set; }
    }

    public class User
    {
        public int UserId { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
        public UserRole Role { get; set; }
        public int? CooperativeId { get; set; }
        public string ContactNumber { get; set; }
        public string DefaultAddress { get; set; }
        public bool IsActive { get; set; }
        public int FailedLogins { get; set; }
    }

    public class Review
    {
        public int ReviewId { get; set; }
        public int ProductId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int Rating { get; set; }               // 1..5
        public string Comment { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    /// <summary>A message a consumer sent to a cooperative.</summary>
    public class CoopMessage
    {
        public int MessageId { get; set; }
        public int FromUserId { get; set; }
        public string FromName { get; set; }
        public int CooperativeId { get; set; }
        public string Body { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
