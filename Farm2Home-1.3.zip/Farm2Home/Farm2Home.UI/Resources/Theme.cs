using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Windows.Forms;

namespace Farm2Home.UI
{
    /// <summary>Single source of truth for colors, fonts and spacing. Every screen uses this.</summary>
    internal static class Theme
    {
        // Palette: the original wireframe colours. The hex values live in Palette.cs (one accessibility adjustment is documented there).
        public static readonly Color Forest = ColorTranslator.FromHtml(Palette.Forest);
        public static readonly Color ForestHover = ColorTranslator.FromHtml(Palette.ForestHover);
        public static readonly Color Deep = ColorTranslator.FromHtml(Palette.Deep);
        public static readonly Color TitleBar = ColorTranslator.FromHtml(Palette.TitleBar);
        public static readonly Color IconGreen = ColorTranslator.FromHtml(Palette.IconGreen);
        public static readonly Color SidebarActive = ColorTranslator.FromHtml(Palette.SidebarActive);
        public static readonly Color SidebarText = ColorTranslator.FromHtml(Palette.SidebarText);
        public static readonly Color Moss = ColorTranslator.FromHtml(Palette.Moss);
        public static readonly Color MossLight = ColorTranslator.FromHtml(Palette.MossLight);
        public static readonly Color Marigold = ColorTranslator.FromHtml(Palette.Marigold);
        public static readonly Color MarigoldHover = ColorTranslator.FromHtml(Palette.MarigoldHover);
        public static readonly Color MarigoldSoft = ColorTranslator.FromHtml(Palette.MarigoldSoft);
        public static readonly Color MarigoldText = ColorTranslator.FromHtml(Palette.MarigoldText);
        public static readonly Color OnMarigold = ColorTranslator.FromHtml(Palette.OnMarigold);
        public static readonly Color Background = ColorTranslator.FromHtml(Palette.Background);
        public static readonly Color Surface = Color.White;
        public static readonly Color Ink = ColorTranslator.FromHtml(Palette.Ink);
        public static readonly Color Muted = ColorTranslator.FromHtml(Palette.Muted);
        public static readonly Color Danger = ColorTranslator.FromHtml(Palette.Danger);
        public static readonly Color DangerSoft = ColorTranslator.FromHtml(Palette.DangerSoft);
        public static readonly Color Info = ColorTranslator.FromHtml(Palette.Info);
        public static readonly Color InfoSoft = ColorTranslator.FromHtml(Palette.InfoSoft);
        public static readonly Color Disabled = ColorTranslator.FromHtml(Palette.Disabled);
        public static readonly Color NeutralBadge = ColorTranslator.FromHtml(Palette.NeutralBadge);
        public static readonly Color ToggleTrack = ColorTranslator.FromHtml(Palette.ToggleTrack);
        public static readonly Color UnreadTint = ColorTranslator.FromHtml(Palette.UnreadTint);

        /// <summary>True when Windows "High contrast" is switched on. Borders and focus rings then use the system colours.</summary>
        public static readonly bool HighContrast = DetectHighContrast();
        private static bool DetectHighContrast() { try { return SystemInformation.HighContrast; } catch { return false; } }

        // Decorative hairlines (cards, dividers) keep the original soft colours; they do not carry meaning on their own.
        public static readonly Color Border = HighContrast ? SystemColors.WindowText : ColorTranslator.FromHtml(Palette.Border);
        public static readonly Color BorderStrong = HighContrast ? SystemColors.WindowText : ColorTranslator.FromHtml(Palette.BorderStrong);

        // Outlines that identify a control (input boxes, outline buttons, unticked boxes) reuse the existing Muted green-grey: 5.0:1 or more on every surface.
        public static readonly Color ControlBorder = HighContrast ? SystemColors.WindowText : Muted;
        // Keyboard focus ring: Forest is 8.6:1 on the page; a white inner ring keeps it visible on Forest and Marigold fills.
        public static readonly Color FocusRing = HighContrast ? SystemColors.Highlight : Forest;
        public static readonly Color FocusInner = Color.White;

        // Spacing
        public const int Gap = 16;
        public const int PagePadding = 32;
        public const int CardRadius = 16;
        public const int ControlRadius = 10;

        // Fonts: Fraunces / Manrope if installed, otherwise safe fallbacks that exist on every Windows PC.
        private static readonly string HeadingFamily = Pick("Fraunces", "Georgia", "Times New Roman");
        private static readonly string BodyFamily = Pick("Manrope", "Segoe UI", "Tahoma");
        private static readonly string IconFamily = Pick("Segoe Fluent Icons", "Segoe MDL2 Assets", "Segoe UI Symbol");
        private static readonly Dictionary<string, Font> Cache = new Dictionary<string, Font>();

        private static string Pick(params string[] names)
        {
            using (var installed = new InstalledFontCollection())
            {
                foreach (var n in names)
                    if (installed.Families.Any(f => string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase))) return n;
            }
            return "Microsoft Sans Serif";
        }

        private static Font Get(string family, float size, FontStyle style)
        {
            string key = family + "|" + size + "|" + (int)style;
            Font f;
            if (!Cache.TryGetValue(key, out f)) { f = new Font(family, size, style, GraphicsUnit.Point); Cache[key] = f; }
            return f;
        }

        public static Font Heading(float size) { return Get(HeadingFamily, size, FontStyle.Regular); }
        public static Font Body(float size, FontStyle style = FontStyle.Regular) { return Get(BodyFamily, size, style); }
        public static Font Icon(float size) { return Get(IconFamily, size, FontStyle.Regular); }
    }

    /// <summary>Icon names. They are drawn as vector shapes by IconPainter, so no icon font is needed and they look the same on every PC.</summary>
    internal static class Icons
    {
        public const string Home = "home";
        public const string Browse = "search";
        public const string Cart = "bag";
        public const string Orders = "bookmark";
        public const string Cooperatives = "barn";
        public const string Profile = "user";
        public const string Dashboard = "grid";
        public const string Products = "leaf";
        public const string Earnings = "dollar";
        public const string SignOut = "signout";
        public const string Pin = "pin";
        public const string Bell = "bell";
        public const string Check = "check";
        public const string Trash = "trash";
        public const string Lock = "lock";
        public const string Mail = "mail";
        public const string Clock = "clock";
        public const string Card = "card";
        public const string Upload = "upload";
        public const string People = "people";
        public const string Alert = "alert";
        public const string Apple = "apple";
        public const string Grain = "grain";
        public const string Bean = "circle";
        public const string Sprout = "sprout";
        public const string Plus = "plus";
        public const string Minus = "minus";
        public const string Chevron = "chevron";
    }
}
