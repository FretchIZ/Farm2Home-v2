using System;
using System.Collections.Generic;
using System.Globalization;

namespace Farm2Home.UI
{
    /// <summary>
    /// The Farm2Home colour values as plain hex text, with no dependency on System.Drawing, so the unit tests can check them.
    /// Every value in the "Original" group is the colour from the original wireframes and must not be edited.
    /// Anything that had to change for accessibility is listed in <see cref="Adjustments"/>, with the reason.
    /// </summary>
    internal static class Palette
    {
        // ---- Original brand colours (unchanged) -------------------------------------------------
        public const string Forest = "#1F4E3D";
        public const string ForestHover = "#286451";
        public const string Deep = "#17342A";
        public const string TitleBar = "#17342A";
        public const string IconGreen = "#7A9B6A";
        public const string SidebarActive = "#35604F";
        public const string SidebarText = "#DCE9E1";
        public const string Moss = "#676B3F";
        public const string MossLight = "#E7EEE2";
        public const string Marigold = "#E8A33D";
        public const string MarigoldHover = "#F0B252";
        public const string MarigoldSoft = "#FCEBD2";
        public const string OnMarigold = "#3A2A0A";
        public const string Background = "#F7F3EC";
        public const string Surface = "#FFFFFF";
        public const string Border = "#E8E3D8";
        public const string BorderStrong = "#D6D0C2";
        public const string Ink = "#1F2A24";
        public const string Muted = "#5F6B62";
        public const string Danger = "#B3312B";
        public const string DangerSoft = "#F8E1DF";
        public const string Info = "#2F4B9C";
        public const string InfoSoft = "#E1E8F8";
        public const string Disabled = "#E6E2D8";

        // Colours that were typed directly into the drawing code in the original; now named, value unchanged.
        public const string NeutralBadge = "#ECE8DE";
        public const string ToggleTrack = "#EDEAE0";
        public const string UnreadTint = "#FAF6E8";

        // ---- The one accessibility adjustment ----------------------------------------------------
        /// <summary>Original value was #B9761A (3.35:1 on the page, 3.17:1 on its own soft tint). Same hue and saturation, lightness lowered just enough for 4.5:1 on every surface it sits on.</summary>
        public const string MarigoldText = "#955F15";
        public const string MarigoldTextOriginal = "#B9761A";

        public sealed class Adjustment
        {
            public string Token, Original, Adjusted, Reason;
            public Adjustment(string token, string original, string adjusted, string reason) { Token = token; Original = original; Adjusted = adjusted; Reason = reason; }
        }

        /// <summary>Every colour value that differs from the original design. Keep this list short.</summary>
        public static readonly Adjustment[] Adjustments =
        {
            new Adjustment("MarigoldText", MarigoldTextOriginal, MarigoldText,
                "Small warning/accent text (Pending badges, 'Needs action', low stock) measured 3.17-3.70:1; WCAG AA needs 4.5:1 for text under 18.66px bold. Weight and size cannot fix text this small, so only the lightness was lowered.")
        };

        /// <summary>All brand colours, by name. Used by the identity test.</summary>
        public static readonly Dictionary<string, string> All = new Dictionary<string, string>
        {
            {"Forest", Forest}, {"ForestHover", ForestHover}, {"Deep", Deep}, {"TitleBar", TitleBar}, {"IconGreen", IconGreen},
            {"SidebarActive", SidebarActive}, {"SidebarText", SidebarText}, {"Moss", Moss}, {"MossLight", MossLight},
            {"Marigold", Marigold}, {"MarigoldHover", MarigoldHover}, {"MarigoldSoft", MarigoldSoft}, {"MarigoldText", MarigoldText},
            {"OnMarigold", OnMarigold}, {"Background", Background}, {"Surface", Surface}, {"Border", Border}, {"BorderStrong", BorderStrong},
            {"Ink", Ink}, {"Muted", Muted}, {"Danger", Danger}, {"DangerSoft", DangerSoft}, {"Info", Info}, {"InfoSoft", InfoSoft},
            {"Disabled", Disabled}, {"NeutralBadge", NeutralBadge}, {"ToggleTrack", ToggleTrack}, {"UnreadTint", UnreadTint}
        };

        // ---- Contrast maths (WCAG 2.x relative luminance) ---------------------------------------
        public static double Luminance(string hex)
        {
            int r, g, b; Parse(hex, out r, out g, out b);
            return 0.2126 * Lin(r) + 0.7152 * Lin(g) + 0.0722 * Lin(b);
        }

        public static double Contrast(string foreground, string background)
        {
            double a = Luminance(foreground), b = Luminance(background);
            if (a < b) { double t = a; a = b; b = t; }
            return (a + 0.05) / (b + 0.05);
        }

        private static double Lin(int v)
        {
            double c = v / 255.0;
            return c <= 0.03928 ? c / 12.92 : Math.Pow((c + 0.055) / 1.055, 2.4);
        }

        private static void Parse(string hex, out int r, out int g, out int b)
        {
            string h = hex.TrimStart('#');
            r = int.Parse(h.Substring(0, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            g = int.Parse(h.Substring(2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            b = int.Parse(h.Substring(4, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
        }
    }
}
