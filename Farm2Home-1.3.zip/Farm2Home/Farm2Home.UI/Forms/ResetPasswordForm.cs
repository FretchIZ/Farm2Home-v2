using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Application;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Forms
{
    /// <summary>"Forgot password?" dialog. The person proves it is their account with the contact number saved on it, then sets a new password.</summary>
    internal sealed class ResetPasswordForm : Form
    {
        private readonly InputBox _email = new InputBox { MaxLength = 150, Placeholder = "you@email.com" };
        private readonly InputBox _phone = new InputBox { MaxLength = 20, Placeholder = "The number saved on your account" };
        private readonly InputBox _password = new InputBox { MaxLength = 128 };
        private readonly InputBox _confirm = new InputBox { MaxLength = 128 };
        private readonly AutoLabel _error = Ui.Text("", 10f, FontStyle.Bold, Theme.Danger);
        private readonly VStack _stack = new VStack();

        public string Email { get { return _email.Text.Trim(); } }

        public ResetPasswordForm(string email)
        {
            Text = "Reset your password";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            Font = Theme.Body(10f);

            _email.Text = email ?? "";
            _password.EnablePasswordToggle();
            _confirm.EnablePasswordToggle();
            _error.Visible = false;

            _stack.Add(Ui.Title("Reset password"), 4);
            _stack.Add(Ui.Sub("Enter your email and the contact number saved on your account, then choose a new password."), 18);
            _stack.Add(Ui.Field("Email address", _email), 12);
            _stack.Add(Ui.Field("Contact number on your account", _phone), 12);
            _stack.Add(Ui.Field("New password (8+ characters, letters and numbers)", _password), 12);
            _stack.Add(Ui.Field("Confirm new password", _confirm), 12);
            _stack.Add(_error, 10);
            var reset = Ui.Button("Reset password", BtnStyle.Accent, 416, 50);
            var cancel = Ui.Button("Cancel", BtnStyle.Outline, 416, 46);
            reset.Click += (s, e) => Reset();
            cancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; };
            _stack.AddFixed(reset, 8);
            _stack.AddFixed(cancel, 0);

            _stack.Location = new Point(32, 28);
            _stack.Width = 416;
            Controls.Add(_stack);
            ClientSize = new Size(480, _stack.Bottom + 28);
        }

        private void Reset()
        {
            if (_password.Text != _confirm.Text) { _error.Text = "Passwords do not match."; _error.Visible = true; return; }
            try
            {
                AppServices.Auth.ResetPassword(_email.Text, _phone.Text, _password.Text);
                MessageBox.Show(this, "Your password was changed. You can sign in with it now.", "Farm2Home", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (BusinessException ex) { _error.Text = ex.Message; _error.Visible = true; }
            catch (Exception ex) { UiErrors.Show(this, ex, "resetting your password"); }
        }
    }
}
