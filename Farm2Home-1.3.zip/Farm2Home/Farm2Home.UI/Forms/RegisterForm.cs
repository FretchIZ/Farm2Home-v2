using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Application;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Forms
{
    /// <summary>"Create a new account" dialog (consumer accounts only).</summary>
    internal sealed class RegisterForm : Form
    {
        private readonly InputBox _name = new InputBox { MaxLength = 150 };
        private readonly InputBox _email = new InputBox { MaxLength = 150, Placeholder = "you@email.com" };
        private readonly InputBox _phone = new InputBox { MaxLength = 20, Placeholder = "Optional" };
        private readonly InputBox _password = new InputBox { MaxLength = 128 };
        private readonly InputBox _confirm = new InputBox { MaxLength = 128 };
        private readonly AutoLabel _error = Ui.Text("", 10f, FontStyle.Bold, Theme.Danger);
        private readonly VStack _stack = new VStack();

        public string Email { get { return _email.Text.Trim(); } }

        public RegisterForm()
        {
            Text = "Create a Farm2Home account";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            Font = Theme.Body(10f);

            _password.EnablePasswordToggle();
            _confirm.EnablePasswordToggle();
            _error.Visible = false;

            _stack.Add(Ui.Title("Create account"), 4);
            _stack.Add(Ui.Sub("Sign up as a consumer to order from local cooperatives."), 20);
            _stack.Add(Ui.Field("Full name", _name), 12);
            _stack.Add(Ui.Field("Email address", _email), 12);
            _stack.Add(Ui.Field("Phone number", _phone), 12);
            _stack.Add(Ui.Field("Password (8+ characters, letters and numbers)", _password), 12);
            _stack.Add(Ui.Field("Confirm password", _confirm), 12);
            _stack.Add(_error, 10);
            var create = Ui.Button("Create account", BtnStyle.Accent, 416, 50);
            var cancel = Ui.Button("Cancel", BtnStyle.Outline, 416, 46);
            create.Click += (s, e) => Create();
            cancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; };
            _stack.AddFixed(create, 8);
            _stack.AddFixed(cancel, 0);

            _stack.Location = new Point(32, 28);
            _stack.Width = 416;
            Controls.Add(_stack);
            ClientSize = new Size(480, _stack.Bottom + 28);
        }

        private bool _busy;

        private void Create()
        {
            if (_password.Text != _confirm.Text) { _error.Text = "Passwords do not match."; _error.Visible = true; return; }
            if (_busy) return;                                  // a double click must not register twice
            _busy = true; Cursor = Cursors.WaitCursor;
            try
            {
                bool created = AppServices.Auth.RegisterConsumer(_name.Text, _email.Text, _password.Text, _phone.Text);
                MessageBox.Show(this, created ? "Your account has been created and saved. You can sign in now."
                                              : "You already have an account with this email and password. You can sign in now.",
                    "Farm2Home", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (BusinessException ex) { _error.Text = ex.Message; _error.Visible = true; }
            catch (Exception ex) { UiErrors.Show(this, ex, "creating your account"); }
            finally { _busy = false; Cursor = Cursors.Default; }
        }
    }
}
