using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application.Services;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Forms
{
    /// <summary>The one main window: sidebar + top bar + a content area where screens are swapped in.</summary>
    internal sealed class MainShellForm : ChromeForm
    {
        private readonly SessionUser _user;
        private readonly Sidebar _sidebar;
        private readonly TopBar _topBar;
        private readonly Panel _content;
        private readonly NavigationService _nav;

        /// <summary>True when the user chose Sign out (as opposed to closing the window).</summary>
        public bool LoggedOut { get; private set; }

        /// <summary>The screen switcher. Exposed so the built-in self-test can open every page and time it.</summary>
        internal NavigationService Navigation { get { return _nav; } }

        public MainShellForm() : base(true)
        {
            _user = AppServices.Session.RequireLogin();

            SuspendLayout();
            Text = "Farm2Home";
            MinimumSize = new Size(1000, 660);
            Size = new Size(1280, 800);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Background;
            Font = Theme.Body(10f);
            DoubleBuffered = true;

            bool coop = _user.Role == UserRole.Cooperative;
            _content = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };
            string city = null;
            if (_user.Role == UserRole.Consumer && !string.IsNullOrWhiteSpace(_user.DefaultAddress))
            {
                var parts = _user.DefaultAddress.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToArray();
                city = parts.Length >= 3 ? parts[2] : parts.LastOrDefault();
            }
            _topBar = new TopBar(coop ? "Search orders, products..." : "Search fresh produce, cooperatives...",
                                 GraphicsUtil.Initials(_user.FullName), city);
            _sidebar = new Sidebar();

            // Docking order: Fill first, then Top (top bar), then Left (sidebar), and the title bar last so it spans the full width.
            Controls.Add(_content);
            Controls.Add(_topBar);
            Controls.Add(_sidebar);
            Controls.SetChildIndex(Bar, Controls.Count - 1);   // back of the z-order = docked first = full width

            _nav = new NavigationService(_content);
            ViewRegistry.RegisterAll(_nav);

            _sidebar.SetUser(_user.FullName, _user.Role.ToString());
            _sidebar.SetItems(BuildMenu(_user.Role));
            _sidebar.NavigateRequested += id => _nav.NavigateRoot(id);
            _sidebar.LogoutRequested += OnLogout;
            _topBar.SearchSubmitted += OnSearch;
            _nav.Navigated += id => { _sidebar.SetActive(ViewInfo.NavGroup(id)); RefreshBadges(); };
            _nav.CartChanged += RefreshBadges;

            ResumeLayout(true);
            Shown += (s, e) => _nav.NavigateRoot(ViewInfo.HomeFor(_user.Role));
        }

        private static List<NavEntry> BuildMenu(UserRole role)
        {
            switch (role)
            {
                case UserRole.Cooperative:
                    return new List<NavEntry>
                    {
                        new NavEntry(ViewId.CoopDashboard, "Dashboard", Icons.Dashboard),
                        new NavEntry(ViewId.CoopProducts, "My products", Icons.Products),
                        new NavEntry(ViewId.CoopOrders, "Orders", Icons.Orders),
                        new NavEntry(ViewId.CoopEarnings, "Earnings", Icons.Earnings),
                        new NavEntry(ViewId.CoopMessages, "Messages", Icons.Mail),
                        new NavEntry(ViewId.CoopProfile, "Coop profile", Icons.Cooperatives)
                    };
                case UserRole.Administrator:
                    return new List<NavEntry>
                    {
                        new NavEntry(ViewId.Browse, "Browse", Icons.Browse),
                        new NavEntry(ViewId.Cooperatives, "Cooperatives", Icons.Cooperatives),
                        new NavEntry(ViewId.Profile, "Profile", Icons.Profile)
                    };
                default:
                    return new List<NavEntry>
                    {
                        new NavEntry(ViewId.Home, "Home", Icons.Home),
                        new NavEntry(ViewId.Browse, "Browse", Icons.Browse),
                        new NavEntry(ViewId.Cart, "Cart", Icons.Cart),
                        new NavEntry(ViewId.Orders, "Orders", Icons.Orders),
                        new NavEntry(ViewId.Cooperatives, "Cooperatives", Icons.Cooperatives),
                        new NavEntry(ViewId.Profile, "Profile", Icons.Profile)
                    };
            }
        }

        private void OnSearch(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            _nav.NavigateRoot(_user.Role == UserRole.Cooperative ? ViewId.CoopProducts : ViewId.Browse, text);
        }

        private void OnLogout()
        {
            if (!UiErrors.Confirm(this, "Sign out of Farm2Home?")) return;
            AppServices.Auth.Logout();
            LoggedOut = true;
            Close();
        }

        private void RefreshBadges()
        {
            try
            {
                if (_user.Role == UserRole.Consumer)
                    _sidebar.SetBadge(ViewId.Cart, AppServices.Cart.GetCart().Items.Count);
                else if (_user.Role == UserRole.Cooperative)
                {
                    _sidebar.SetBadge(ViewId.CoopOrders, AppServices.ProductManagement.GetStats().PendingOrders);
                    _sidebar.SetBadge(ViewId.CoopMessages, AppServices.Engagement.UnreadCount());
                }
            }
            catch (Exception ex)
            {
                if (AppServices.Logger != null) AppServices.Logger.Error(ex, "Refreshing sidebar badges");
            }
        }
    }
}
