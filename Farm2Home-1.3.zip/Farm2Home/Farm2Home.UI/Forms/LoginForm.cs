using System;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Farm2Home.Application;
using Farm2Home.Infrastructure.Data;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.Infrastructure.Security;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Forms
{
    /// <summary>Screen 01: sign in. Credentials are checked against the database; nothing is hard-coded.</summary>
    internal sealed class LoginForm : ChromeForm
    {
        private static readonly string RememberFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Farm2Home", "remember.txt");

        private readonly Panel _left, _right;
        private Farm2Home.Application.DTOs.PublicStats _stats;
        private readonly VStack _form = new VStack();
        private readonly SegmentedToggle _type = new SegmentedToggle("Consumer", "Cooperative") { Height = 44 };
        private readonly InputBox _email = new InputBox { Placeholder = "you@email.com", MaxLength = 150 };
        private readonly InputBox _password = new InputBox { Placeholder = "Enter your password", MaxLength = 128 };
        private readonly CheckBox _remember = Ui.Check("Keep me signed in");
        private readonly AutoLabel _error = Ui.Text("", 10.5f, FontStyle.Bold, Theme.Danger);
        private readonly FlatButton _signIn = Ui.Button("Sign in", BtnStyle.Accent, 440, 48);

        private readonly Task<DatabaseSetupResult> _setup;
        private bool _ready;
        private readonly AutoLabel _status = Ui.Text("Preparing your data\u2026", 9.5f, FontStyle.Regular, Theme.Muted);

        public LoginForm(Task<DatabaseSetupResult> setup)
            : base(false)
        {
            _setup = setup;
            Text = "Farm2Home \u2014 Sign in";
            ClientSize = new Size(1280, 800);
            MinimumSize = new Size(1000, 700);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Background;
            Font = Theme.Body(10f);

            _left = new Panel { Dock = DockStyle.Left, BackColor = Theme.Forest };
            _left.Paint += PaintLeft;
            _right = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };

            BuildForm();
            _right.Controls.Add(_form);
            Controls.Add(_right);
            Controls.Add(_left);
            Bar.SendToBack();

            Resize += (s, e) => LayoutSides();
            _right.Resize += (s, e) => PlaceForm();
            _form.SizeChanged += (s, e) => PlaceForm();
            LayoutSides();
            LoadRemembered();
            _signIn.Enabled = false;
            Shown += (s, e) =>
            {
                (string.IsNullOrEmpty(_email.Text) ? _email : _password).Inner.Focus();
                _form.Relayout(); PlaceForm();
                WaitForDatabase();
            };
        }

        /// <summary>The window is already visible; the database check runs in the background and unlocks Sign in when finished.</summary>
        private void WaitForDatabase()
        {
            var ui = TaskScheduler.FromCurrentSynchronizationContext();
            _setup.ContinueWith(t =>
            {
                if (IsDisposed) return;
                DatabaseSetupResult r = t.IsFaulted ? new DatabaseSetupResult { UserMessage = "Farm2Home could not prepare its data.", Technical = t.Exception.GetBaseException().Message } : t.Result;
                if (!r.Success)
                {
                    _status.Text = r.UserMessage;
                    _status.ForeColor = Theme.Danger;
                    MessageBox.Show(this, r.UserMessage + "\n\nDetails (press Ctrl+C to copy):\n" + r.Technical +
                                    "\n\nThe full log is saved at:\n" + Farm2Home.Infrastructure.Data.FileLogger.LogFilePath, "Farm2Home", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.Abort;
                    return;
                }
                try { _stats = AppServices.PublicInfo.GetStats(); } catch { /* totals are decorative */ }
                _ready = true;
                _status.Visible = false;
                _signIn.Enabled = true;
                _left.Invalidate();
            }, CancellationToken.None, TaskContinuationOptions.None, ui);
        }

        private void BuildForm()
        {
            _form.Add(new AutoLabel { Text = "Welcome back", Font = Theme.Heading(26f), ForeColor = Theme.Ink }, 4);
            _form.Add(Ui.Sub("Sign in to continue to your account."), 24);
            _form.Add(_type, 22);
            _form.Add(Ui.Field("Email address", _email), 14);
            _password.EnablePasswordToggle();
            _form.Add(Ui.Field("Password", _password), 10);

            _remember.Width = 220;
            var forgot = Ui.Button("Forgot password?", BtnStyle.Ghost, 170, 30);
            forgot.Click += (s, e) =>
            {
                if (!_ready) return;
                using (var r = new ResetPasswordForm(_email.Text))
                    if (r.ShowDialog(this) == DialogResult.OK) { _email.Text = r.Email; _password.Text = ""; _password.Inner.Focus(); }
            };
            _form.Add(Ui.Buttons(_remember, forgot), 10);

            _error.Visible = false;
            _form.Add(_error, 10);

            _signIn.Click += (s, e) => DoLogin();
            _form.AddFixed(_signIn, 8);
            _form.Add(_status, 14);
            _email.EnterPressed += DoLogin;
            _password.EnterPressed += DoLogin;

            _form.Add(new AutoLabel { Text = "OR", ForeColor = Theme.Muted, Font = Theme.Body(9.5f), TextAlign = ContentAlignment.MiddleCenter }, 12);
            var create = Ui.Button("Create a new account", BtnStyle.Outline, 440, 46);
            create.Click += (s, e) => Register();
            _form.AddFixed(create, 10);

            if (string.Equals(ConfigurationManager.AppSettings["SeedDemoAccounts"], "true", StringComparison.OrdinalIgnoreCase))
            {
                var demo = Ui.Button("Fill demo account (testing only)", BtnStyle.Ghost, 440, 40);
                demo.Click += (s, e) =>
                {
                    _email.Text = _type.SelectedIndex == 0 ? DemoAccounts.ConsumerEmail : DemoAccounts.CooperativeEmail;
                    _password.Text = DemoAccounts.Password;
                };
                _form.AddFixed(demo, 10);
            }
            _form.Add(Ui.Text("By continuing you agree to Farm2Home's Terms and Privacy Policy.", 9.5f, FontStyle.Regular, Theme.Muted), 0);
        }

        private void LayoutSides()
        {
            _left.Width = Math.Max(380, ClientSize.Width * 45 / 100);
            PlaceForm();
        }

        private void PlaceForm()
        {
            int w = Math.Max(300, Math.Min(440, _right.ClientSize.Width - 64));
            if (_form.Width != w) _form.Width = w;
            int top = Math.Max(24, (_right.ClientSize.Height - _form.Height) / 2);
            _form.Location = new Point((_right.ClientSize.Width - w) / 2, top);
        }

        private void PaintLeft(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            int w = _left.Width, h = _left.Height;
            using (var b = new SolidBrush(Color.FromArgb(160, Theme.Moss))) g.FillEllipse(b, w - 260, -150, 400, 400);
            using (var b = new SolidBrush(Color.FromArgb(120, Theme.SidebarActive))) g.FillEllipse(b, w - 240, h - 330, 420, 420);

            TextRenderer.DrawText(g, "Farm2Home", Theme.Heading(20f), new Rectangle(64, 40, w - 128, 44), Color.White,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            // The headline shrinks until it fits, so it is never clipped in a small or scaled window.
            const string headline = "Local harvest.\nDirect to your home.";
            var wrap = TextFormatFlags.Left | TextFormatFlags.Bottom | TextFormatFlags.WordBreak | TextFormatFlags.NoPadding;
            int boxW = Math.Max(200, w - 128), maxH = Math.Max(110, h * 28 / 100);
            float fs = 40f;
            Font hf = Theme.Heading(fs);
            while (fs > 18f && TextRenderer.MeasureText(g, headline, hf, new Size(boxW, 10000), wrap).Height > maxH)
            { fs -= 2f; hf.Dispose(); hf = Theme.Heading(fs); }
            int bottom = Math.Max(maxH + 70, h / 2 + 30);
            TextRenderer.DrawText(g, headline, hf, new Rectangle(64, bottom - maxH, boxW, maxH), Color.White, wrap);
            hf.Dispose();
            TextRenderer.DrawText(g, "Order fresh, organic produce straight from Philippine farmer cooperatives \u2014 fair prices for growers, honest prices for you.",
                Theme.Body(12f), new Rectangle(64, bottom + 22, Math.Min(boxW, 520), 110), Color.FromArgb(225, 238, 230),
                TextFormatFlags.Left | TextFormatFlags.Top | TextFormatFlags.WordBreak | TextFormatFlags.NoPadding);
            PaintStats(g, w, h);
        }

        private void PaintStats(Graphics g, int w, int h)
        {
            if (_stats == null) { _stats = new Farm2Home.Application.DTOs.PublicStats(); if (!_ready) return; }
            var items = new[]
            {
                new[] { _stats.Cooperatives.ToString(), "Cooperatives onboard" },
                new[] { _stats.Products.ToString(), "Products listed" },
                new[] { "0%", "Middleman markup" }
            };
            int colW = (w - 128) / 3;
            for (int i = 0; i < items.Length; i++)
            {
                int x = 64 + i * colW;
                using (var pen = new Pen(Color.FromArgb(70, 255, 255, 255))) g.DrawLine(pen, x, h - 150, x + colW - 24, h - 150);
                TextRenderer.DrawText(g, items[i][0], Theme.Heading(24f), new Rectangle(x, h - 140, colW - 24, 44), Color.White,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, items[i][1], Theme.Body(10.5f), new Rectangle(x, h - 94, colW - 24, 26), Color.FromArgb(215, 232, 222),
                    TextFormatFlags.Left | TextFormatFlags.Top | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis);
            }
        }

        private void LoadRemembered()
        {
            try
            {
                if (!File.Exists(RememberFile)) return;
                var lines = File.ReadAllLines(RememberFile);
                if (lines.Length > 0) { _email.Text = lines[0]; _remember.Checked = true; }
                int idx;
                if (lines.Length > 1 && int.TryParse(lines[1], out idx) && idx >= 0 && idx <= 1) _type.SelectedIndex = idx;
            }
            catch { /* remembering the email is optional */ }
        }

        private void SaveRemembered()
        {
            try
            {
                if (_remember.Checked)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(RememberFile));
                    File.WriteAllLines(RememberFile, new[] { _email.Text.Trim(), _type.SelectedIndex.ToString() });
                }
                else if (File.Exists(RememberFile)) File.Delete(RememberFile);
            }
            catch { }
        }

        private void DoLogin()
        {
            if (!_ready) return;
            _error.Visible = false;
            _signIn.Enabled = false;
            Cursor = Cursors.WaitCursor;
            try
            {
                var role = _type.SelectedIndex == 0 ? UserRole.Consumer : UserRole.Cooperative;
                AppServices.Auth.Login(_email.Text, _password.Text, role);
                SaveRemembered();
                DialogResult = DialogResult.OK;
            }
            catch (BusinessException ex)
            {
                _error.Text = ex.Message;
                _error.Visible = true;
                _password.Text = "";
                _password.Inner.Focus();
            }
            catch (Exception ex) { UiErrors.Show(this, ex, "signing in"); }
            finally { Cursor = Cursors.Default; _signIn.Enabled = true; }
        }

        private void Register()
        {
            using (var r = new RegisterForm())
            {
                if (r.ShowDialog(this) != DialogResult.OK) return;
                _type.SelectedIndex = 0;
                _email.Text = r.Email;
                _password.Text = "";
                _password.Inner.Focus();
            }
        }
    }
}
