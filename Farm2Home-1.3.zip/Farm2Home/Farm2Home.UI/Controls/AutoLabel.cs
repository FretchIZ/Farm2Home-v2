using System;
using System.Drawing;
using System.Windows.Forms;

namespace Farm2Home.UI.Controls
{
    /// <summary>Label that wraps its text and grows in height to fit whatever width it is given.</summary>
    internal class AutoLabel : Label
    {
        private bool _fitting;
        public bool SingleLine { get; set; }

        public AutoLabel()
        {
            AutoSize = false;
            UseMnemonic = false;
            BackColor = Color.Transparent;
            ForeColor = Theme.Ink;
            Font = Theme.Body(10.5f);
        }

        protected override void OnTextChanged(EventArgs e) { base.OnTextChanged(e); Fit(); }
        protected override void OnResize(EventArgs e) { base.OnResize(e); Fit(); }
        protected override void OnFontChanged(EventArgs e) { base.OnFontChanged(e); Fit(); }

        private void Fit()
        {
            if (_fitting || Width <= 0) return;
            _fitting = true;
            try
            {
                var flags = TextFormatFlags.NoPadding | (SingleLine ? TextFormatFlags.SingleLine : TextFormatFlags.WordBreak);
                int h = TextRenderer.MeasureText(string.IsNullOrEmpty(Text) ? " " : Text, Font, new Size(Width, int.MaxValue), flags).Height + 2;
                if (h != Height) Height = h;
            }
            finally { _fitting = false; }
        }
    }
}
