using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>The dark window bar from the wireframes: mark + "Farm2Home" on the left, minimise / maximise / close on the right. Drag it to move the window.</summary>
    internal sealed class TitleBar : Control
    {
        public const int BarHeight = 36;
        private readonly Form _form;
        private int _hot = -1;          // 0 = minimise, 1 = maximise, 2 = close
        private readonly bool _canMaximize;

        public TitleBar(Form form, bool canMaximize)
        {
            _form = form; _canMaximize = canMaximize;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Dock = DockStyle.Top; Height = BarHeight; BackColor = Theme.TitleBar;
        }

        private Rectangle ButtonRect(int i) { return new Rectangle(Width - 46 * (3 - i), 0, 46, Height); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            g.Clear(Theme.TitleBar);
            IconPainter.DrawMark(g, new Rectangle(14, 11, 16, 16), Color.White);
            TextRenderer.DrawText(g, "Farm2Home", Theme.Body(9.5f, FontStyle.Bold), new Rectangle(38, 0, 300, Height), Color.White,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);

            var ink = Color.FromArgb(200, 220, 208);
            for (int i = 0; i < 3; i++)
            {
                if (i == 1 && !_canMaximize) continue;
                var r = ButtonRect(i);
                if (_hot == i) using (var b = new SolidBrush(i == 2 ? Color.FromArgb(196, 52, 46) : Color.FromArgb(40, 255, 255, 255))) g.FillRectangle(b, r);
                float cx = r.X + r.Width / 2f, cy = r.Y + r.Height / 2f;
                using (var pen = new Pen(_hot == i && i == 2 ? Color.White : ink, 1.3f))
                {
                    if (i == 0) g.DrawLine(pen, cx - 5, cy, cx + 5, cy);
                    else if (i == 1) g.DrawRectangle(pen, cx - 5, cy - 5, 10, 10);
                    else { g.DrawLine(pen, cx - 5, cy - 5, cx + 5, cy + 5); g.DrawLine(pen, cx + 5, cy - 5, cx - 5, cy + 5); }
                }
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int hot = -1;
            for (int i = 0; i < 3; i++) if (ButtonRect(i).Contains(e.Location) && (i != 1 || _canMaximize)) hot = i;
            if (hot != _hot) { _hot = hot; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { _hot = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            if (_hot == 0) { _form.WindowState = FormWindowState.Minimized; return; }
            if (_hot == 1) { ToggleMax(); return; }
            if (_hot == 2) { _form.Close(); return; }
            if (e.Clicks == 2 && _canMaximize) { ToggleMax(); return; }
            if (_form.WindowState == FormWindowState.Normal)
                try { ReleaseCapture(); SendMessage(_form.Handle, 0xA1, (IntPtr)2, IntPtr.Zero); } catch (Exception) { /* dragging is a convenience */ }
        }

        private void ToggleMax()
        {
            var chrome = _form as ChromeForm;
            if (chrome != null) chrome.ToggleMaximize();
        }

        [DllImport("user32.dll")] private static extern bool ReleaseCapture();
        [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
    }

    /// <summary>A window without the Windows title bar: it draws the wireframe's dark TitleBar and can still be resized from its edges.</summary>
    internal class ChromeForm : Form
    {
        protected readonly TitleBar Bar;
        private const int Grip = 6;

        public ChromeForm(bool canMaximize)
        {
            FormBorderStyle = FormBorderStyle.None;
            DoubleBuffered = true;
            Bar = new TitleBar(this, canMaximize);
            Controls.Add(Bar);
        }

        public void ToggleMaximize()
        {
            MaximizedBounds = Screen.FromControl(this).WorkingArea;      // keeps the taskbar visible
            WindowState = WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_NCHITTEST = 0x84;
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST && WindowState == FormWindowState.Normal && (int)m.Result == 1)
            {
                var p = PointToClient(new Point((short)((long)m.LParam & 0xFFFF), (short)(((long)m.LParam >> 16) & 0xFFFF)));
                bool l = p.X < Grip, r = p.X >= ClientSize.Width - Grip, t = p.Y < Grip, b = p.Y >= ClientSize.Height - Grip;
                if (l && t) m.Result = (IntPtr)13; else if (r && t) m.Result = (IntPtr)14;
                else if (l && b) m.Result = (IntPtr)16; else if (r && b) m.Result = (IntPtr)17;
                else if (l) m.Result = (IntPtr)10; else if (r) m.Result = (IntPtr)11;
                else if (t) m.Result = (IntPtr)12; else if (b) m.Result = (IntPtr)15;
            }
        }

        protected override CreateParams CreateParams
        {
            get { var cp = base.CreateParams; cp.Style |= 0x20000 | 0x10000; cp.ClassStyle |= 0x20000; return cp; }   // keep minimise/maximise from the taskbar and a drop shadow
        }
    }
}
