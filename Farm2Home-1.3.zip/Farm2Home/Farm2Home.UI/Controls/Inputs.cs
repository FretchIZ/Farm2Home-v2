using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Rounded text field with optional placeholder and show/hide password link.</summary>
    internal class InputBox : RoundedPanel
    {
        private readonly bool _multi;
        private Label _toggle;
        private string _placeholder;

        public TextBox Inner { get; private set; }
        public event Action EnterPressed;

        public InputBox(bool multiline = false)
        {
            _multi = multiline;
            Radius = 8;
            FillColor = Theme.Background;
            BorderColor = Theme.ControlBorder;
            Height = multiline ? 84 : 36;
            Inner = new TextBox
            {
                BorderStyle = BorderStyle.None, BackColor = Theme.Background, ForeColor = Theme.Ink,
                Font = Theme.Body(10f), Multiline = multiline, AcceptsReturn = multiline,
                ScrollBars = multiline ? ScrollBars.Vertical : ScrollBars.None
            };
            Inner.GotFocus += (s, e) => { BorderColor = Theme.FocusRing; BorderWidth = 2f; Invalidate(); };
            Inner.LostFocus += (s, e) => { BorderColor = Theme.ControlBorder; BorderWidth = 1f; Invalidate(); };
            Inner.KeyDown += (s, e) =>
            {
                if (_multi || e.KeyCode != Keys.Enter) return;
                e.SuppressKeyPress = true;
                if (EnterPressed != null) EnterPressed();
            };
            Inner.HandleCreated += (s, e) => ApplyPlaceholder();
            Controls.Add(Inner);
            Click += (s, e) => Inner.Focus();
            DoLayout();
        }

        public override string Text { get { return Inner == null ? "" : Inner.Text; } set { if (Inner != null) Inner.Text = value; } }
        public int MaxLength { get { return Inner.MaxLength; } set { Inner.MaxLength = value; } }
        public bool ReadOnly { get { return Inner.ReadOnly; } set { Inner.ReadOnly = value; } }

        public string Placeholder { get { return _placeholder; } set { _placeholder = value; ApplyPlaceholder(); } }
        private void ApplyPlaceholder() { if (!_multi && _placeholder != null) NativeMethods.SetPlaceholder(Inner, _placeholder); }

        public void EnablePasswordToggle()
        {
            Inner.UseSystemPasswordChar = true;
            _toggle = new Label
            {
                Text = "Show", AutoSize = true, Cursor = Cursors.Hand, ForeColor = Theme.Forest,
                Font = Theme.Body(9.5f, FontStyle.Bold), BackColor = Theme.Background
            };
            _toggle.Click += (s, e) =>
            {
                Inner.UseSystemPasswordChar = !Inner.UseSystemPasswordChar;
                _toggle.Text = Inner.UseSystemPasswordChar ? "Show" : "Hide";
                DoLayout();
            };
            Controls.Add(_toggle);
            DoLayout();
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); DoLayout(); }

        private void DoLayout()
        {
            if (Inner == null) return;
            int right = 14 + (_toggle != null ? _toggle.Width + 8 : 0);
            Inner.Left = 14;
            Inner.Width = Math.Max(10, Width - 14 - right);
            if (_multi) { Inner.Top = 12; Inner.Height = Math.Max(20, Height - 24); }
            else Inner.Top = Math.Max(0, (Height - Inner.Height) / 2);
            if (_toggle != null) _toggle.Location = new Point(Width - _toggle.Width - 14, Math.Max(0, (Height - _toggle.Height) / 2));
        }
    }

    internal class SelectOption
    {
        public object Value { get; private set; }
        public string Text { get; private set; }
        public SelectOption(object value, string text) { Value = value; Text = text; }
        public override string ToString() { return Text; }
    }

    /// <summary>Rounded drop-down list.</summary>
    internal class SelectBox : RoundedPanel
    {
        private bool _loading;
        public ComboBox Inner { get; private set; }
        public event Action SelectionChanged;

        public SelectBox()
        {
            Radius = 8; FillColor = Theme.Background; BorderColor = Theme.ControlBorder; Height = 36;
            Inner = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat,
                BackColor = Theme.Background, ForeColor = Theme.Ink, Font = Theme.Body(10f)
            };
            Inner.SelectedIndexChanged += (s, e) => { if (!_loading && SelectionChanged != null) SelectionChanged(); };
            Inner.GotFocus += (s, e) => { BorderColor = Theme.FocusRing; BorderWidth = 2f; Invalidate(); };
            Inner.LostFocus += (s, e) => { BorderColor = Theme.ControlBorder; BorderWidth = 1f; Invalidate(); };
            Controls.Add(Inner);
            DoLayout();
        }

        public object SelectedValue
        {
            get { var o = Inner.SelectedItem as SelectOption; return o == null ? null : o.Value; }
        }

        public void SetOptions(IEnumerable<SelectOption> options, object select = null)
        {
            _loading = true;
            try
            {
                Inner.Items.Clear();
                int idx = 0, i = 0;
                foreach (var o in options)
                {
                    Inner.Items.Add(o);
                    if (object.Equals(o.Value, select)) idx = i;
                    i++;
                }
                if (Inner.Items.Count > 0) Inner.SelectedIndex = idx;
            }
            finally { _loading = false; }
        }

        public void Select(object value)
        {
            _loading = true;
            try
            {
                for (int i = 0; i < Inner.Items.Count; i++)
                    if (object.Equals(((SelectOption)Inner.Items[i]).Value, value)) { Inner.SelectedIndex = i; return; }
                if (Inner.Items.Count > 0) Inner.SelectedIndex = 0;
            }
            finally { _loading = false; }
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); DoLayout(); }

        private void DoLayout()
        {
            if (Inner == null) return;
            Inner.SetBounds(10, Math.Max(0, (Height - Inner.Height) / 2), Math.Max(10, Width - 20), Inner.Height);
        }
    }

    /// <summary>[ - 2 kg + ] with limits. Raises LimitReached when the user tries to go above Max.</summary>
    internal class QuantitySelector : Control
    {
        private int _value = 1;
        public int Min { get; set; } = 1;
        public int Max { get; set; } = 99;
        public string Unit { get; set; } = "";
        /// <summary>Cart style: smaller, with grey end buttons and a white number cell.</summary>
        public bool Compact { get; set; }
        public event EventHandler ValueChanged;
        public event Action LimitReached;

        public QuantitySelector()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Cursor = Cursors.Hand;
            TabStop = true;
            Size = new Size(116, 40);
            Font = Theme.Body(10f, FontStyle.Bold);
        }

        public int Value
        {
            get { return _value; }
            set
            {
                int v = Math.Max(Min, Math.Min(Max, value));
                if (v == _value) { Invalidate(); return; }
                _value = v;
                Invalidate();
                if (ValueChanged != null) ValueChanged(this, EventArgs.Empty);
            }
        }

        private void Step(int d)
        {
            int n = _value + d;
            if (n > Max) { if (LimitReached != null) LimitReached(); return; }
            if (n < Min) return;
            Value = n;
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            Focus();
            int bw = Compact ? 30 : 40;
            if (e.X < bw) Step(-1); else if (e.X > Width - bw) Step(1);
            base.OnMouseClick(e);
        }

        protected override bool IsInputKey(Keys keyData)
        {
            return keyData == Keys.Left || keyData == Keys.Right || keyData == Keys.Up || keyData == Keys.Down || base.IsInputKey(keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Down) Step(-1);
            else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Up) Step(1);
            base.OnKeyDown(e);
        }

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            var flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding;
            Color minus = _value <= Min ? Theme.BorderStrong : Theme.Ink, plus = _value >= Max ? Theme.BorderStrong : Theme.Ink;
            using (var path = GraphicsUtil.RoundedRect(new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f), 8))
            using (var fill = new SolidBrush(Theme.Surface))
            using (var pen = new Pen(Focused && ShowFocusCues ? Theme.FocusRing : Theme.ControlBorder, Focused && ShowFocusCues ? 2f : 1f))
            {
                g.FillPath(fill, path);
                if (Compact)
                {
                    var st = g.Save(); g.SetClip(path);
                    using (var seg = new SolidBrush(Theme.Background)) { g.FillRectangle(seg, 0, 0, 30, Height); g.FillRectangle(seg, Width - 30, 0, 30, Height); }
                    g.Restore(st);
                }
                g.DrawPath(pen, path);
            }
            int bw = Compact ? 30 : 40;
            IconPainter.Draw(g, Icons.Minus, new Rectangle((bw - 12) / 2, (Height - 12) / 2, 12, 12), minus, 1.6f);
            IconPainter.Draw(g, Icons.Plus, new Rectangle(Width - bw + (bw - 12) / 2, (Height - 12) / 2, 12, 12), plus, 1.6f);
            TextRenderer.DrawText(g, _value + (string.IsNullOrEmpty(Unit) ? "" : " " + Unit), Font,
                new Rectangle(bw, 0, Width - 2 * bw, Height), Theme.Ink, flags | TextFormatFlags.EndEllipsis);
        }
    }

    /// <summary>Two-or-more option pill switch (Consumer | Cooperative).</summary>
    internal class SegmentedToggle : Control
    {
        private readonly string[] _options;
        private int _selected;
        public event Action SelectedChanged;

        public SegmentedToggle(params string[] options)
        {
            _options = options;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Cursor = Cursors.Hand;
            TabStop = true;
            Height = 56;
            Font = Theme.Body(10.5f, FontStyle.Bold);
        }

        public int SelectedIndex
        {
            get { return _selected; }
            set { if (value == _selected) return; _selected = value; Invalidate(); if (SelectedChanged != null) SelectedChanged(); }
        }

        protected override bool IsInputKey(Keys keyData) { return keyData == Keys.Left || keyData == Keys.Right || base.IsInputKey(keyData); }
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) { SelectedIndex = Math.Max(0, _selected - 1); e.Handled = true; }
            else if (e.KeyCode == Keys.Right) { SelectedIndex = Math.Min(_options.Length - 1, _selected + 1); e.Handled = true; }
            base.OnKeyDown(e);
        }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            Focus();
            SelectedIndex = Math.Max(0, Math.Min(_options.Length - 1, (int)(e.X / (Width / (float)_options.Length))));
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            using (var track = GraphicsUtil.RoundedRect(new RectangleF(0, 0, Width - 1, Height - 1), 14))
            using (var tb = new SolidBrush(Theme.ToggleTrack)) g.FillPath(tb, track);
            if (Focused && ShowFocusCues) using (var fp = GraphicsUtil.RoundedRect(new RectangleF(1, 1, Width - 3, Height - 3), 14)) using (var pen = new Pen(Theme.FocusRing, 2f)) g.DrawPath(pen, fp);
            float w = (Width - 1) / (float)_options.Length;
            for (int i = 0; i < _options.Length; i++)
            {
                var r = new RectangleF(i * w + 6, 6, w - 12, Height - 13);
                if (i == _selected)
                    using (var p = GraphicsUtil.RoundedRect(r, 10))
                    {
                        using (var b = new SolidBrush(Theme.Surface)) g.FillPath(b, p);
                        using (var o = new Pen(Theme.Forest, 1.5f)) g.DrawPath(o, p);      // selected = outlined, not just lighter
                    }
                TextRenderer.DrawText(g, _options[i], Font, Rectangle.Round(r), i == _selected ? Theme.Deep : Theme.Muted,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
        }
    }
}
