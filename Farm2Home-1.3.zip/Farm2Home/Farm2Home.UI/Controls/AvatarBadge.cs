using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Circle with the user's initials.</summary>
    internal class AvatarBadge : Control
    {
        private string _initials = "?";
        public string Initials { get { return _initials; } set { _initials = value; Invalidate(); } }
        public Color FillColor { get; set; } = Theme.Forest;
        public Color TextColor { get; set; } = Color.White;

        public AvatarBadge()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Size = new Size(44, 44);
            Font = Theme.Body(10.5f, FontStyle.Bold);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            GraphicsUtil.HighQuality(e.Graphics);
            using (var b = new SolidBrush(FillColor)) e.Graphics.FillEllipse(b, 0, 0, Width - 1, Height - 1);
            TextRenderer.DrawText(e.Graphics, _initials, Font, new Rectangle(0, 0, Width, Height), TextColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }
}
