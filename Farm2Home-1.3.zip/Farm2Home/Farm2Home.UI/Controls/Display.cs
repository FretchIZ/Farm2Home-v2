using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Domain.Enums;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Left label / right value line (order summaries, details).</summary>
    internal class PairRow : Control
    {
        private readonly string _left, _right;
        private readonly bool _bold;
        public Color RightColor { get; set; } = Theme.Ink;

        public PairRow(string left, string right, bool bold = false)
        {
            _left = left ?? ""; _right = right ?? ""; _bold = bold;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Height = bold ? 34 : 28;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var f = Theme.Body(_bold ? 12f : 10.5f, _bold ? FontStyle.Bold : FontStyle.Regular);
            var rf = Theme.Body(_bold ? 12f : 10.5f, FontStyle.Bold);
            int rw = Math.Min(Width / 2, TextRenderer.MeasureText(_right ?? "", rf).Width + 4);
            TextRenderer.DrawText(e.Graphics, _left, f, new Rectangle(0, 0, Width - rw - 8, Height), _bold ? Theme.Ink : Theme.Muted,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(e.Graphics, _right, rf, new Rectangle(Width - rw, 0, rw, Height), RightColor,
                TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
        }
    }

    /// <summary>Thin horizontal rule.</summary>
    internal class Divider : Control
    {
        public Divider() { Height = 1; BackColor = Theme.Border; }
    }

    /// <summary>Section title with an optional "See all" link on the right.</summary>
    internal class SectionHeader : Panel
    {
        private readonly AutoLabel _title;
        private readonly Label _link;
        public event Action LinkClicked;

        public SectionHeader(string title, string linkText = null)
        {
            Height = 36;
            _title = Ui.Section(title);
            _title.SingleLine = true;
            _link = new Label
            {
                Text = linkText ?? "", AutoSize = true, Cursor = Cursors.Hand, ForeColor = Theme.Forest,
                Font = Theme.Body(10.5f, FontStyle.Bold), Visible = !string.IsNullOrEmpty(linkText)
            };
            _link.Click += (s, e) => { if (LinkClicked != null) LinkClicked(); };
            Controls.Add(_title);
            Controls.Add(_link);
            Place();
        }

        protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); Place(); }

        private void Place()
        {
            if (_title == null) return;
            _title.SetBounds(0, 4, Math.Max(10, Width - 110), 28);
            _link.Location = new Point(Width - _link.Width, 8);
        }
    }

    /// <summary>Picture (or placeholder) in a rounded frame.</summary>
    internal class ImageBox : RoundedPanel
    {
        private string _file;
        public bool IsCooperative { get; set; }
        public string ImageFile { get { return _file; } set { _file = value; Invalidate(); } }

        /// <summary>Shown over the placeholder when there is no picture (e.g. "Drag a photo here, or click to browse").</summary>
        public string HintText { get; set; }

        public ImageBox() { Radius = 14; BorderColor = Color.Transparent; Height = 200; }

        protected override void OnPaint(PaintEventArgs e)
        {
            GraphicsUtil.HighQuality(e.Graphics);
            bool dropZone = !string.IsNullOrEmpty(HintText) && ImageStore.Load(_file) == null;
            if (dropZone)
            {
                using (var path = GraphicsUtil.RoundedRect(new RectangleF(0, 0, Width, Height), Radius))
                using (var b = new SolidBrush(Color.FromArgb(246, 250, 247))) e.Graphics.FillPath(b, path);
            }
            else ImagePainter.Paint(e.Graphics, new Rectangle(0, 0, Width, Height), _file, IsCooperative, Radius);
            if (dropZone)
            {
                using (var pen = new Pen(Theme.BorderStrong, 1.5f) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dash })
                using (var path = GraphicsUtil.RoundedRect(new RectangleF(1.5f, 1.5f, Width - 3f, Height - 3f), Radius)) e.Graphics.DrawPath(pen, path);
                IconPainter.Draw(e.Graphics, "upload", new Rectangle(Width / 2 - 14, Height / 2 - 40, 28, 28), Theme.IconGreen, 1.8f);
                TextRenderer.DrawText(e.Graphics, HintText, Theme.Body(10.5f, FontStyle.Bold), new Rectangle(16, Height / 2 + 6, Width - 32, 54), Theme.Ink,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.Top | TextFormatFlags.WordBreak | TextFormatFlags.NoPadding);
            }
        }
    }

    /// <summary>Dark green banner with a headline, text and an optional button.</summary>
    internal class HeroBanner : RoundedPanel
    {
        private readonly AutoLabel _eyebrow, _title, _body;
        private readonly FlatButton _button;
        private bool _busy;
        public event Action ButtonClicked;

        public HeroBanner(string eyebrow, string title, string body, string buttonText)
        {
            FillColor = Theme.Forest; BorderColor = Color.Transparent; Radius = 14; Height = 200;
            _eyebrow = Ui.Text(eyebrow, 9f, FontStyle.Bold, Theme.MarigoldHover, Theme.Forest);
            _title = new AutoLabel { Text = title, Font = Theme.Heading(17f), ForeColor = Color.White, BackColor = Theme.Forest };
            _body = Ui.Text(body, 10f, FontStyle.Regular, Color.FromArgb(230, 240, 234), Theme.Forest);
            _button = Ui.Button(buttonText ?? "", BtnStyle.Accent, 200, 36); _button.Width = TextRenderer.MeasureText(buttonText ?? "", _button.Font).Width + 40;
            _button.Visible = !string.IsNullOrEmpty(buttonText);
            _button.BackColor = Theme.Forest;
            _button.Click += (s, e) => { if (ButtonClicked != null) ButtonClicked(); };
            Controls.AddRange(new Control[] { _eyebrow, _title, _body, _button });
            DoLayout();
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); DoLayout(); }

        private void DoLayout()
        {
            if (_busy || _eyebrow == null || Width <= 0) return;
            _busy = true;
            try
            {
                int w = Math.Max(120, Math.Min(Width - 60, 480));
                _eyebrow.SetBounds(30, 27, w, 18);
                _title.SetBounds(30, 48, w, _title.Height);
                _body.SetBounds(30, _title.Bottom + 6, w, _body.Height);
                int bottom = _body.Bottom;
                if (_button.Visible) { _button.Location = new Point(30, _body.Bottom + 16); bottom = _button.Bottom; }
                int h = bottom + 28;
                if (Height != h) Height = h;
            }
            finally { _busy = false; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            using (var clip = GraphicsUtil.RoundedRect(new RectangleF(0, 0, Width - 1, Height - 1), Radius))
            {
                g.SetClip(clip);
                using (var b = new SolidBrush(Color.FromArgb(150, Theme.Moss))) g.FillEllipse(b, Width - 180, -60, 220, 220);
                g.ResetClip();
            }
        }
    }

    /// <summary>Four-step progress: Order placed, Preparing, Out for delivery, Delivered (the six database statuses map onto these).</summary>
    internal class OrderTimeline : Control
    {
        private static readonly string[] Steps = { "Order placed", "Preparing", "Out for delivery", "Delivered" };

        public OrderStatus Status { get; set; } = OrderStatus.Pending;
        public DateTime? PlacedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        public static int StepOf(OrderStatus s)
        {
            switch (s)
            {
                case OrderStatus.Preparing: case OrderStatus.ReadyForDelivery: return 1;
                case OrderStatus.OutForDelivery: return 2;
                case OrderStatus.Delivered: return 3;
                default: return 0;
            }
        }

        public OrderTimeline()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Height = 78;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            int n = Steps.Length, cur = StepOf(Status);
            float slot = Width / (float)n, y = 14f, r = 14f;
            for (int i = 0; i < n - 1; i++)
                using (var pen = new Pen(i < cur ? Theme.Forest : Theme.Border, 2f))
                    g.DrawLine(pen, slot * i + slot / 2 + r, y, slot * (i + 1) + slot / 2 - r, y);
            var center = TextFormatFlags.HorizontalCenter | TextFormatFlags.Top | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            for (int i = 0; i < n; i++)
            {
                float cx = slot * i + slot / 2;
                bool done = i <= cur;
                using (var b = new SolidBrush(done ? Theme.Forest : Theme.MossLight)) g.FillEllipse(b, cx - r, y - r, 2 * r, 2 * r);
                if (done) IconPainter.Draw(g, Icons.Check, new Rectangle((int)(cx - 7), (int)(y - 7), 14, 14), Color.White, 1.8f);
                TextRenderer.DrawText(g, Steps[i], Theme.Body(9.5f, FontStyle.Bold), new Rectangle((int)(slot * i + 4), (int)(y + r + 10), (int)slot - 8, 18), Theme.Ink, center);
                string sub = i == 0 ? (PlacedAt.HasValue ? PlacedAt.Value.ToString("MMM d, h:mm tt") : "")
                           : (i == cur && UpdatedAt.HasValue ? UpdatedAt.Value.ToString("MMM d, h:mm tt") : (i > cur ? "Pending" : ""));
                TextRenderer.DrawText(g, sub, Theme.Body(9f), new Rectangle((int)(slot * i + 4), (int)(y + r + 28), (int)slot - 8, 16), Theme.Muted, center);
            }
        }
    }
}
