using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Farm2Home.UI.Components;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Controls
{
    internal class NavEntry
    {
        public ViewId Id;
        public string Text;
        public string Glyph;
        public NavEntry(ViewId id, string text, string glyph) { Id = id; Text = text; Glyph = glyph; }
    }

    /// <summary>Left navigation: logo, role-specific menu, sign-out and the signed-in user card.</summary>
    internal sealed class Sidebar : Panel
    {
        public event Action<ViewId> NavigateRequested;
        public event Action LogoutRequested;

        private readonly FlowLayoutPanel _flow;
        private readonly Panel _footer;
        private readonly Panel _logo;
        private readonly AvatarBadge _avatar;
        private readonly Label _name, _role;
        private bool _signHot;
        private Rectangle SignRect() { return new Rectangle(_footer.Width - 40, 18, 32, 32); }
        private readonly Dictionary<ViewId, NavItem> _items = new Dictionary<ViewId, NavItem>();

        public Sidebar()
        {
            Width = 216;
            Dock = DockStyle.Left;
            BackColor = Theme.Forest;
            DoubleBuffered = true;

            _flow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = false,
                BackColor = Theme.Forest,
                Padding = new Padding(0, 4, 0, 0)
            };
            _flow.Resize += (s, e) => { foreach (var i in _items.Values) i.Width = _flow.ClientSize.Width; };

            _logo = new Panel { Dock = DockStyle.Top, Height = 62, BackColor = Theme.Forest };
            _logo.Paint += PaintLogo;

            _footer = new Panel { Dock = DockStyle.Bottom, Height = 68, BackColor = Theme.Forest };
            _footer.Paint += (s, e) =>
            {
                using (var pen = new Pen(Color.FromArgb(40, 255, 255, 255))) e.Graphics.DrawLine(pen, 14, 0, _footer.Width - 14, 0);
                GraphicsUtil.HighQuality(e.Graphics);
                IconPainter.Draw(e.Graphics, Icons.SignOut, new Rectangle(_footer.Width - 34, 26, 16, 16), _signHot ? Color.White : Theme.SidebarText, 1.4f);
            };
            _footer.MouseMove += (s, e) => { bool h = SignRect().Contains(e.Location); if (h != _signHot) { _signHot = h; _footer.Cursor = h ? Cursors.Hand : Cursors.Default; _footer.Invalidate(); } };
            _footer.MouseLeave += (s, e) => { if (_signHot) { _signHot = false; _footer.Invalidate(); } };
            _footer.MouseClick += (s, e) => { if (SignRect().Contains(e.Location) && LogoutRequested != null) LogoutRequested(); };

            _avatar = new AvatarBadge { Location = new Point(24, 18), Size = new Size(32, 32), FillColor = Theme.Marigold, TextColor = Theme.OnMarigold, Font = Theme.Body(9f, FontStyle.Bold) };
            _name = new Label
            {
                Location = new Point(66, 9), Size = new Size(116, 32), ForeColor = Color.White, BackColor = Theme.Forest,
                Font = Theme.Body(9.5f, FontStyle.Bold), AutoEllipsis = true
            };
            _role = new Label
            {
                Location = new Point(66, 42), Size = new Size(116, 16), ForeColor = Theme.SidebarText, BackColor = Theme.Forest,
                Font = Theme.Body(9f)
            };
            _footer.Controls.AddRange(new Control[] { _avatar, _name, _role });

            // Fill first, then Top/Bottom (WinForms docks the last-added control first).
            Controls.Add(_flow);
            Controls.Add(_logo);
            Controls.Add(_footer);
        }

        public void SetUser(string fullName, string roleText)
        {
            _name.Text = fullName;
            _role.Text = roleText;
            _avatar.Initials = GraphicsUtil.Initials(fullName);
        }

        public void SetItems(IEnumerable<NavEntry> entries)
        {
            _flow.SuspendLayout();
            _flow.Controls.Clear();
            _items.Clear();
            foreach (var entry in entries)
            {
                var item = new NavItem { Text = entry.Text, Glyph = entry.Glyph, Width = _flow.ClientSize.Width };
                var id = entry.Id;
                item.Click += (s, e) => { if (NavigateRequested != null) NavigateRequested(id); };
                _items[id] = item;
                _flow.Controls.Add(item);
            }
            _flow.ResumeLayout(true);
        }

        public void SetActive(ViewId id)
        {
            foreach (var kv in _items) kv.Value.Active = kv.Key == id;
        }

        public void SetBadge(ViewId id, int count)
        {
            NavItem item;
            if (_items.TryGetValue(id, out item)) item.Badge = count;
        }

        private void PaintLogo(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            IconPainter.DrawMark(g, new Rectangle(22, 20, 20, 20), Color.White);
            TextRenderer.DrawText(g, "Farm2Home", Theme.Heading(13f), new Rectangle(51, 0, 150, 62), Color.White,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }
}
