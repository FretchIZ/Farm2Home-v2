using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Reusable product tile: picture, name, cooperative, rating, price and a quick "+" add button.</summary>
    internal class ProductCard : RoundedPanel
    {
        private Product _product;
        private readonly bool _canAdd;
        private Rectangle _plus;
        private bool _hover;

        public event Action OpenRequested;
        public event Action AddRequested;

        /// <summary>Compact cards (cooperative profile) leave out the cooperative name and rating.</summary>
        public bool Compact { get; set; }

        public ProductCard(Product product, bool canAdd)
        {
            _product = product; _canAdd = canAdd;
            SetStyle(ControlStyles.Selectable, true);
            TabStop = true;
            Cursor = Cursors.Hand;
            Radius = 12;
            Height = 236;
        }

        public void SetProduct(Product p) { _product = p; Invalidate(); }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; BorderColor = Theme.BorderStrong; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; BorderColor = Theme.Border; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { BorderColor = Theme.FocusRing; BorderWidth = 2f; Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { BorderColor = Theme.Border; BorderWidth = 1f; Invalidate(); base.OnLostFocus(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (_canAdd && _product.InStock && _plus.Contains(e.Location)) { if (AddRequested != null) AddRequested(); }
            else if (OpenRequested != null) OpenRequested();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && OpenRequested != null) { OpenRequested(); e.Handled = true; }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            var p = _product;
            const int pad = 14;
            int imgH = Compact ? Math.Max(60, Height * 54 / 100) : Math.Max(80, Height * 52 / 100);
            ImagePainter.Paint(g, new Rectangle(1, 1, Width - 2, imgH), p.ImagePath, false, 11, true);
            var left = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;

            int y = imgH + 10;
            TextRenderer.DrawText(g, p.ProductName ?? "", Theme.Body(10f, FontStyle.Bold), new Rectangle(pad, y, Width - 2 * pad, 20), Theme.Ink, left);
            y += 20;
            if (!Compact)
            {
                TextRenderer.DrawText(g, p.CooperativeName ?? "", Theme.Body(9f), new Rectangle(pad, y, Width - 2 * pad, 16), Theme.Muted, left);
                y += 17;
                IconPainter.DrawStar(g, new Rectangle(pad, y + 2, 11, 11), p.ReviewCount > 0);
                TextRenderer.DrawText(g, RatingText.Short(p.AvgRating, p.ReviewCount), Theme.Body(9f), new Rectangle(pad + 16, y, Width - 2 * pad - 16, 16), Theme.Muted, left);
            }

            int baseY = Height - 14 - 22;
            var priceFont = Theme.Body(11.5f, FontStyle.Bold);
            string price = Ui.Money(p.Price);
            int pw = TextRenderer.MeasureText(price, priceFont, new Size(500, 40), TextFormatFlags.NoPadding).Width;
            TextRenderer.DrawText(g, price, priceFont, new Rectangle(pad, baseY, pw + 4, 22), Theme.Deep, left);
            TextRenderer.DrawText(g, "/" + p.Unit, Theme.Body(9f, FontStyle.Bold), new Rectangle(pad + pw + 2, baseY + 2, 70, 22), Theme.Muted, left);

            if (!p.InStock)
                TextRenderer.DrawText(g, "Out of stock", Theme.Body(9f, FontStyle.Bold), new Rectangle(Width - pad - 90, baseY, 90, 22), Theme.Danger,
                    TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);

            if (_canAdd && p.InStock)
            {
                _plus = new Rectangle(Width - pad - 26, Height - pad - 28, 26, 26);
                using (var b = new SolidBrush(_hover ? Color.FromArgb(250, 224, 180) : Theme.MarigoldSoft)) g.FillEllipse(b, _plus);
                IconPainter.Draw(g, Icons.Plus, new Rectangle(_plus.X + 7, _plus.Y + 7, 12, 12), Theme.MarigoldText, 1.6f);
            }
            else _plus = Rectangle.Empty;
        }
    }

    /// <summary>Reusable cooperative tile.</summary>
    internal class CooperativeCard : RoundedPanel
    {
        private readonly Cooperative _coop;
        public event Action OpenRequested;

        public CooperativeCard(Cooperative coop)
        {
            _coop = coop;
            SetStyle(ControlStyles.Selectable, true);
            TabStop = true;
            Cursor = Cursors.Hand;
            Radius = 12;
            Height = 180;
        }

        protected override void OnMouseEnter(EventArgs e) { BorderColor = Theme.BorderStrong; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { BorderColor = Theme.Border; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { BorderColor = Theme.FocusRing; BorderWidth = 2f; Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { BorderColor = Theme.Border; BorderWidth = 1f; Invalidate(); base.OnLostFocus(e); }
        protected override void OnMouseClick(MouseEventArgs e) { base.OnMouseClick(e); if (OpenRequested != null) OpenRequested(); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && OpenRequested != null) { OpenRequested(); e.Handled = true; }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            const int pad = 17;
            int w = Width - 2 * pad;
            ImagePainter.Paint(g, new Rectangle(pad, 17, w, 78), _coop.ImagePath, true, 8);

            var left = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            TextRenderer.DrawText(g, _coop.Name ?? "", Theme.Body(10f, FontStyle.Bold), new Rectangle(pad, 103, w, 20), Theme.Ink, left);
            IconPainter.Draw(g, Icons.Pin, new Rectangle(pad, 126, 12, 12), Theme.Muted, 1.2f);
            TextRenderer.DrawText(g, _coop.Location ?? "", Theme.Body(9f), new Rectangle(pad + 17, 123, w - 17, 18), Theme.Muted, left);

            if (_coop.IsOrganicCertified)
            {
                var f = Theme.Body(9f, FontStyle.Bold);
                int tw = TextRenderer.MeasureText("Organic certified", f, new Size(300, 30), TextFormatFlags.NoPadding).Width;
                var pill = new Rectangle(pad, 147, tw + 32, 21);
                using (var path = GraphicsUtil.RoundedRect(pill, 10)) using (var b = new SolidBrush(Theme.MossLight)) g.FillPath(b, path);
                IconPainter.Draw(g, Icons.Check, new Rectangle(pill.X + 8, pill.Y + 5, 11, 11), Theme.Forest, 1.5f);
                TextRenderer.DrawText(g, "Organic certified", f, new Rectangle(pill.X + 22, pill.Y, tw + 6, pill.Height), Theme.Forest, left);
            }
        }
    }
}
