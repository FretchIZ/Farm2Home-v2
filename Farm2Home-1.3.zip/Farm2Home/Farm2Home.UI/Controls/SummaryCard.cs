using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Dashboard stat card: icon, big value, caption and an optional tag ("Needs action").</summary>
    internal class SummaryCard : RoundedPanel
    {
        private string _glyph = Icons.Dashboard, _value = "0", _caption = "", _tag = "";
        public string Glyph { get { return _glyph; } set { _glyph = value; Invalidate(); } }
        public string Value { get { return _value; } set { _value = value; Invalidate(); } }
        public string Caption { get { return _caption; } set { _caption = value; Invalidate(); } }
        public string TagText { get { return _tag; } set { _tag = value; Invalidate(); } }
        public Color TagColor { get; set; } = Theme.Forest;

        public SummaryCard() { Size = new Size(260, 120); Radius = 12; }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);

            var iconBox = new Rectangle(16, 16, 36, 36);
            using (var p = GraphicsUtil.RoundedRect(iconBox, 8))
            using (var b = new SolidBrush(Theme.MossLight)) g.FillPath(b, p);
            IconPainter.Draw(g, _glyph, new Rectangle(iconBox.X + 9, iconBox.Y + 9, 18, 18), Theme.Forest, 1.5f);

            if (!string.IsNullOrEmpty(_tag))
                TextRenderer.DrawText(g, _tag, Theme.Body(9f, FontStyle.Bold), new Rectangle(Width - 170, 16, 154, 36), TagColor,
                    TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);

            TextRenderer.DrawText(g, _value, Theme.Heading(17f), new Rectangle(16, 58, Width - 32, 30), Theme.Deep,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, _caption, Theme.Body(9f), new Rectangle(16, 90, Width - 32, 20), Theme.Muted,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
        }
    }
}
