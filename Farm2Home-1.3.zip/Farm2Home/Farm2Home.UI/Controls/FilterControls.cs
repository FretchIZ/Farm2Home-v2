using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Custom check box row: [x] label ........ count.</summary>
    internal class CheckRow : Control
    {
        private bool _checked;
        public int Count { get; set; }
        public bool ShowCount { get; set; } = true;
        public event EventHandler CheckedChanged;
        public bool Checked { get { return _checked; } set { if (_checked == value) return; _checked = value; Invalidate(); if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty); } }

        public CheckRow(string text)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);
            Text = text; BackColor = Color.Transparent; Cursor = Cursors.Hand; TabStop = true; Height = 26; Font = Theme.Body(9.5f);
        }

        protected override void OnMouseClick(MouseEventArgs e) { Focus(); Checked = !Checked; base.OnMouseClick(e); }
        protected override void OnKeyDown(KeyEventArgs e) { if (e.KeyCode == Keys.Space) { Checked = !Checked; e.Handled = true; } base.OnKeyDown(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            var box = new RectangleF(0.5f, (Height - 15) / 2f, 15, 15);
            using (var path = GraphicsUtil.RoundedRect(box, 3.5f))
            {
                if (_checked) using (var b = new SolidBrush(Theme.Forest)) g.FillPath(b, path);
                using (var pen = new Pen(_checked || (Focused && ShowFocusCues) ? Theme.FocusRing : Theme.ControlBorder, Focused && ShowFocusCues ? 2f : 1.3f)) g.DrawPath(pen, path);
            }
            if (_checked) IconPainter.Draw(g, Icons.Check, new Rectangle(2, (Height - 11) / 2, 11, 11), Color.White, 1.7f);
            int cw = ShowCount ? 34 : 0;
            var f = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            TextRenderer.DrawText(g, Text, Font, new Rectangle(25, 0, Width - 25 - cw, Height), _checked ? Theme.Ink : Theme.Muted, f);
            if (ShowCount)
                TextRenderer.DrawText(g, Count.ToString(), Theme.Body(9f), new Rectangle(Width - cw, 0, cw, Height), Theme.Muted,
                    TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }

    /// <summary>On/off switch with a label on the left ("Organic certified").</summary>
    internal class ToggleRow : Control
    {
        private bool _on;
        public event EventHandler CheckedChanged;
        public bool Checked { get { return _on; } set { if (_on == value) return; _on = value; Invalidate(); if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty); } }

        public ToggleRow(string text)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);
            Text = text; BackColor = Color.Transparent; Cursor = Cursors.Hand; TabStop = true; Height = 30; Font = Theme.Body(9.5f, FontStyle.Bold);
        }

        protected override void OnMouseClick(MouseEventArgs e) { Focus(); Checked = !Checked; base.OnMouseClick(e); }
        protected override void OnKeyDown(KeyEventArgs e) { if (e.KeyCode == Keys.Space) { Checked = !Checked; e.Handled = true; } base.OnKeyDown(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            TextRenderer.DrawText(g, Text, Font, new Rectangle(0, 0, Width - 50, Height), Theme.Ink,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            var track = new RectangleF(Width - 42, (Height - 22) / 2f, 40, 22);
            using (var path = GraphicsUtil.RoundedRect(track, 11))
            {
                using (var b = new SolidBrush(_on ? Theme.Forest : Theme.ControlBorder)) g.FillPath(b, path);
                if (Focused && ShowFocusCues)
                    using (var ring = GraphicsUtil.RoundedRect(new RectangleF(track.X - 2, track.Y - 2, track.Width + 4, track.Height + 4), 13))
                    using (var pen = new Pen(Theme.FocusRing, 2f)) g.DrawPath(pen, ring);
            }
            float kx = _on ? track.Right - 19 : track.X + 3;
            g.FillEllipse(Brushes.White, kx, track.Y + 3, 16, 16);
            if (_on) IconPainter.Draw(g, Icons.Check, new Rectangle((int)kx + 3, (int)track.Y + 6, 10, 10), Theme.Forest, 1.6f);   // on = tick as well as colour/position
        }
    }

    /// <summary>Two-handle price slider with the chosen minimum and maximum printed underneath.</summary>
    internal class RangeSlider : Control
    {
        private decimal _lo, _hi, _min, _max;
        private int _drag;       // 0 none, 1 low thumb, 2 high thumb
        public event EventHandler RangeChanged;
        public decimal Low { get { return _lo; } }
        public decimal High { get { return _hi; } }
        public decimal Minimum { get { return _min; } }
        public decimal Maximum { get { return _max; } }
        /// <summary>True when the thumbs are not at the ends, i.e. the user is really filtering by price.</summary>
        public bool IsNarrowed { get { return _lo > _min || _hi < _max; } }

        public RangeSlider()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Height = 46; Cursor = Cursors.Hand;
        }

        public void SetBounds(decimal min, decimal max, decimal lo, decimal hi)
        {
            if (max <= min) max = min + 1;
            _min = min; _max = max; _lo = Math.Max(min, Math.Min(lo, max)); _hi = Math.Max(_lo, Math.Min(hi, max)); Invalidate();
        }

        private float X(decimal v) { return 8 + (float)((v - _min) / (_max - _min)) * (Width - 16); }
        private decimal ValueAt(int x) { decimal v = _min + (decimal)((x - 8f) / Math.Max(1, Width - 16)) * (_max - _min); return Math.Max(_min, Math.Min(_max, Math.Round(v))); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Y > 26) return;
            _drag = Math.Abs(e.X - X(_lo)) <= Math.Abs(e.X - X(_hi)) ? 1 : 2;
            Move(e.X); base.OnMouseDown(e);
        }
        protected override void OnMouseMove(MouseEventArgs e) { if (_drag != 0) Move(e.X); base.OnMouseMove(e); }
        protected override void OnMouseUp(MouseEventArgs e) { bool was = _drag != 0; _drag = 0; if (was && RangeChanged != null) RangeChanged(this, EventArgs.Empty); base.OnMouseUp(e); }

        private void Move(int x)
        {
            decimal v = ValueAt(x);
            if (_drag == 1) _lo = Math.Min(v, _hi); else _hi = Math.Max(v, _lo);
            Invalidate();      // RangeChanged is raised on mouse-up so we do not query the database on every pixel of the drag
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            float y = 13, x1 = X(_lo), x2 = X(_hi);
            using (var b = new SolidBrush(Theme.Border)) g.FillRectangle(b, 8, y - 2, Width - 16, 4);
            using (var pen = new Pen(Theme.ControlBorder, 1f)) g.DrawRectangle(pen, 8, y - 2, Width - 16, 4);
            using (var b = new SolidBrush(Theme.Forest)) g.FillRectangle(b, x1, y - 2, Math.Max(0, x2 - x1), 4);
            foreach (var x in new[] { x1, x2 })
            {
                g.FillEllipse(Brushes.White, x - 8, y - 8, 16, 16);
                using (var b = new SolidBrush(Theme.Forest)) g.FillEllipse(b, x - 6, y - 6, 12, 12);
            }
            var f = Theme.Body(9f);
            TextRenderer.DrawText(g, Ui.Money(_lo), f, new Rectangle(0, 28, Width / 2, 18), Theme.Muted, TextFormatFlags.Left | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, Ui.Money(_hi), f, new Rectangle(Width / 2, 28, Width / 2, 18), Theme.Muted, TextFormatFlags.Right | TextFormatFlags.NoPadding);
        }
    }

    /// <summary>"Home / Vegetables / Highland carrots": parts are muted, the last one is bold. Parts can be clicked.</summary>
    internal class Crumbs : Control
    {
        private string[] _parts = new string[0];
        private readonly System.Collections.Generic.List<Rectangle> _hits = new System.Collections.Generic.List<Rectangle>();
        public event Action<int> PartClicked;

        public Crumbs() { SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true); BackColor = Color.Transparent; Height = 20; }

        public void SetParts(params string[] parts) { _parts = parts; Invalidate(); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            for (int i = 0; i < _hits.Count; i++) if (_hits[i].Contains(e.Location) && i < _parts.Length - 1 && PartClicked != null) { PartClicked(i); return; }
            base.OnMouseClick(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            bool hand = false;
            for (int i = 0; i < _hits.Count; i++) if (i < _parts.Length - 1 && _hits[i].Contains(e.Location)) hand = true;
            Cursor = hand ? Cursors.Hand : Cursors.Default; base.OnMouseMove(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            _hits.Clear(); int x = 0;
            var flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            for (int i = 0; i < _parts.Length; i++)
            {
                bool last = i == _parts.Length - 1;
                var f = Theme.Body(9f, last ? FontStyle.Bold : FontStyle.Regular);
                int w = TextRenderer.MeasureText(_parts[i], f, new Size(2000, Height), flags).Width;
                TextRenderer.DrawText(e.Graphics, _parts[i], f, new Rectangle(x, 0, w + 2, Height), last ? Theme.Ink : Theme.Muted, flags);
                _hits.Add(new Rectangle(x, 0, w, Height)); x += w + 2;
                if (!last) { TextRenderer.DrawText(e.Graphics, " / ", Theme.Body(9f), new Rectangle(x, 0, 24, Height), Theme.Muted, flags); x += 14; }
            }
        }
    }
}

namespace Farm2Home.UI.Controls
{
    /// <summary>Label + value with a thin bar on its left (product facts: Harvested, Origin, Min. order).</summary>
    internal class FactItem : Control
    {
        private readonly string _label;
        public FactItem(string label, string value)
        {
            _label = label; Text = value;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Height = 40;
            Width = Math.Max(TextRenderer.MeasureText(label, Theme.Body(10f, FontStyle.Bold)).Width, TextRenderer.MeasureText(value ?? "", Theme.Body(9.5f)).Width) + 22;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            using (var b = new SolidBrush(Theme.BorderStrong)) e.Graphics.FillRectangle(b, 0, 2, 2, Height - 4);
            var f = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis;
            TextRenderer.DrawText(e.Graphics, _label, Theme.Body(10f, FontStyle.Bold), new Rectangle(11, 0, Width - 11, 20), Theme.Ink, f);
            TextRenderer.DrawText(e.Graphics, Text ?? "", Theme.Body(9.5f), new Rectangle(11, 20, Width - 11, 18), Theme.Muted, f);
        }
    }

    /// <summary>Square tile with a vector icon (cooperative logo placeholder, small thumbnails).</summary>
    internal class IconTile : Control
    {
        public string IconName { get; set; }
        public Color Fill { get; set; } = Theme.MossLight;
        public Color IconColor { get; set; } = Theme.IconGreen;
        public Color BorderColor { get; set; } = Color.Transparent;
        public int Radius { get; set; } = 10;
        public IconTile(string icon, int size) { IconName = icon; Size = new Size(size, size); SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor | ControlStyles.ResizeRedraw, true); BackColor = Color.Transparent; }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            using (var p = GraphicsUtil.RoundedRect(new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f), Radius))
            {
                using (var b = new SolidBrush(Fill)) g.FillPath(b, p);
                if (BorderColor != Color.Transparent) using (var pen = new Pen(BorderColor, 1.5f)) g.DrawPath(pen, p);
            }
            int s = Math.Min(Width, Height) * 46 / 100;
            IconPainter.Draw(g, IconName, new Rectangle((Width - s) / 2, (Height - s) / 2, s, s), IconColor, Math.Max(1.4f, s / 12f));
        }
    }
}

namespace Farm2Home.UI.Controls
{
    /// <summary>Card heading with a small icon: "(pin) Delivery address".</summary>
    internal class HeaderRow : Control
    {
        private readonly string _icon;
        /// <summary>Red title and icon (low stock alert).</summary>
        public bool Danger { get; set; }
        public HeaderRow(string icon, string text)
        {
            _icon = icon; Text = text; Height = 24;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            GraphicsUtil.HighQuality(e.Graphics);
            IconPainter.Draw(e.Graphics, _icon, new Rectangle(0, 3, 18, 18), Danger ? Theme.Danger : Theme.Forest, 1.4f);
            TextRenderer.DrawText(e.Graphics, Text, Theme.Body(10.5f, FontStyle.Bold), new Rectangle(27, 0, Width - 27, Height), Danger ? Theme.Danger : Theme.Ink,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        }
    }

    /// <summary>"Cart -> Delivery & payment -> Confirmation" with the current step in bold green.</summary>
    internal class StepCrumbs : Control
    {
        private readonly string[] _steps; private readonly int _current;
        public StepCrumbs(int current, params string[] steps)
        {
            _steps = steps; _current = current; Height = 20;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            int x = 0;
            var fl = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            for (int i = 0; i < _steps.Length; i++)
            {
                var f = Theme.Body(9.5f, i == _current ? FontStyle.Bold : FontStyle.Regular);
                int w = TextRenderer.MeasureText(_steps[i], f, new Size(1000, Height), fl).Width;
                TextRenderer.DrawText(e.Graphics, _steps[i], f, new Rectangle(x, 0, w + 2, Height), i == _current ? Theme.Forest : Theme.Muted, fl);
                x += w + 6;
                if (i < _steps.Length - 1) { TextRenderer.DrawText(e.Graphics, "\u2192", Theme.Body(8f), new Rectangle(x, 1, 16, Height), Theme.Muted, fl); x += 18; }
            }
        }
    }

    /// <summary>Selected payment option: radio dot, icon, title and a line of explanation.</summary>
    internal class PaymentOption : Control
    {
        private readonly string _title, _sub;
        public PaymentOption(string title, string sub)
        {
            _title = title; _sub = sub; Height = 58;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor | ControlStyles.ResizeRedraw, true);
            BackColor = Color.Transparent;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            using (var p = GraphicsUtil.RoundedRect(new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f), 10))
            {
                using (var b = new SolidBrush(Theme.MossLight)) g.FillPath(b, p);
                using (var pen = new Pen(Theme.Forest, 1.2f)) g.DrawPath(pen, p);
            }
            using (var pen = new Pen(Theme.Forest, 1.6f)) g.DrawEllipse(pen, 16, Height / 2 - 9, 18, 18);
            using (var b = new SolidBrush(Theme.Forest)) g.FillEllipse(b, 21, Height / 2 - 4, 8, 8);
            IconPainter.Draw(g, Icons.Card, new Rectangle(46, Height / 2 - 11, 22, 22), Theme.Forest, 1.4f);
            var fl = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis;
            TextRenderer.DrawText(g, _title, Theme.Body(10f, FontStyle.Bold), new Rectangle(80, 9, Width - 90, 20), Theme.Ink, fl);
            TextRenderer.DrawText(g, _sub, Theme.Body(9f), new Rectangle(80, 29, Width - 90, 18), Theme.Muted, fl);
        }
    }
}
