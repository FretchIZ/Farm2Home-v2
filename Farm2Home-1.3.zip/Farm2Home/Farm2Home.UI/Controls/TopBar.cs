using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Header: search box (Enter to search), delivery city, notifications bell and the user's avatar.</summary>
    internal sealed class TopBar : Panel
    {
        public event Action<string> SearchSubmitted;

        private readonly RoundedPanel _searchBox;
        private readonly TextBox _text;
        private readonly AvatarBadge _avatar;
        private readonly string _placeholder, _locationText;

        public TopBar(string placeholder, string initials, string locationText = null)
        {
            _placeholder = placeholder;
            _locationText = string.IsNullOrWhiteSpace(locationText) ? null : "Delivering to " + locationText;
            Dock = DockStyle.Top;
            Height = 70;
            BackColor = Theme.Surface;
            DoubleBuffered = true;

            _searchBox = new RoundedPanel
            {
                Location = new Point(28, 17), Size = new Size(360, 36), Radius = 8,
                FillColor = Theme.Background, BorderColor = Theme.ControlBorder
            };
            _searchBox.PostPaint += (s, e) => { GraphicsUtil.HighQuality(e.Graphics); IconPainter.Draw(e.Graphics, Icons.Browse, new Rectangle(13, 10, 16, 16), Theme.Muted, 1.4f); };
            _text = new TextBox
            {
                BorderStyle = BorderStyle.None, BackColor = Theme.Background, ForeColor = Theme.Ink,
                Font = Theme.Body(10f), MaxLength = 100, Location = new Point(42, 9), Width = 305,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            _text.HandleCreated += (s, e) => NativeMethods.SetPlaceholder(_text, _placeholder);
            _text.KeyDown += (s, e) =>
            {
                if (e.KeyCode != Keys.Enter) return;
                e.SuppressKeyPress = true;
                if (SearchSubmitted != null) SearchSubmitted(_text.Text.Trim());
            };
            _searchBox.Controls.Add(_text);
            _searchBox.Resize += (s, e) => _text.Top = Math.Max(0, (_searchBox.Height - _text.Height) / 2);

            _avatar = new AvatarBadge { Initials = initials, Size = new Size(30, 30), Font = Theme.Body(8.5f, FontStyle.Bold), Anchor = AnchorStyles.Top | AnchorStyles.Right };
            Controls.Add(_searchBox);
            Controls.Add(_avatar);
            _text.Top = Math.Max(0, (_searchBox.Height - _text.Height) / 2);
            PositionChildren();
        }

        protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); PositionChildren(); }

        private bool ShowLocation { get { return _locationText != null && Width >= 900; } }

        private void PositionChildren()
        {
            if (_searchBox == null || _avatar == null) return;
            _avatar.Location = new Point(Width - _avatar.Width - 28, (Height - _avatar.Height) / 2);
            int reserved = ShowLocation ? 330 : 120;
            _searchBox.Width = Math.Max(200, Math.Min(360, Width - 28 - reserved - 60));
            _text.Width = _searchBox.Width - 55;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);
            int right = _avatar.Left - 18;
            IconPainter.Draw(g, Icons.Bell, new Rectangle(right - 18, (Height - 18) / 2, 18, 18), Theme.Forest, 1.4f);
            right -= 18 + 20;
            if (ShowLocation)
            {
                var f = Theme.Body(10f, FontStyle.Bold);
                int w = TextRenderer.MeasureText(_locationText, f, new Size(400, 30), TextFormatFlags.NoPadding).Width;
                TextRenderer.DrawText(g, _locationText, f, new Rectangle(right - w, 0, w + 2, Height), Theme.Forest,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                IconPainter.Draw(g, Icons.Pin, new Rectangle(right - w - 24, (Height - 16) / 2, 16, 16), Theme.Forest, 1.4f);
            }
        }
    }
}
