using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Farm2Home.UI.Controls
{
    /// <summary>Equal-width responsive grid of fixed-height cards. Column count follows the available width.</summary>
    internal class GridPanel : Panel
    {
        private bool _busy;
        public int MinItemWidth { get; set; } = 240;
        public int ItemHeight { get; set; } = 290;
        public int Gap { get; set; } = 16;

        public void SetItems(IEnumerable<Control> items)
        {
            SuspendLayout();
            for (int i = Controls.Count - 1; i >= 0; i--) { var c = Controls[i]; Controls.RemoveAt(i); c.Dispose(); }
            foreach (var item in items) Controls.Add(item);
            ResumeLayout();
            LayoutItems();
        }

        protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); LayoutItems(); }

        private void LayoutItems()
        {
            if (_busy || Width <= 0) return;
            _busy = true;
            try
            {
                int n = Controls.Count;
                if (n == 0) { Height = 0; return; }
                int cols = Math.Max(1, (Width + Gap) / (MinItemWidth + Gap));
                int itemW = (Width - (cols - 1) * Gap) / cols;
                int i = 0;
                foreach (Control c in Controls)
                {
                    c.SetBounds((i % cols) * (itemW + Gap), (i / cols) * (ItemHeight + Gap), itemW, ItemHeight);
                    i++;
                }
                int rows = (n + cols - 1) / cols;
                Height = rows * ItemHeight + (rows - 1) * Gap;
            }
            finally { _busy = false; }
        }
    }

    /// <summary>Flows fixed-size children left-to-right and wraps (chips, button rows).</summary>
    internal class WrapRow : Panel
    {
        private bool _busy;
        public int Gap { get; set; } = 10;

        protected override void OnControlAdded(ControlEventArgs e) { base.OnControlAdded(e); LayoutItems(); }
        protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); LayoutItems(); }

        private void LayoutItems()
        {
            if (_busy || Width <= 0) return;
            _busy = true;
            try
            {
                int x = 0, y = 0, rowH = 0;
                foreach (Control c in Controls)
                {
                    if (x > 0 && x + c.Width > Width) { x = 0; y += rowH + Gap; rowH = 0; }
                    c.Location = new Point(x, y);
                    x += c.Width + Gap;
                    rowH = Math.Max(rowH, c.Height);
                }
                int h = Controls.Count == 0 ? 0 : y + rowH;
                if (Height != h) Height = h;
            }
            finally { _busy = false; }
        }
    }

    /// <summary>N children side by side with equal widths (e.g. City | Province).</summary>
    internal class EqualRow : Panel
    {
        private bool _busy;
        public int Gap { get; set; } = 16;

        public EqualRow(params Control[] items)
        {
            foreach (var c in items) { Controls.Add(c); c.SizeChanged += (s, e) => LayoutItems(); }
        }

        protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); LayoutItems(); }

        private void LayoutItems()
        {
            if (_busy || Width <= 0 || Controls.Count == 0) return;
            _busy = true;
            try
            {
                int n = Controls.Count, w = (Width - (n - 1) * Gap) / n, h = 0, i = 0;
                foreach (Control c in Controls) { c.SetBounds(i * (w + Gap), 0, w, c.Height); h = Math.Max(h, c.Height); i++; }
                if (Height != h) Height = h;
            }
            finally { _busy = false; }
        }
    }

    /// <summary>Two columns, one with a fixed width. Stacks vertically when the window is narrow.</summary>
    internal class TwoColumn : Panel
    {
        private bool _busy;
        private readonly Control _first, _second;
        private readonly int _fixedWidth;
        private readonly bool _fixedIsSecond;
        public int Gap { get; set; } = 24;
        public int StackBelow { get; set; } = 860;
        /// <summary>When set, the first column has this width and the second takes the rest (used by the product page).</summary>
        public int FirstWidth { get; set; }

        public TwoColumn(Control first, Control second, int fixedWidth, bool fixedIsSecond)
        {
            _first = first; _second = second; _fixedWidth = fixedWidth; _fixedIsSecond = fixedIsSecond;
            Controls.Add(first); Controls.Add(second);
            first.SizeChanged += (s, e) => LayoutItems();
            second.SizeChanged += (s, e) => LayoutItems();
        }

        protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); LayoutItems(); }

        private void LayoutItems()
        {
            if (_busy || Width <= 0) return;
            _busy = true;
            try
            {
                int h;
                if (Width < StackBelow)
                {
                    _first.SetBounds(0, 0, Width, _first.Height);
                    _second.SetBounds(0, _first.Height + Gap, Width, _second.Height);
                    h = _second.Bottom;
                }
                else
                {
                    int fw = FirstWidth > 0 ? FirstWidth : _fixedWidth, flex = Width - fw - Gap;
                    bool secondFixed = _fixedIsSecond && FirstWidth <= 0;
                    int w1 = secondFixed ? flex : fw, w2 = secondFixed ? fw : flex;
                    _first.SetBounds(0, 0, w1, _first.Height);
                    _second.SetBounds(w1 + Gap, 0, w2, _second.Height);
                    h = Math.Max(_first.Height, _second.Height);
                }
                if (Height != h) Height = h;
            }
            finally { _busy = false; }
        }
    }
}

namespace Farm2Home.UI.Controls
{
    /// <summary>Centres one child horizontally with a maximum width (the confirmation page is a narrow column).</summary>
    internal class CenterColumn : Panel
    {
        private readonly Control _child; private readonly int _max; private bool _busy;
        public CenterColumn(Control child, int maxWidth) { _child = child; _max = maxWidth; Controls.Add(child); child.SizeChanged += (s, e) => Place(); }
        protected override void OnResize(EventArgs e) { base.OnResize(e); Place(); }
        private void Place()
        {
            if (_busy || Width <= 0) return; _busy = true;
            try { int w = Math.Min(_max, Width); _child.SetBounds((Width - w) / 2, 0, w, _child.Height); if (Height != _child.Height) Height = _child.Height; }
            finally { _busy = false; }
        }
    }
}

namespace Farm2Home.UI.Controls
{
    /// <summary>Gives a VStack left/right margins inside a full-width page (so a banner can be full-bleed while the rest keeps the page margins).</summary>
    internal class InsetHost : Panel
    {
        private readonly VStack _inner; private readonly int _inset; private bool _busy;
        public InsetHost(VStack inner, int inset) { _inner = inner; _inset = inset; Controls.Add(inner); inner.SizeChanged += (s, e) => Place(); }
        protected override void OnResize(EventArgs e) { base.OnResize(e); Place(); }
        private void Place()
        {
            if (_busy || Width <= 0) return; _busy = true;
            try { _inner.SetBounds(_inset, 0, Math.Max(10, Width - 2 * _inset), _inner.Height); if (Height != _inner.Height) Height = _inner.Height; }
            finally { _busy = false; }
        }
    }
}
