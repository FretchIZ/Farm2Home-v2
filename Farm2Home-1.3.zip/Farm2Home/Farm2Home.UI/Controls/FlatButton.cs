using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    internal enum BtnStyle { Primary, Accent, Outline, Soft, Ghost, Chip, ChipSelected }

    /// <summary>Rounded, themed button with hover/pressed/disabled/focus states.</summary>
    internal class FlatButton : Control
    {
        private bool _hover, _pressed, _busy;
        private System.Windows.Forms.Timer _spin;
        private int _angle;
        private BtnStyle _style = BtnStyle.Primary;

        /// <summary>Same as the person clicking the button.</summary>
        public void PerformClick() { if (Enabled && Visible) OnClick(EventArgs.Empty); }

        public BtnStyle Style { get { return _style; } set { _style = value; Invalidate(); } }
        public int Radius { get; set; } = 8;
        /// <summary>Optional vector icon drawn left of the text (see Icons).</summary>
        public string IconName { get; set; }
        public Color? IconColor { get; set; }
        public Color? TextColorOverride { get; set; }
        public Color? BorderOverride { get; set; }

        /// <summary>While true the button shows a small spinner, ignores clicks and keeps its label (use during saves and sign-in).</summary>
        public bool Busy
        {
            get { return _busy; }
            set
            {
                if (_busy == value) return;
                _busy = value;
                if (_busy)
                {
                    _spin = new System.Windows.Forms.Timer { Interval = 70 };
                    _spin.Tick += (s, e) => { _angle = (_angle + 40) % 360; Invalidate(); };
                    _spin.Start();
                }
                else if (_spin != null) { _spin.Stop(); _spin.Dispose(); _spin = null; }
                Cursor = _busy ? Cursors.WaitCursor : Cursors.Hand;
                Invalidate();
            }
        }

        protected override void OnClick(EventArgs e) { if (_busy) return; base.OnClick(e); }
        protected override void Dispose(bool disposing) { if (disposing && _spin != null) { _spin.Stop(); _spin.Dispose(); _spin = null; } base.Dispose(disposing); }

        public FlatButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.StandardClick |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Cursor = Cursors.Hand;
            TabStop = true;
            Size = new Size(140, 46);
            Font = Theme.Body(10f, FontStyle.Bold);
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _pressed = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { _pressed = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _pressed = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) { OnClick(EventArgs.Empty); e.Handled = true; }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);

            Color bg, fg, border = Color.Transparent;
            switch (_style)
            {
                case BtnStyle.Accent:
                    bg = _hover ? Theme.MarigoldHover : Theme.Marigold; fg = Theme.OnMarigold; break;
                case BtnStyle.Outline:
                    bg = _pressed ? Theme.MossLight : (_hover ? Theme.Background : Theme.Surface); fg = Theme.Ink; border = Theme.ControlBorder; break;
                case BtnStyle.Soft:
                    bg = _hover ? Theme.Marigold : Theme.MarigoldSoft; fg = _hover ? Theme.OnMarigold : Theme.MarigoldText; break;
                case BtnStyle.Chip:
                    bg = _pressed ? Theme.MossLight : (_hover ? Theme.Background : Theme.Surface); fg = Theme.Muted; border = Theme.ControlBorder; break;
                case BtnStyle.ChipSelected:
                    bg = Theme.MossLight; fg = Theme.Forest; border = Theme.Forest; break;
                case BtnStyle.Ghost:
                    bg = (_hover || _pressed) ? Theme.MossLight : Color.Transparent; fg = Theme.Forest; break;
                default:
                    bg = _pressed ? Theme.Deep : (_hover ? Theme.ForestHover : Theme.Forest); fg = Color.White; break;
            }
            if (!Enabled) { bg = _style == BtnStyle.Ghost ? Color.Transparent : Theme.Disabled; fg = Theme.Muted; border = Color.Transparent; }

            if (BorderOverride.HasValue && Enabled) border = BorderOverride.Value;
            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            using (var path = GraphicsUtil.RoundedRect(r, Radius))
            {
                if (bg != Color.Transparent) using (var b = new SolidBrush(bg)) g.FillPath(b, path);
                if (border != Color.Transparent) using (var p = new Pen(border, 1f)) g.DrawPath(p, path);
                if (Focused && ShowFocusCues)
                {
                    // Two-tone ring: dark outer line (8.6:1 on the page) + white inner line (9.5:1 on the green button) so it shows on every button style.
                    using (var op = GraphicsUtil.RoundedRect(new RectangleF(1f, 1f, Width - 3f, Height - 3f), Radius))
                    using (var fo = new Pen(Theme.FocusRing, 2f)) g.DrawPath(fo, op);
                    using (var ip = GraphicsUtil.RoundedRect(new RectangleF(3.5f, 3.5f, Width - 8f, Height - 8f), Math.Max(2, Radius - 3)))
                    using (var fi = new Pen(Theme.FocusInner, 1f)) g.DrawPath(fi, ip);
                }
            }

            if (TextColorOverride.HasValue && Enabled) fg = TextColorOverride.Value;
            var flags = TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            int dy = _pressed && Enabled ? 1 : 0;            // pressed = label moves down 1px (works on every colour)
            if (string.IsNullOrEmpty(IconName) && !_busy)
            {
                TextRenderer.DrawText(g, Text, Font, new Rectangle(8, dy, Width - 16, Height), fg, flags | TextFormatFlags.HorizontalCenter);
                return;
            }
            int tw = TextRenderer.MeasureText(g, Text ?? "", Font, new Size(Width, Height), TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix).Width;
            int icon = 16, gap = 8, total = icon + (string.IsNullOrEmpty(Text) ? 0 : gap + tw), x0 = Math.Max(6, (Width - total) / 2);
            if (_busy) using (var sp = new Pen(fg, 2f) { StartCap = System.Drawing.Drawing2D.LineCap.Round, EndCap = System.Drawing.Drawing2D.LineCap.Round })
                g.DrawArc(sp, x0 + 1, (Height - icon) / 2 + 1, icon - 2, icon - 2, _angle, 270);
            else IconPainter.Draw(g, IconName, new Rectangle(x0, (Height - icon) / 2 + dy, icon, icon), IconColor ?? fg, 1.5f);
            if (!string.IsNullOrEmpty(Text))
                TextRenderer.DrawText(g, Text, Font, new Rectangle(x0 + icon + gap, dy, Width - x0 - icon - gap - 4, Height), fg, flags | TextFormatFlags.Left);
        }
    }
}
