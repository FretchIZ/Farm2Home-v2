using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Cooperative page header: green banner, white logo tile, name with verified tick, meta line and Message / Follow buttons.</summary>
    internal sealed class CoopHeader : Control
    {
        private const int BannerH = 130;
        private readonly string _name, _location, _members, _rating;
        private readonly bool _verified;
        public FlatButton Message { get; private set; }
        public FlatButton Follow { get; private set; }

        public CoopHeader(string name, string location, int? members, string rating, bool verified, bool showButtons)
        {
            _name = name; _location = location; _verified = verified; _rating = rating;
            _members = members.HasValue ? members.Value.ToString("#,##0") + " member-farmers" : null;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Background; Height = 196;
            Message = Ui.Button("Message", BtnStyle.Outline, 84, 36); Message.Visible = showButtons;
            Follow = Ui.Button("Follow", BtnStyle.Primary, 76, 36); Follow.Visible = showButtons;
            Controls.Add(Message); Controls.Add(Follow);
            PlaceButtons();
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); PlaceButtons(); }

        private void PlaceButtons()
        {
            if (Message == null) return;
            Follow.Location = new Point(Width - 28 - Follow.Width, BannerH + 12);
            Message.Location = new Point(Follow.Left - 10 - Message.Width, BannerH + 12);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            g.Clear(Theme.Background);
            var banner = new Rectangle(0, 0, Width, BannerH);
            using (var br = new LinearGradientBrush(banner, Color.FromArgb(0x22, 0x55, 0x42), Color.FromArgb(0x2C, 0x6E, 0x52), 0f)) g.FillRectangle(br, banner);
            var st = g.Save(); g.SetClip(banner);
            using (var b = new SolidBrush(Color.FromArgb(160, Theme.Moss))) g.FillEllipse(b, Width - 150, -50, 220, 220);
            g.Restore(st);

            // logo tile with a soft shadow
            var logo = new Rectangle(28, BannerH - 38, 88, 88);
            using (var sh = new SolidBrush(Color.FromArgb(25, 0, 0, 0))) using (var p = GraphicsUtil.RoundedRect(new RectangleF(logo.X, logo.Y + 3, logo.Width, logo.Height), 16)) g.FillPath(sh, p);
            using (var p = GraphicsUtil.RoundedRect(logo, 16)) using (var b = new SolidBrush(Color.White)) g.FillPath(b, p);
            IconPainter.Draw(g, Icons.Cooperatives, new Rectangle(logo.X + 22, logo.Y + 22, 44, 44), Theme.Forest, 2.6f);

            int x = logo.Right + 18;
            var nf = Theme.Heading(15f);
            var fl = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            int nw = TextRenderer.MeasureText(_name ?? "", nf, new Size(2000, 40), fl).Width;
            int avail = Math.Max(120, Message.Left - x - 20 - (_verified ? 26 : 0));
            nw = Math.Min(nw, avail);
            TextRenderer.DrawText(g, _name ?? "", nf, new Rectangle(x, BannerH + 2, nw + 4, 30), Theme.Ink, fl | TextFormatFlags.EndEllipsis);
            if (_verified)
            {
                using (var b = new SolidBrush(Theme.Forest)) g.FillEllipse(b, x + nw + 10, BannerH + 8, 18, 18);
                IconPainter.Draw(g, Icons.Check, new Rectangle(x + nw + 13, BannerH + 11, 12, 12), Color.White, 1.8f);
            }
            var mf = Theme.Body(9f); int mx = x, my = BannerH + 34;
            Action<string, string> part = (icon, text) =>
            {
                if (string.IsNullOrEmpty(text)) return;
                if (icon != null) { IconPainter.Draw(g, icon, new Rectangle(mx, my + 3, 14, 14), Theme.Muted, 1.2f); mx += 19; }
                int w = TextRenderer.MeasureText(text, mf, new Size(1000, 20), fl).Width;
                TextRenderer.DrawText(g, text, mf, new Rectangle(mx, my, w + 2, 20), Theme.Muted, fl);
                mx += w + 18;
            };
            part(Icons.Pin, _location); part(Icons.People, _members); part(null, _rating);
        }
    }

    /// <summary>Text tabs with a green underline on the active one (Products / About / Reviews).</summary>
    internal sealed class TabStrip : Control
    {
        private readonly string[] _tabs; private int _sel;
        private readonly Rectangle[] _hits;
        public event Action<int> TabChanged;
        public TabStrip(params string[] tabs)
        {
            _tabs = tabs; _hits = new Rectangle[tabs.Length]; Height = 44; Cursor = Cursors.Hand;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Background;
        }
        public int Selected { get { return _sel; } set { _sel = value; Invalidate(); } }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            for (int i = 0; i < _hits.Length; i++) if (_hits[i].Contains(e.Location)) { _sel = i; Invalidate(); if (TabChanged != null) TabChanged(i); }
            base.OnMouseClick(e);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.Clear(Theme.Background);
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);
            int x = 28;
            var fl = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            for (int i = 0; i < _tabs.Length; i++)
            {
                var f = Theme.Body(10f, FontStyle.Bold);
                int w = TextRenderer.MeasureText(_tabs[i], f, new Size(500, 30), fl).Width;
                TextRenderer.DrawText(g, _tabs[i], f, new Rectangle(x, 0, w + 2, Height - 2), i == _sel ? Theme.Forest : Theme.Muted, fl);
                if (i == _sel) using (var b = new SolidBrush(Theme.Forest)) g.FillRectangle(b, x, Height - 3, w, 3);
                _hits[i] = new Rectangle(x - 6, 0, w + 12, Height); x += w + 26;
            }
        }
    }
}
