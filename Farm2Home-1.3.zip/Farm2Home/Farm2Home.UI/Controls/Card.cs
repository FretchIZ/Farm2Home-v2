using System;
using System.Drawing;

namespace Farm2Home.UI.Controls
{
    /// <summary>White rounded card with padding and a VStack inside. Grows to fit its content.</summary>
    internal class Card : RoundedPanel
    {
        public VStack Body { get; private set; }
        public int Inset { get; set; } = 24;

        public Card()
        {
            Body = new VStack { BackColor = Theme.Surface };
            Controls.Add(Body);
            Body.SizeChanged += (s, e) => FitHeight();
        }

        public Color Surface
        {
            set { FillColor = value; Body.BackColor = value; Invalidate(); }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (Body == null) return;
            Body.SetBounds(Inset, Inset, Math.Max(1, Width - 2 * Inset), Body.Height);
            FitHeight();
        }

        private void FitHeight()
        {
            int h = Body.Height + 2 * Inset;
            if (Height != h) Height = h;
        }
    }
}
