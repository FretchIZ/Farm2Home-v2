using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>One sidebar row: icon, label, optional count badge. Spans the sidebar width.</summary>
    internal class NavItem : Control
    {
        private bool _hover, _active;
        private int _badge;
        private string _glyph = "";

        public string Glyph { get { return _glyph; } set { _glyph = value; Invalidate(); } }
        public bool Active { get { return _active; } set { _active = value; Invalidate(); } }
        public int Badge { get { return _badge; } set { _badge = value; Invalidate(); } }

        public NavItem()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.StandardClick |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Cursor = Cursors.Hand;
            TabStop = true;
            Height = 40;
            Margin = Padding.Empty;
            Font = Theme.Body(10f, FontStyle.Bold);
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) { OnClick(EventArgs.Empty); e.Handled = true; }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);

            var rect = new RectangleF(14, 1, Width - 28, Height - 2);
            if (_active || _hover || (Focused && ShowFocusCues))
            {
                using (var p = GraphicsUtil.RoundedRect(rect, 8))
                using (var b = new SolidBrush(_active ? Theme.SidebarActive : Color.FromArgb(_hover ? 36 : 20, 255, 255, 255)))
                    g.FillPath(b, p);
            }
            if (_active)
                using (var b = new SolidBrush(Theme.Marigold)) g.FillRectangle(b, 0, 9, 3, Height - 18);
            if (Focused && ShowFocusCues)
                using (var fp = GraphicsUtil.RoundedRect(new RectangleF(rect.X + 1, rect.Y + 1, rect.Width - 2, rect.Height - 2), 7))
                using (var pen = new Pen(Color.White, 2f)) g.DrawPath(pen, fp);      // white ring: 9.5:1 on the green sidebar

            Color fg = _active ? Color.White : Theme.SidebarText;
            IconPainter.Draw(g, _glyph, new Rectangle(24, (Height - 18) / 2, 18, 18), fg, 1.5f);
            TextRenderer.DrawText(g, Text, Font, new Rectangle(53, 0, Width - 53 - 50, Height), fg,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);

            if (_badge > 0)
            {
                string s = _badge > 99 ? "99+" : _badge.ToString();
                var f = Theme.Body(9f, FontStyle.Bold);
                int w = Math.Max(20, TextRenderer.MeasureText(s, f, new Size(100, 30), TextFormatFlags.NoPadding).Width + 10);
                var pill = new RectangleF(Width - 24 - w, (Height - 18) / 2f, w, 18);
                using (var p = GraphicsUtil.RoundedRect(pill, 9))
                using (var b = new SolidBrush(Theme.Marigold)) g.FillPath(b, p);
                TextRenderer.DrawText(g, s, f, Rectangle.Round(pill), Theme.OnMarigold,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
        }
    }
}
