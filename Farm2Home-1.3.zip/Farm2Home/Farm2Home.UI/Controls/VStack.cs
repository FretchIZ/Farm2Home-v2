using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Farm2Home.UI.Controls
{
    /// <summary>Stacks children top-to-bottom at full width and sizes itself to fit. Child Margin.Bottom is the gap below it.</summary>
    internal class VStack : Panel
    {
        private bool _busy;
        private readonly HashSet<Control> _fixedWidth = new HashSet<Control>();

        public T Add<T>(T c, int gapBelow = 16) where T : Control
        {
            c.Margin = new Padding(0, 0, 0, gapBelow);
            Hook(c);
            return c;
        }

        /// <summary>Adds a child that keeps its own width (buttons, badges), left-aligned.</summary>
        public T AddFixed<T>(T c, int gapBelow = 16) where T : Control
        {
            _fixedWidth.Add(c);
            return Add(c, gapBelow);
        }

        private void Hook(Control c)
        {
            Controls.Add(c);
            c.SizeChanged += (s, e) => Relayout();
            c.VisibleChanged += (s, e) => Relayout();
            Relayout();
        }

        public void Clear()
        {
            SuspendLayout();
            for (int i = Controls.Count - 1; i >= 0; i--) { var c = Controls[i]; Controls.RemoveAt(i); c.Dispose(); }
            _fixedWidth.Clear();
            ResumeLayout();
            Relayout();
        }

        protected override void OnResize(System.EventArgs eventargs) { base.OnResize(eventargs); Relayout(); }

        public void Relayout()
        {
            if (_busy || ClientSize.Width <= 0) return;
            _busy = true;
            try
            {
                int y = 0, w = ClientSize.Width;
                foreach (Control c in Controls)
                {
                    if (!c.Visible) continue;
                    y += c.Margin.Top;
                    c.SetBounds(0, y, _fixedWidth.Contains(c) ? c.Width : w, c.Height);
                    y += c.Height + c.Margin.Bottom;
                }
                if (Height != y) Height = y;
            }
            finally { _busy = false; }
        }
    }
}
