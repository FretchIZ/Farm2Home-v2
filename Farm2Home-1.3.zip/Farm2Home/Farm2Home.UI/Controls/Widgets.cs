using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application.DTOs;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>A big number with a caption (cooperative profile figures, product facts).</summary>
    internal class StatTile : RoundedPanel
    {
        public string Value { get; set; }
        public string Caption { get; set; }
        public Font ValueFont { get; set; } = Theme.Heading(14f);

        public StatTile(string value, string caption, bool small = false)
        {
            Value = value; Caption = caption;
            if (small) { ValueFont = Theme.Body(11.5f, FontStyle.Bold); Height = 78; Radius = 12; } else { Height = 70; Radius = 12; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            GraphicsUtil.HighQuality(e.Graphics);
            var flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding;
            bool small = Height >= 74;
            TextRenderer.DrawText(e.Graphics, Value ?? "", ValueFont, new Rectangle(16, small ? 12 : 10, Width - 32, small ? 26 : 28), Theme.Deep, flags);
            TextRenderer.DrawText(e.Graphics, Caption ?? "", Theme.Body(9f), new Rectangle(16, small ? 42 : 38, Width - 32, 20), Theme.Muted, flags);
        }
    }

    /// <summary>Seven-day sales bars (busiest day highlighted).</summary>
    internal class BarChart : RoundedPanel
    {
        private IList<DailySale> _data = new List<DailySale>();
        public string Title { get; set; } = "Sales this week";

        public BarChart() { Height = 192; Radius = 12; }

        public void SetData(IList<DailySale> data) { _data = data ?? new List<DailySale>(); Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            TextRenderer.DrawText(g, Title, Theme.Body(10.5f, FontStyle.Bold), new Rectangle(20, 14, Width - 40, 22), Theme.Ink,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);

            decimal max = _data.Count == 0 ? 0m : _data.Max(d => d.Total);
            var area = new Rectangle(20, 46, Width - 40, Height - 46 - 34);
            if (max <= 0m)
            {
                TextRenderer.DrawText(g, "No sales yet this week. Orders will show up here.", Theme.Body(10.5f), area, Theme.Muted,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
            }

            int n = Math.Max(1, _data.Count);
            float slot = area.Width / (float)n, barW = slot * 0.88f;
            int top = _data.Select((d, i) => new { d, i }).OrderByDescending(x => x.d.Total).Select(x => x.i).FirstOrDefault();
            for (int i = 0; i < _data.Count; i++)
            {
                var d = _data[i];
                float x = area.X + slot * i + (slot - barW) / 2f;
                float h = max <= 0m ? 8f : Math.Max(8f, (float)(d.Total / max) * (area.Height - 4));
                var bar = new RectangleF(x, area.Bottom - h, barW, h);
                using (var path = GraphicsUtil.RoundedRect(bar, 4))
                using (var b = new SolidBrush(max > 0m && i == top ? Theme.Forest : Theme.MossLight)) g.FillPath(b, path);
                if (d.Total > 0m)
                    TextRenderer.DrawText(g, Ui.ShortMoney(d.Total), Theme.Body(9f, FontStyle.Bold), new Rectangle((int)(x - 12), (int)(bar.Y - 20), (int)barW + 24, 18),
                        Theme.Muted, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, d.Date.ToString("ddd"), Theme.Body(9.5f), new Rectangle((int)(area.X + slot * i), area.Bottom + 6, (int)slot, 20),
                    Theme.Muted, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
        }
    }

    /// <summary>Big green tick in a soft circle, centred (order placed).</summary>
    internal class CheckCircle : Control
    {
        public CheckCircle()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Height = 78;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            int d = 64, x = (Width - d) / 2, y = (Height - d) / 2;
            using (var b = new SolidBrush(Theme.MossLight)) g.FillEllipse(b, x, y, d, d);
            IconPainter.Draw(g, Icons.Check, new Rectangle(x + 16, y + 16, 32, 32), Theme.Forest, 3.2f);
        }
    }

    /// <summary>Row of selectable chips (delivery time slots). Exactly one is selected.</summary>
    internal class ChipGroup : WrapRow
    {
        private int _sel = -1;

        public string Selected { get { return _sel >= 0 && _sel < Controls.Count ? Controls[_sel].Text : null; } }

        public void SetOptions(IEnumerable<string> options, int selectedIndex)
        {
            foreach (var c in Controls.Cast<Control>().ToList()) { Controls.Remove(c); c.Dispose(); }
            int i = 0;
            foreach (var o in options)
            {
                int w = TextRenderer.MeasureText(o, Theme.Body(9.5f, FontStyle.Bold)).Width + 34;
                var b = new FlatButton { Text = o, Size = new Size(w, 34), Radius = 8, Font = Theme.Body(9.5f, FontStyle.Bold) };
                int idx = i;
                b.Click += (s, e) => Choose(idx);
                Controls.Add(b);
                i++;
            }
            Choose(selectedIndex);
        }

        private void Choose(int index)
        {
            _sel = index;
            for (int k = 0; k < Controls.Count; k++)
            {
                var b = Controls[k] as FlatButton;
                if (b != null) b.Style = k == index ? BtnStyle.ChipSelected : BtnStyle.Chip;
            }
        }
    }

    /// <summary>Rounded optional date picker (tick the box to set a date).</summary>
    internal class DateBox : RoundedPanel
    {
        public DateTimePicker Inner { get; private set; }

        public DateBox()
        {
            Radius = 8; FillColor = Theme.Background; BorderColor = Theme.ControlBorder; Height = 36;
            Inner = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom, CustomFormat = "MMM d, yyyy", ShowCheckBox = true, Checked = false,
                Font = Theme.Body(10f), MaxDate = DateTime.Today.AddDays(1)
            };
            Controls.Add(Inner);
            DoLayout();
        }

        public DateTime? Value
        {
            get { return Inner.Checked ? (DateTime?)Inner.Value.Date : null; }
            set
            {
                if (value.HasValue) { Inner.Value = value.Value > Inner.MaxDate ? Inner.MaxDate : value.Value; Inner.Checked = true; }
                else Inner.Checked = false;
            }
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); DoLayout(); }

        private void DoLayout()
        {
            if (Inner == null) return;
            Inner.SetBounds(12, Math.Max(0, (Height - Inner.Height) / 2), Math.Max(10, Width - 24), Inner.Height);
        }
    }
}
