using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>Five stars the person can click to choose a rating (or just show one, when ReadOnly).</summary>
    internal class StarPicker : Control
    {
        private int _value, _hover;
        public bool ReadOnly { get; set; }
        public int StarSize { get; set; } = 22;
        public event Action ValueChanged;

        public StarPicker()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Height = 28; Width = 150; Cursor = Cursors.Hand;
        }

        public int Value { get { return _value; } set { _value = Math.Max(0, Math.Min(5, value)); Invalidate(); if (ValueChanged != null) ValueChanged(); } }

        private int IndexAt(int x) { return Math.Max(1, Math.Min(5, x / (StarSize + 6) + 1)); }

        protected override void OnMouseMove(MouseEventArgs e) { if (!ReadOnly) { _hover = IndexAt(e.X); Invalidate(); } base.OnMouseMove(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = 0; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e) { if (!ReadOnly) Value = IndexAt(e.X); base.OnMouseClick(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            GraphicsUtil.HighQuality(e.Graphics);
            int shown = _hover > 0 ? _hover : _value;
            for (int i = 0; i < 5; i++)
                IconPainter.DrawStar(e.Graphics, new Rectangle(i * (StarSize + 6), (Height - StarSize) / 2, StarSize, StarSize), i < shown);
        }
    }

    /// <summary>One customer review: name, date, stars and comment.</summary>
    internal class ReviewRow : Control
    {
        private readonly Review _r;
        private readonly bool _line;

        public ReviewRow(Review r, bool line)
        {
            _r = r; _line = line;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Height = string.IsNullOrWhiteSpace(r.Comment) ? 50 : 76;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; GraphicsUtil.HighQuality(g);
            g.Clear(Theme.Surface);
            var flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
            TextRenderer.DrawText(g, _r.UserName ?? "Customer", Theme.Body(10f, FontStyle.Bold), new Rectangle(0, 8, Width - 140, 20), Theme.Ink, flags);
            for (int i = 0; i < 5; i++)
                IconPainter.DrawStar(g, new Rectangle(Width - 5 * 16 - 2 + i * 16, 11, 13, 13), i < _r.Rating);
            TextRenderer.DrawText(g, _r.CreatedAt.ToString("MMM d, yyyy"), Theme.Body(9f), new Rectangle(0, 28, 200, 16), Theme.Muted, flags);
            if (!string.IsNullOrWhiteSpace(_r.Comment))
                TextRenderer.DrawText(g, _r.Comment, Theme.Body(9.5f), new Rectangle(0, 46, Width, 26), Theme.Ink,
                    TextFormatFlags.Left | TextFormatFlags.Top | TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
            if (_line) using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);
        }
    }
}
