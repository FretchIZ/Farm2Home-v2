using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Domain.Enums;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    internal enum BadgeKind { Neutral, Warning, Info, Success, Danger }

    /// <summary>Small colored pill, e.g. an order status. Sizes itself to its text.</summary>
    internal class StatusBadge : Control
    {
        private BadgeKind _kind = BadgeKind.Neutral;

        public StatusBadge()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Font = Theme.Body(9f, FontStyle.Bold);
            Height = 24;
        }

        /// <summary>Optional icon drawn before the text.</summary>
        public string IconName { get; set; }

        public void Set(string text, BadgeKind kind, string icon = null)
        {
            _kind = kind; IconName = icon;
            Text = text;
            var w = TextRenderer.MeasureText(text ?? "", Font, new Size(int.MaxValue, int.MaxValue),
                TextFormatFlags.NoPadding | TextFormatFlags.SingleLine).Width;
            Size = new Size(w + 22 + (icon != null ? 16 : 0), 24);
            Invalidate();
        }

        public void SetOrderStatus(OrderStatus status)
        {
            BadgeKind kind;
            switch (status)
            {
                case OrderStatus.Pending: kind = BadgeKind.Warning; break;
                case OrderStatus.Confirmed:
                case OrderStatus.Preparing: kind = BadgeKind.Info; break;
                case OrderStatus.ReadyForDelivery:
                case OrderStatus.OutForDelivery: kind = BadgeKind.Success; break;
                case OrderStatus.Cancelled: kind = BadgeKind.Danger; break;
                default: kind = BadgeKind.Neutral; break;
            }
            Set(OrderStatusText.Of(status), kind);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);

            Color bg, fg;
            switch (_kind)
            {
                case BadgeKind.Warning: bg = Theme.MarigoldSoft; fg = Theme.MarigoldText; break;
                case BadgeKind.Info: bg = Theme.InfoSoft; fg = Theme.Info; break;
                case BadgeKind.Success: bg = Theme.MossLight; fg = Theme.Forest; break;
                case BadgeKind.Danger: bg = Theme.DangerSoft; fg = Theme.Danger; break;
                default: bg = Theme.NeutralBadge; fg = Theme.Muted; break;
            }
            using (var path = GraphicsUtil.RoundedRect(new RectangleF(0, 0, Width - 1, Height - 1), Height / 2f))
            using (var b = new SolidBrush(bg)) g.FillPath(b, path);
            if (IconName != null)
            {
                IconPainter.Draw(g, IconName, new Rectangle(9, (Height - 12) / 2, 12, 12), fg, 1.5f);
                TextRenderer.DrawText(g, Text, Font, new Rectangle(25, 0, Width - 25, Height), fg,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
            }
            else
                TextRenderer.DrawText(g, Text, Font, new Rectangle(0, 0, Width, Height), fg,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        }
    }
}
