using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Controls
{
    /// <summary>A card: rounded corners, subtle border. Use it for every white box in the app.</summary>
    internal class RoundedPanel : Panel
    {
        public int Radius { get; set; } = Theme.CardRadius;
        public Color FillColor { get; set; } = Theme.Surface;
        public Color BorderColor { get; set; } = Theme.Border;
        /// <summary>Outline thickness. 1 normally; fields use 2 while they have keyboard focus.</summary>
        public float BorderWidth { get; set; } = 1f;

        /// <summary>Raised after the card background is drawn, so custom drawing can go on top of it.</summary>
        public event PaintEventHandler PostPaint;

        public RoundedPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            GraphicsUtil.HighQuality(g);
            float inset = BorderWidth / 2f, grow = BorderWidth - 1f;
            var r = new RectangleF(inset, inset, Width - 1.5f - grow, Height - 1.5f - grow);
            using (var path = GraphicsUtil.RoundedRect(r, Radius))
            using (var fill = new SolidBrush(FillColor))
            using (var pen = new Pen(BorderColor, BorderWidth))
            {
                g.FillPath(fill, path);
                if (BorderColor != Color.Transparent) g.DrawPath(pen, path);
            }
            if (PostPaint != null) PostPaint(this, e);
        }
    }
}
