using System;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>List of cooperatives.</summary>
    internal sealed class CooperativesView : BaseView
    {
        private readonly AutoLabel _count = Ui.Sub("");
        private readonly GridPanel _grid = new GridPanel { MinItemWidth = 280, ItemHeight = 250 };

        public CooperativesView()
        {
            Page.Add(Ui.Title("Cooperatives"), 4);
            Page.Add(_count, 20);
            Page.Add(_grid, 0);
        }

        public override void OnNavigatedTo(object arg)
        {
            try
            {
                string search = arg as string;
                var list = AppServices.Catalog.GetCooperatives(search);
                _grid.SetItems(list.Select(c => (Control)NewCoopCard(c)));
                _count.Text = list.Count + " " + Ui.Plural(list.Count, "cooperative", "cooperatives") +
                              (string.IsNullOrWhiteSpace(search) ? "" : " for \u201C" + search + "\u201D");
            }
            catch (Exception ex) { ShowError(ex, "loading cooperatives"); }
        }
    }
}
