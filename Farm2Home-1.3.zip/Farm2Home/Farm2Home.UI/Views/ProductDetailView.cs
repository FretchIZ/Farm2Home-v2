using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application.DTOs;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 04: product detail with stock-aware quantity selector.</summary>
    internal sealed class ProductDetailView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            try
            {
                var p = AppServices.Catalog.GetProduct(Convert.ToInt32(arg));
                Build(p);
            }
            catch (Exception ex)
            {
                ShowError(ex, "loading the product");
                Defer(() => Nav.NavigateRoot(CurrentUser.Role == UserRole.Cooperative ? ViewId.CoopDashboard : ViewId.Browse));
            }
        }

        private void Build(Product p)
        {
            Page.Clear();
            var coop = AppServices.Catalog.GetCooperative(p.CooperativeId);
            var crumbs = new Crumbs();
            crumbs.SetParts("Home", p.CategoryName ?? "Browse", p.ProductName);
            crumbs.PartClicked += i =>
            {
                if (i == 0) Nav.NavigateRoot(CurrentUser.Role == UserRole.Cooperative ? ViewId.CoopDashboard : ViewId.Home);
                else Nav.NavigateRoot(ViewId.Browse, new ProductFilter { CategoryId = p.CategoryId });
            };
            Page.Add(crumbs, 14);

            // left: picture + thumbnail strip
            var left = new VStack();
            left.Add(new ImageBox { Height = 330, ImageFile = p.ImagePath, Radius = 12 }, 0);

            var info = new VStack();
            var tag = new StatusBadge();
            if (coop.IsOrganicCertified) tag.Set("Organic certified", BadgeKind.Success, Icons.Check);
            else tag.Set(p.CategoryName ?? "Produce", BadgeKind.Success);
            info.AddFixed(tag, 10);
            info.Add(new AutoLabel { Text = p.ProductName, Font = Theme.Heading(20f), ForeColor = Theme.Ink }, 6);

            // cooperative link + rating
            var meta = new Panel { Height = 22 };
            var coopLink = new Label { Text = p.CooperativeName, AutoSize = true, Cursor = Cursors.Hand, ForeColor = Theme.Forest, Font = Theme.Body(10f, FontStyle.Bold), UseMnemonic = false, BackColor = Color.Transparent };
            coopLink.Location = new Point(22, 3);
            coopLink.Click += (s, e) => Nav.NavigateTo(ViewId.CooperativeProfile, p.CooperativeId);
            int ratingX = 22 + TextRenderer.MeasureText(p.CooperativeName ?? "", coopLink.Font).Width + 22;
            meta.Paint += (s, e) =>
            {
                GraphicsUtil.HighQuality(e.Graphics);
                IconPainter.Draw(e.Graphics, Icons.Cooperatives, new Rectangle(0, 3, 16, 16), Theme.Forest, 1.3f);
                IconPainter.DrawStar(e.Graphics, new Rectangle(ratingX, 5, 12, 12), p.ReviewCount > 0);
                TextRenderer.DrawText(e.Graphics, RatingText.Long(p.AvgRating, p.ReviewCount), Theme.Body(9.5f),
                    new Rectangle(ratingX + 17, 0, 200, 22), Theme.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
            meta.Controls.Add(coopLink);
            info.Add(meta, 12);

            // price
            var price = new Panel { Height = 36 };
            string money = Ui.Money(p.Price), per = "per " + Ui.UnitName(p.Unit);
            var pf = Theme.Heading(21f); var pfBold = new Font(pf, FontStyle.Bold);
            int mw = TextRenderer.MeasureText(money, pfBold, new Size(400, 60), TextFormatFlags.NoPadding).Width;
            price.Paint += (s, e) =>
            {
                TextRenderer.DrawText(e.Graphics, money, pfBold, new Rectangle(0, 0, mw + 4, 36), Theme.Deep, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(e.Graphics, per, Theme.Body(10.5f), new Rectangle(mw + 10, 4, 200, 30), Theme.Ink, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
            info.Add(price, 8);

            var stock = new StatusBadge();
            if (p.InStock)
                stock.Set(p.StockQuantity + " " + p.Unit + " available" +
                          (string.IsNullOrWhiteSpace(p.HarvestInfo) ? "" : " \u00B7 harvested " + Ui.HarvestLabel(p.HarvestInfo)), BadgeKind.Warning, Icons.Check);
            else stock.Set("Out of stock", BadgeKind.Danger);
            info.AddFixed(stock, 14);

            info.Add(Ui.Text(p.Description, 10f, FontStyle.Regular, Theme.Muted), 14);
            var facts = new WrapRow { Gap = 18 };
            facts.Controls.Add(new FactItem("Harvested", Ui.HarvestLabel(p.HarvestInfo)));
            facts.Controls.Add(new FactItem("Origin", p.CooperativeLocation));
            facts.Controls.Add(new FactItem("Min. order", "1 " + p.Unit));
            info.Add(facts, 18);

            if (CurrentUser.Role == UserRole.Consumer)
            {
                if (p.InStock)
                {
                    var qty = new QuantitySelector { Unit = p.Unit, Max = p.StockQuantity };
                    qty.LimitReached += () => Info("Only " + p.StockQuantity + " " + p.Unit + " available.", true);
                    var add = Ui.Button("Add to cart", BtnStyle.Outline, 112, 40);
                    add.BorderOverride = Theme.Forest; add.TextColorOverride = Theme.Forest;
                    var buy = Ui.Button("Buy now", BtnStyle.Accent, 100, 40);
                    add.Click += (s, e) => AddToCart(p, qty.Value, false);
                    buy.Click += (s, e) => AddToCart(p, qty.Value, true);
                    info.Add(Ui.Buttons(qty, add, buy), 0);
                }
                else info.Add(Ui.Text("This product is currently unavailable.", 10.5f, FontStyle.Bold, Theme.Danger), 0);
            }
            Page.Add(new TwoColumn(left, info, 0, false) { Gap = 36, StackBelow = 800, FirstWidth = 400 }, 22);

            // cooperative strip
            var strip = new RoundedPanel { Height = 90, Radius = 12 };
            strip.Controls.Add(new IconTile(Icons.Cooperatives, 52) { Location = new Point(20, 19), Radius = 10 });
            string line2 = (coop.MemberFarmers.HasValue ? coop.MemberFarmers + " member-farmers \u00B7 " : "") + coop.Location + (coop.IsOrganicCertified ? " \u00B7 Organic certified" : "");
            strip.PostPaint += (s, e) =>
            {
                TextRenderer.DrawText(e.Graphics, coop.Name, Theme.Body(10.5f, FontStyle.Bold), new Rectangle(86, 20, strip.Width - 300, 24), Theme.Ink, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                TextRenderer.DrawText(e.Graphics, line2, Theme.Body(9.5f), new Rectangle(86, 46, strip.Width - 300, 22), Theme.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
            };
            var visit = Ui.Button("Visit cooperative", BtnStyle.Outline, 140, 36);
            visit.Click += (s, e) => Nav.NavigateTo(ViewId.CooperativeProfile, p.CooperativeId);
            strip.Controls.Add(visit);
            strip.Resize += (s, e) => visit.Location = new Point(strip.Width - visit.Width - 20, (strip.Height - visit.Height) / 2);
            Page.Add(strip, 26);

            Page.Add(BuildReviews(p), 26);

            var related = AppServices.Catalog.Browse(new ProductFilter { CategoryId = p.CategoryId, InStockOnly = true, Take = 5 })
                .Where(r => r.ProductId != p.ProductId).Take(4).ToList();
            if (related.Count > 0)
            {
                Page.Add(Ui.Section("You might also like"), 12);
                var grid = new GridPanel { MinItemWidth = 200, ItemHeight = 236 };
                Page.Add(grid, 0);
                grid.SetItems(related.Select(r => (Control)NewProductCard(r)));
            }
        }

        /// <summary>Real customer reviews. Someone whose order with this product was delivered can add or change their own review.</summary>
        private Card BuildReviews(Product p)
        {
            var card = new Card { Inset = 22 };
            var reviews = AppServices.Engagement.GetReviews(p.ProductId);
            card.Body.Add(Ui.Section("Customer reviews  \u00B7  " + RatingText.Long(p.AvgRating, reviews.Count)), 10);
            if (reviews.Count == 0)
                card.Body.Add(Ui.Muted("No one has reviewed this product yet."), 6);
            for (int i = 0; i < Math.Min(6, reviews.Count); i++) card.Body.Add(new ReviewRow(reviews[i], i < Math.Min(6, reviews.Count) - 1), 0);

            if (AppServices.Engagement.CanReview(p.ProductId))
            {
                var mine = reviews.FirstOrDefault(r => r.UserId == CurrentUser.UserId);
                card.Body.Add(new Divider(), 14);
                card.Body.Add(Ui.Text(mine == null ? "Rate this product" : "Update your review", 10.5f, FontStyle.Bold, Theme.Ink, Theme.Surface), 8);
                var stars = new StarPicker { Value = mine == null ? 0 : mine.Rating };
                card.Body.AddFixed(stars, 8);
                var comment = new InputBox(true) { Placeholder = "Share a few words about the produce (optional)", MaxLength = 500, Text = mine == null ? "" : mine.Comment };
                card.Body.Add(comment, 10);
                var submit = Ui.Button(mine == null ? "Submit review" : "Save review", BtnStyle.Primary, 150, 38);
                submit.Click += (s, e) =>
                {
                    try
                    {
                        AppServices.Engagement.SubmitReview(p.ProductId, stars.Value, comment.Text);
                        Info("\u2713 Thanks! Your review was saved.");
                        Defer(() => Build(AppServices.Catalog.GetProduct(p.ProductId)));
                    }
                    catch (Exception ex) { ShowError(ex, "saving your review"); }
                };
                card.Body.AddFixed(submit, 0);
            }
            else if (CurrentUser.Role == UserRole.Consumer)
                card.Body.Add(Ui.Muted("You can review this product after an order that includes it has been delivered."), 0);
            return card;
        }

        private void AddToCart(Product p, int quantity, bool thenOpenCart)
        {
            try
            {
                AppServices.Cart.Add(p.ProductId, quantity);
                NotifyCartChanged();
                Info("\u2713 Added " + quantity + " " + p.Unit + " of " + p.ProductName + " to your cart.");
                if (thenOpenCart) Defer(() => Nav.NavigateTo(ViewId.Cart));
            }
            catch (Exception ex) { ShowError(ex, "adding that item to your cart"); }
        }
    }
}
