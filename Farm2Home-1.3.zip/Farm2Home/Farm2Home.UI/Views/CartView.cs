using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application.Services;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 05: shopping cart grouped by cooperative.</summary>
    internal sealed class CartView : BaseView
    {
        public override void OnNavigatedTo(object arg) { Render(); }

        private void Render()
        {
            if (IsDisposed) return;
            try
            {
                var cart = AppServices.Cart.GetCart();
                Page.Clear();
                int lines = cart.Items.Count;
                Page.Add(Ui.Title("Your cart (" + lines + " " + Ui.Plural(lines, "item", "items") + ")"), 16);

                if (lines == 0)
                {
                    var empty = new Card();
                    empty.Body.Add(Ui.Text("Your cart is empty.", 13f, FontStyle.Bold, Theme.Ink, Theme.Surface), 6);
                    empty.Body.Add(Ui.Text("Browse fresh produce from local cooperatives and add what you like.", 10.5f, FontStyle.Regular, Theme.Muted, Theme.Surface), 16);
                    var browse = Ui.Button("Browse produce", BtnStyle.Accent, 190, 46);
                    browse.Click += (s, e) => Nav.NavigateRoot(ViewId.Browse);
                    empty.Body.AddFixed(browse, 0);
                    Page.Add(empty, 0);
                    return;
                }

                var left = new VStack();
                var groups = cart.Items.GroupBy(i => i.Product.CooperativeId).ToList();
                foreach (var g in groups)
                {
                    var card = new CartGroupCard(g.First().Product.CooperativeName);
                    var items = g.ToList();
                    for (int i = 0; i < items.Count; i++)
                        card.Rows.Add(BuildRow(items[i], i < items.Count - 1), 0);
                    left.Add(card, 14);
                }

                bool problem = cart.Items.Any(i => !i.Product.InStock || i.Quantity > i.Product.StockQuantity);
                decimal delivery = groups.Count * OrderService.DeliveryFeePerOrder;
                var applied = AppServices.Engagement.AppliedPromo;
                decimal discount = applied == null ? 0m : groups.Sum(g => OrderService.DiscountFor(g.Sum(i => i.Subtotal), applied.Percent));

                var sum = new Card { Inset = 18, Radius = 12 };
                sum.Body.Add(Ui.Text("Order summary", 11f, FontStyle.Bold, Theme.Ink, Theme.Surface), 12);
                sum.Body.Add(new PairRow("Subtotal (" + lines + " " + Ui.Plural(lines, "item", "items") + ")", Ui.Money(cart.Subtotal)), 2);
                sum.Body.Add(new PairRow("Delivery fee", Ui.Money(delivery)), 0);
                sum.Body.Add(Ui.Text("One delivery fee per cooperative (" + groups.Count + " \u00D7 " + Ui.Money(OrderService.DeliveryFeePerOrder) + ").",
                    9f, FontStyle.Regular, Theme.Muted, Theme.Surface), 10);

                var promo = new InputBox { Placeholder = "Promo code", MaxLength = 20, Height = 36, Text = applied == null ? "" : applied.Code, ReadOnly = applied != null };
                var apply = Ui.Button(applied == null ? "Apply" : "Remove", BtnStyle.Outline, applied == null ? 62 : 78, 36);
                apply.Click += (s, e) =>
                {
                    try
                    {
                        if (applied == null) { var p = AppServices.Engagement.ApplyPromo(promo.Text); Info("\u2713 Promo " + p.Code + " applied: " + p.Percent + "% off produce."); }
                        else { AppServices.Engagement.ClearPromo(); Info("Promo code removed."); }
                    }
                    catch (Exception ex) { ShowError(ex, "applying that promo code"); return; }
                    Defer(Render);
                };
                promo.EnterPressed += () => apply.PerformClick();
                var promoRow = new Panel { Height = 36 };
                promoRow.Controls.Add(promo); promoRow.Controls.Add(apply);
                promoRow.Resize += (s, e) => { apply.Location = new Point(promoRow.Width - apply.Width, 0); promo.SetBounds(0, 0, Math.Max(40, promoRow.Width - apply.Width - 8), 36); };
                sum.Body.Add(promoRow, discount > 0 ? 10 : 14);
                if (discount > 0)
                    sum.Body.Add(new PairRow("Promo " + applied.Code + " (" + applied.Percent + "% off)", "\u2212" + Ui.Money(discount)) { RightColor = Theme.Forest }, 14);
                sum.Body.Add(new Divider(), 12);
                sum.Body.Add(new PairRow("Total", Ui.Money(cart.Subtotal - discount + delivery), true), 14);
                if (problem)
                    sum.Body.Add(Ui.Text("Please fix the items marked in red before checking out.", 9.5f, FontStyle.Bold, Theme.Danger, Theme.Surface), 10);

                var checkout = Ui.Button("Proceed to checkout", BtnStyle.Accent, 100, 42);
                checkout.Enabled = !problem;
                checkout.Click += (s, e) => Nav.NavigateTo(ViewId.Checkout);
                sum.Body.Add(checkout, 8);
                var secure = new Panel { Height = 20 };
                secure.Paint += (s, e) =>
                {
                    GraphicsUtil.HighQuality(e.Graphics);
                    int tw = TextRenderer.MeasureText("Secure checkout", Theme.Body(9f)).Width, x0 = (secure.Width - tw - 18) / 2;
                    IconPainter.Draw(e.Graphics, Icons.Lock, new Rectangle(x0, 3, 13, 13), Theme.Muted, 1.2f);
                    TextRenderer.DrawText(e.Graphics, "Secure checkout", Theme.Body(9f), new Rectangle(x0 + 18, 0, tw + 4, 20), Theme.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                };
                sum.Body.Add(secure, 8);
                var cont = Ui.Button("Continue shopping", BtnStyle.Ghost, 100, 32);
                cont.Click += (s, e) => Nav.NavigateRoot(ViewId.Browse);
                var clear = Ui.Button("Clear cart", BtnStyle.Ghost, 100, 32);
                clear.Click += (s, e) =>
                {
                    if (!UiErrors.Confirm(this, "Remove everything from your cart?")) return;
                    Defer(() =>
                    {
                        try { AppServices.Cart.Clear(); NotifyCartChanged(); } catch (Exception ex) { ShowError(ex, "clearing your cart"); }
                        Render();
                    });
                };
                sum.Body.Add(cont, 0);
                sum.Body.Add(clear, 0);

                Page.Add(new TwoColumn(left, sum, 300, true) { Gap = 22, StackBelow = 760 }, 0);
            }
            catch (Exception ex) { ShowError(ex, "loading your cart"); }
        }

        private CartRow BuildRow(CartItem item, bool line)
        {
            var row = new CartRow(item, line);
            int id = item.ProductId;
            row.Qty.LimitReached += () => Info("Only " + item.Product.StockQuantity + " " + item.Product.Unit + " available.", true);
            row.Qty.ValueChanged += (s, e) => Defer(() =>
            {
                try { AppServices.Cart.SetQuantity(id, row.Qty.Value); NotifyCartChanged(); }
                catch (Exception ex) { ShowError(ex, "updating the quantity"); }
                Render();
            });
            row.Remove.Click += (s, e) => Defer(() =>
            {
                try { AppServices.Cart.Remove(id); NotifyCartChanged(); }
                catch (Exception ex) { ShowError(ex, "removing that item"); }
                Render();
            });
            return row;
        }

        /// <summary>White card for one cooperative: green header band with its name, then its cart lines.</summary>
        private sealed class CartGroupCard : RoundedPanel
        {
            private readonly string _title;
            public VStack Rows { get; private set; }
            private const int Head = 44;

            public CartGroupCard(string title)
            {
                _title = title; Radius = 12;
                Rows = new VStack { BackColor = Theme.Surface };
                Controls.Add(Rows);
                Rows.SizeChanged += (s, e) => Fit();
                PostPaint += (s, e) =>
                {
                    var g = e.Graphics; GraphicsUtil.HighQuality(g);
                    using (var path = GraphicsUtil.RoundedRect(new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f), Radius))
                    {
                        var st = g.Save(); g.SetClip(path);
                        using (var b = new SolidBrush(Theme.MossLight)) g.FillRectangle(b, 0, 0, Width, Head);
                        g.Restore(st);
                    }
                    using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 1, Head, Width - 2, Head);
                    IconPainter.Draw(g, Icons.Cooperatives, new Rectangle(16, (Head - 16) / 2, 16, 16), Theme.Forest, 1.3f);
                    TextRenderer.DrawText(g, _title, Theme.Body(10f, FontStyle.Bold), new Rectangle(40, 0, Width - 56, Head), Theme.Forest,
                        TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
                };
            }

            protected override void OnResize(EventArgs e) { base.OnResize(e); if (Rows != null) { Rows.SetBounds(1, Head + 1, Width - 2, Rows.Height); Fit(); } }
            private void Fit() { int h = Head + 1 + Rows.Height + 10; if (Height != h) Height = h; }
        }

        /// <summary>One cart line: picture, name, unit price, quantity, subtotal, remove.</summary>
        private sealed class CartRow : Panel
        {
            private readonly bool _line;
            private readonly IconTile _img;
            private readonly AutoLabel _name, _price, _warn, _sub;
            public QuantitySelector Qty { get; private set; }
            public FlatButton Remove { get; private set; }

            public CartRow(CartItem item, bool line)
            {
                _line = line;
                var p = item.Product;
                Height = 88;
                BackColor = Theme.Surface;

                _img = new IconTile(Icons.Products, 56) { Radius = 8 };
                _name = new AutoLabel { Text = p.ProductName, Font = Theme.Body(10.5f, FontStyle.Bold), SingleLine = true };
                _price = Ui.Text(Ui.Money(p.Price) + " / " + p.Unit, 9f, FontStyle.Regular, Theme.Muted);
                _price.SingleLine = true;
                string warn = null;
                if (!p.InStock) warn = "No longer available";
                else if (item.Quantity > p.StockQuantity) warn = "Only " + p.StockQuantity + " " + p.Unit + " available";
                _warn = Ui.Text(warn ?? "", 9f, FontStyle.Bold, Theme.Danger);
                _warn.SingleLine = true;
                _sub = new AutoLabel { Text = Ui.Money(item.Subtotal), Font = Theme.Body(10.5f, FontStyle.Bold), ForeColor = Theme.Deep, TextAlign = ContentAlignment.MiddleRight, SingleLine = true };

                Qty = new QuantitySelector { Unit = "", Max = Math.Max(item.Quantity, p.StockQuantity), Compact = true, Size = new Size(94, 34) };
                Qty.Value = item.Quantity;
                Remove = Ui.Button("", BtnStyle.Ghost, 32, 32);
                Remove.IconName = Icons.Trash; Remove.IconColor = Theme.Muted;

                Controls.AddRange(new Control[] { _img, _name, _price, _warn, _sub, Qty, Remove });
                DoLayout();
            }

            protected override void OnResize(EventArgs eventargs) { base.OnResize(eventargs); DoLayout(); }

            private void DoLayout()
            {
                if (_img == null || Width <= 0) return;
                int xRemove = Width - 16 - 32, xSub = xRemove - 8 - 70, xQty = xSub - 24 - 94;
                _img.Location = new Point(16, 16);
                int nameW = Math.Max(80, xQty - 88 - 12);
                _name.SetBounds(88, 20, nameW, _name.Height);
                _price.SetBounds(88, 40, nameW, _price.Height);
                _warn.SetBounds(88, 58, nameW, _warn.Height);
                Qty.Location = new Point(xQty, (Height - 34) / 2);
                _sub.SetBounds(xSub, (Height - _sub.Height) / 2, 70, _sub.Height);
                Remove.Location = new Point(xRemove, (Height - 32) / 2);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                if (_line) using (var pen = new Pen(Theme.Border)) e.Graphics.DrawLine(pen, 0, Height - 1, Width, Height - 1);
            }
        }
    }
}
