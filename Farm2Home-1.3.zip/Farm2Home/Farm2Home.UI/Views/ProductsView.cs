using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application.DTOs;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 03: product browsing with search, category / cooperative / price / organic filters and sorting.
    /// The database does the searching, price, organic and sorting; the check-box groups are applied on top of that result.</summary>
    internal sealed class ProductsView : BaseView
    {
        private ProductFilter _f = new ProductFilter();
        private readonly List<CheckRow> _catRows = new List<CheckRow>(), _coopRows = new List<CheckRow>();
        private readonly Dictionary<CheckRow, int> _ids = new Dictionary<CheckRow, int>();
        private readonly SelectBox _sort = new SelectBox { FillColor = Theme.Surface, BorderColor = Theme.ControlBorder };
        private readonly RangeSlider _price = new RangeSlider();
        private readonly ToggleRow _organic = new ToggleRow("Organic certified");
        private readonly ToggleRow _inStock = new ToggleRow("In stock only");
        private readonly GridPanel _grid = new GridPanel { MinItemWidth = 190, ItemHeight = 236 };
        private readonly Crumbs _crumb = new Crumbs();
        private readonly AutoLabel _title = new AutoLabel { Text = "Browse produce", Font = Theme.Heading(19f), ForeColor = Theme.Ink };
        private readonly AutoLabel _count = Ui.Sub("");
        private readonly AutoLabel _empty = Ui.Text("No products match your search. Try clearing some filters.", 10.5f, FontStyle.Regular, Theme.Muted);
        private Card _filters;
        private bool _loading;

        public ProductsView()
        {
            var headLeft = new VStack();
            headLeft.Add(_crumb, 4);
            headLeft.Add(_title, 2);
            headLeft.Add(_count, 0);
            _crumb.PartClicked += i => { if (i == 0) Nav.NavigateRoot(ViewId.Home); };
            var headRight = new VStack();
            headRight.Add(_sort, 0);
            headRight.Padding = new Padding(0, 12, 0, 0);
            Page.Add(new TwoColumn(headLeft, headRight, 190, true) { StackBelow = 640 }, 16);

            _sort.SetOptions(new[]
            {
                new SelectOption(ProductSort.RecentlyAdded, "Sort: Newest first"),
                new SelectOption(ProductSort.PriceLowToHigh, "Sort: Price low to high"),
                new SelectOption(ProductSort.PriceHighToLow, "Sort: Price high to low"),
                new SelectOption(ProductSort.NameAToZ, "Sort: Name A to Z")
            });
            _sort.SelectionChanged += Reload;
            _price.RangeChanged += (s, e) => Reload();
            _organic.CheckedChanged += (s, e) => Reload();
            _inStock.CheckedChanged += (s, e) => Reload();

            _filters = new Card { Inset = 18, Radius = 12 };
            var right = new VStack();
            right.Add(_grid, 16);
            right.Add(_empty, 0);
            _empty.Visible = false;
            Page.Add(new TwoColumn(_filters, right, 224, false) { Gap = 22, StackBelow = 760 }, 0);
        }

        private void BuildFilterCard(List<Category> cats, List<Cooperative> coops)
        {
            var b = _filters.Body;
            b.Clear(); _catRows.Clear(); _coopRows.Clear(); _ids.Clear();

            var head = new Panel { Height = 24 };
            var title = Ui.Text("Filters", 10f, FontStyle.Bold, Theme.Ink); title.SingleLine = true; title.SetBounds(0, 2, 100, 20);
            var clear = new Label { Text = "Clear all", AutoSize = true, Cursor = Cursors.Hand, ForeColor = Theme.Forest, Font = Theme.Body(9f, FontStyle.Bold), BackColor = Theme.Surface, UseMnemonic = false };
            clear.Click += (s, e) => { _f = new ProductFilter(); _loading = true; SyncControls(); _loading = false; Reload(); };
            head.Controls.Add(title); head.Controls.Add(clear);
            head.Resize += (s, e) => clear.Location = new Point(head.Width - clear.Width, 4);
            b.Add(head, 8);

            b.Add(Ui.Text("Category", 10f, FontStyle.Bold, Theme.Ink, Theme.Surface), 6);
            foreach (var c in cats) { var r = new CheckRow(c.CategoryName); _ids[r] = c.CategoryId; _catRows.Add(r); r.CheckedChanged += (s, e) => Reload(); b.Add(r, 0); }
            b.Add(new Divider(), 0); b.Controls[b.Controls.Count - 1].Margin = new Padding(0, 10, 0, 12);

            b.Add(Ui.Text("Cooperative", 10f, FontStyle.Bold, Theme.Ink, Theme.Surface), 6);
            foreach (var c in coops) { var r = new CheckRow(c.Name); _ids[r] = c.CooperativeId; _coopRows.Add(r); r.CheckedChanged += (s, e) => Reload(); b.Add(r, 0); }
            b.Add(new Divider(), 0); b.Controls[b.Controls.Count - 1].Margin = new Padding(0, 10, 0, 12);

            b.Add(Ui.Text("Price range", 10f, FontStyle.Bold, Theme.Ink, Theme.Surface), 6);
            b.Add(_price, 6);
            b.Add(new Divider(), 0); b.Controls[b.Controls.Count - 1].Margin = new Padding(0, 4, 0, 10);
            b.Add(_organic, 0);
            b.Add(_inStock, 12);
            var apply = Ui.Button("Apply filters", BtnStyle.Primary, 100, 36);
            apply.Click += (s, e) => Reload();
            b.Add(apply, 0);
        }

        public override void OnNavigatedTo(object arg)
        {
            _f = new ProductFilter();
            var text = arg as string;
            var pf = arg as ProductFilter;
            if (text != null) _f.Search = text;
            else if (pf != null) _f = pf;

            try
            {
                _loading = true;
                var cats = AppServices.Catalog.GetCategories();
                var coops = AppServices.Catalog.GetCooperatives();
                BuildFilterCard(cats, coops);

                var all = AppServices.Catalog.Browse(new ProductFilter());
                decimal lo = all.Count == 0 ? 0 : Math.Floor(all.Min(p => p.Price)), hi = all.Count == 0 ? 100 : Math.Ceiling(all.Max(p => p.Price));
                _price.SetBounds(lo, hi, _f.MinPrice ?? lo, _f.MaxPrice ?? hi);
                SyncControls();
                _loading = false;
                Reload();
            }
            catch (Exception ex) { _loading = false; ShowError(ex, "loading products"); }
        }

        private void SyncControls()
        {
            foreach (var r in _catRows) r.Checked = _f.CategoryId.HasValue && _ids[r] == _f.CategoryId.Value;
            foreach (var r in _coopRows) r.Checked = _f.CooperativeId.HasValue && _ids[r] == _f.CooperativeId.Value;
            _price.SetBounds(_price.Minimum, _price.Maximum, _f.MinPrice ?? _price.Minimum, _f.MaxPrice ?? _price.Maximum);
            _sort.Select(_f.Sort);
            _organic.Checked = _f.OrganicOnly;
            _inStock.Checked = _f.InStockOnly;
        }

        private void Reload()
        {
            if (_loading) return;
            try
            {
                var sv = _sort.SelectedValue;
                _f.Sort = sv == null ? ProductSort.RecentlyAdded : (ProductSort)sv;
                _f.OrganicOnly = _organic.Checked; _f.InStockOnly = _inStock.Checked;
                _f.MinPrice = _price.IsNarrowed ? _price.Low : (decimal?)null;
                _f.MaxPrice = _price.IsNarrowed ? _price.High : (decimal?)null;
                var selCats = new HashSet<int>(_catRows.Where(r => r.Checked).Select(r => _ids[r]));
                var selCoops = new HashSet<int>(_coopRows.Where(r => r.Checked).Select(r => _ids[r]));
                _f.CategoryId = selCats.Count == 1 ? selCats.First() : (int?)null;
                _f.CooperativeId = selCoops.Count == 1 ? selCoops.First() : (int?)null;

                // everything except the two check-box groups is done by the database
                var baseFilter = new ProductFilter { Search = _f.Search, MinPrice = _f.MinPrice, MaxPrice = _f.MaxPrice, InStockOnly = _f.InStockOnly, OrganicOnly = _f.OrganicOnly, Sort = _f.Sort };
                var baseList = AppServices.Catalog.Browse(baseFilter);
                foreach (var r in _catRows) r.Count = baseList.Count(p => p.CategoryId == _ids[r]);
                foreach (var r in _coopRows) r.Count = baseList.Count(p => p.CooperativeId == _ids[r]);
                foreach (var r in _catRows.Concat(_coopRows)) r.Invalidate();

                var list = baseList.Where(p => (selCats.Count == 0 || selCats.Contains(p.CategoryId)) && (selCoops.Count == 0 || selCoops.Contains(p.CooperativeId))).ToList();
                _grid.SetItems(list.Select(p => (Control)NewProductCard(p)));

                string cat = selCats.Count == 1 ? _catRows.First(r => r.Checked).Text : null;
                _title.Text = cat ?? (string.IsNullOrWhiteSpace(_f.Search) ? "Browse produce" : "Search results");
                _crumb.SetParts("Home", cat ?? "Browse");

                int coops = list.Select(p => p.CooperativeId).Distinct().Count();
                _count.Text = list.Count + " " + Ui.Plural(list.Count, "product", "products") + " from " + coops + " " + Ui.Plural(coops, "cooperative", "cooperatives") +
                              (string.IsNullOrWhiteSpace(_f.Search) ? "" : " for “" + _f.Search + "”");
                _empty.Visible = list.Count == 0;
            }
            catch (Exception ex) { ShowError(ex, "loading products"); }
        }
    }
}
