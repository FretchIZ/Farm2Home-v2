using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Incoming orders for the cooperative, with one-step status updates.</summary>
    internal sealed class CoopOrdersView : BaseView
    {
        private readonly DataGridView _grid = Tables.Create();
        private readonly RoundedPanel _card;
        private readonly AutoLabel _count = Ui.Sub("");
        private readonly AutoLabel _detail = Ui.Text("Select an order to see its details.", 10.5f, FontStyle.Regular, Theme.Muted, Theme.Surface);
        private readonly FlatButton _advance = Ui.Button("Mark as next step", BtnStyle.Accent, 230, 46);
        private readonly FlatButton _cancel = Ui.Button("Cancel order", BtnStyle.Outline, 160, 46);
        private int _selectedId;

        public CoopOrdersView()
        {
            Page.Add(Ui.Title("Orders"), 4);
            Page.Add(_count, 20);

            Tables.AddColumn(_grid, "Order", 16);
            Tables.AddColumn(_grid, "Date", 20);
            Tables.AddColumn(_grid, "Consumer", 18);
            Tables.AddColumn(_grid, "Items", 24);
            Tables.AddColumn(_grid, "Total", 10);
            Tables.AddColumn(_grid, "Payment", 10);
            Tables.AddColumn(_grid, "Status", 16);
            Tables.UsePills(_grid, 6);
            _grid.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex != 6) return;
                var o = _grid.Rows[e.RowIndex].Tag as Order;
                if (o == null) return;
                e.CellStyle.ForeColor = Tables.StatusColor(o.OrderStatus);
                e.CellStyle.Font = Theme.Body(10f, FontStyle.Bold);
            };
            _grid.SelectionChanged += (s, e) => ShowSelected();
            _card = Tables.Wrap(_grid);
            Page.Add(_card, 20);

            var details = new Card { Inset = 22 };
            details.Body.Add(Ui.Section("Order details"), 10);
            details.Body.Add(_detail, 16);
            _advance.Click += (s, e) => Advance();
            _cancel.Click += (s, e) => CancelOrder();
            details.Body.Add(Ui.Buttons(_advance, _cancel), 0);
            Page.Add(details, 0);
            _advance.Enabled = false;
            _cancel.Enabled = false;
        }

        public override void OnNavigatedTo(object arg)
        {
            if (arg is int) _selectedId = (int)arg;
            Reload();
        }

        private Order Selected()
        {
            return _grid.CurrentRow == null ? null : _grid.CurrentRow.Tag as Order;
        }

        private void Reload()
        {
            if (IsDisposed) return;
            try
            {
                var orders = AppServices.Orders.GetCooperativeOrders();
                _grid.Rows.Clear();
                int reselect = -1;
                foreach (var o in orders)
                {
                    int i = _grid.Rows.Add(o.OrderNumber, o.OrderDate.ToString("MMM d, h:mm tt"), o.CustomerName, Ui.ItemsSummary(o),
                        Ui.Money(o.Total), o.PaymentStatus, OrderStatusText.Of(o.OrderStatus));
                    _grid.Rows[i].Tag = o;
                    if (o.OrderId == _selectedId) reselect = i;
                }
                Tables.Fit(_card, _grid, 10);
                _count.Text = orders.Count + " " + Ui.Plural(orders.Count, "order", "orders");
                if (orders.Count > 0)
                {
                    int target = reselect >= 0 ? reselect : 0;
                    _grid.ClearSelection();
                    _grid.CurrentCell = _grid.Rows[target].Cells[0];
                    _grid.Rows[target].Selected = true;
                }
                ShowSelected();
            }
            catch (Exception ex) { ShowError(ex, "loading orders"); }
        }

        private void ShowSelected()
        {
            var o = Selected();
            if (o == null)
            {
                _detail.Text = "No orders yet. They will appear here as consumers check out.";
                _advance.Enabled = false; _cancel.Enabled = false;
                return;
            }
            _selectedId = o.OrderId;
            var lines = o.Items.Select(i => "\u2022 " + i.ProductName + " \u00D7" + i.Quantity + " @ " + Ui.Money(i.UnitPrice) + " = " + Ui.Money(i.Subtotal));
            _detail.Text = o.OrderNumber + "  \u00B7  " + OrderStatusText.Of(o.OrderStatus) + Environment.NewLine +
                           "Consumer: " + o.CustomerName + "  \u00B7  " + o.ContactNumber + Environment.NewLine +
                           "Deliver to: " + o.DeliveryAddress + Environment.NewLine +
                           "Payment: " + Ui.PaymentText(o.PaymentMethod) + " (" + o.PaymentStatus + ")" + Environment.NewLine + Environment.NewLine +
                           string.Join(Environment.NewLine, lines) + Environment.NewLine +
                           "Subtotal " + Ui.Money(o.Subtotal) + "  +  Delivery " + Ui.Money(o.DeliveryFee) + (o.Discount > 0 ? "  \u2212  Promo " + o.PromoCode + " " + Ui.Money(o.Discount) : "") + "  =  Total " + Ui.Money(o.Total);

            bool open = o.OrderStatus != OrderStatus.Delivered && o.OrderStatus != OrderStatus.Cancelled;
            _advance.Enabled = open;
            _advance.Text = open ? "Mark as " + OrderStatusText.Of((OrderStatus)((int)o.OrderStatus + 1)) : "Order closed";
            _cancel.Enabled = o.OrderStatus == OrderStatus.Pending || o.OrderStatus == OrderStatus.Confirmed;
        }

        private void Advance()
        {
            var o = Selected();
            if (o == null) return;
            var next = (OrderStatus)((int)o.OrderStatus + 1);
            try
            {
                AppServices.Orders.UpdateStatus(o.OrderId, next);
                Info("\u2713 " + o.OrderNumber + " is now " + OrderStatusText.Of(next) + ".");
                NotifyCartChanged();
                Reload();
            }
            catch (Exception ex) { ShowError(ex, "updating the order"); Reload(); }
        }

        private void CancelOrder()
        {
            var o = Selected();
            if (o == null) return;
            if (!UiErrors.Confirm(this, "Cancel order " + o.OrderNumber + "? The items will be returned to stock.")) return;
            try
            {
                AppServices.Orders.UpdateStatus(o.OrderId, OrderStatus.Cancelled);
                Info("Order " + o.OrderNumber + " cancelled.");
                NotifyCartChanged();
                Reload();
            }
            catch (Exception ex) { ShowError(ex, "cancelling the order"); Reload(); }
        }
    }
}
