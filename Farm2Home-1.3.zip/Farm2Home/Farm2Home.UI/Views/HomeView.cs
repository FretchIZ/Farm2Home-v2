using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application.DTOs;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 02: consumer home dashboard.</summary>
    internal sealed class HomeView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            try
            {
                Page.Clear();
                string first = (CurrentUser.FullName ?? "").Split(' ')[0];
                Page.Add(Ui.Title(Ui.Greeting() + ", " + first), 4);
                Page.Add(Ui.Sub("Here's what's fresh from your favorite cooperatives today."), 18);

                var latest = AppServices.Catalog.Browse(new ProductFilter { InStockOnly = true, Sort = ProductSort.RecentlyAdded, Take = 12 });
                HeroBanner hero;
                if (latest.Count > 0)
                {
                    var lead = latest[0];
                    var names = latest.Where(p => p.CooperativeId == lead.CooperativeId).Select(p => p.ProductName.ToLower()).Distinct().Take(3).ToList();
                    string list = names.Count == 1 ? names[0] : string.Join(", ", names.Take(names.Count - 1)) + " and " + names.Last();
                    string coopFirst = (lead.CooperativeName ?? "").Split(' ')[0];
                    hero = new HeroBanner("SEASONAL PICK", coopFirst + "'s fresh harvest is in",
                        list.Substring(0, 1).ToUpper() + list.Substring(1) + " picked this week by " + lead.CooperativeName + " \u2014 fresh from " + lead.CooperativeLocation + ".",
                        "Shop " + coopFirst + " produce");
                    int coopId = lead.CooperativeId;
                    hero.ButtonClicked += () => Nav.NavigateRoot(ViewId.Browse, new ProductFilter { CooperativeId = coopId });
                }
                else
                {
                    hero = new HeroBanner("FRESH FROM THE FARM", "Local harvest, direct to your home.",
                        "Order organic produce straight from Philippine farmer cooperatives \u2014 fair prices for growers, honest prices for you.",
                        "Browse fresh produce");
                    hero.ButtonClicked += () => Nav.NavigateRoot(ViewId.Browse);
                }
                Page.Add(hero, 20);

                var chips = new WrapRow();
                chips.Controls.Add(Chip("All produce", null, true));
                foreach (var c in AppServices.Catalog.GetCategories()) chips.Controls.Add(Chip(c.CategoryName, c.CategoryId, false));
                Page.Add(chips, 24);

                var coops = AppServices.Catalog.GetCooperatives().Take(3).ToList();
                if (coops.Count > 0)
                {
                    var h = new SectionHeader("Cooperatives near you", "See all");
                    h.LinkClicked += () => Nav.NavigateRoot(ViewId.Cooperatives);
                    Page.Add(h, 8);
                    var grid = new GridPanel { MinItemWidth = 260, ItemHeight = 180, Gap = 18 };
                    Page.Add(grid, 26);
                    grid.SetItems(coops.Select(c => (Control)NewCoopCard(c)));
                }

                var fresh = AppServices.Catalog.Browse(new ProductFilter { InStockOnly = true, Sort = ProductSort.RecentlyAdded, Take = 4 });
                var h2 = new SectionHeader("Fresh this week", "See all");
                h2.LinkClicked += () => Nav.NavigateRoot(ViewId.Browse);
                Page.Add(h2, 8);
                if (fresh.Count == 0) Page.Add(Ui.Muted("No produce is listed yet. Please check back soon."), 0);
                else
                {
                    var grid2 = new GridPanel { MinItemWidth = 200, ItemHeight = 236 };
                    Page.Add(grid2, 0);
                    grid2.SetItems(fresh.Select(p => (Control)NewProductCard(p)));
                }
            }
            catch (Exception ex) { ShowError(ex, "loading the home page"); }
        }

        private static string CategoryIcon(string name)
        {
            string n = (name ?? "").ToLowerInvariant();
            if (n.Contains("fruit")) return Icons.Apple;
            if (n.Contains("rice") || n.Contains("grain")) return Icons.Grain;
            if (n.Contains("cacao") || n.Contains("coffee")) return Icons.Bean;
            if (n.Contains("root")) return Icons.Sprout;
            return Icons.Products;
        }

        private FlatButton Chip(string text, int? categoryId, bool primary)
        {
            var f = Theme.Body(9.5f, FontStyle.Bold);
            int w = TextRenderer.MeasureText(text, f, new Size(400, 40), TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix).Width + 56;
            var b = Ui.Button(text, primary ? BtnStyle.Primary : BtnStyle.Outline, w, 34);
            b.Font = f; b.Radius = 17;
            b.IconName = primary ? Icons.Products : CategoryIcon(text);
            b.IconColor = primary ? Theme.Marigold : Theme.Forest;
            b.TextColorOverride = primary ? Color.White : Theme.Forest;
            b.Click += (s, e) => Nav.NavigateRoot(ViewId.Browse, categoryId.HasValue ? new ProductFilter { CategoryId = categoryId } : new ProductFilter());
            return b;
        }
    }
}
