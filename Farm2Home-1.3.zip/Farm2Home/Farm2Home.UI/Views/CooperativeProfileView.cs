using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 08: cooperative profile with its products. With no argument, shows the signed-in cooperative's own profile.</summary>
    internal sealed class CooperativeProfileView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            try
            {
                int id = arg == null ? CurrentUser.CooperativeId.GetValueOrDefault() : Convert.ToInt32(arg);
                var c = AppServices.Catalog.GetCooperative(id);
                var products = AppServices.Catalog.GetCooperativeProducts(id);
                Page.Clear();
                Padding = new Padding(0, 0, 0, 28);               // the banner runs edge to edge; the sections below get their own side margins

                bool isConsumer = CurrentUser.Role == UserRole.Consumer;
                bool following = isConsumer && AppServices.Engagement.IsFollowing(id);
                string ratingText = RatingText.Long(c.AvgRating, c.ReviewCount) + (c.FollowerCount > 0 ? " \u00B7 " + c.FollowerCount + (c.FollowerCount == 1 ? " follower" : " followers") : "");
                var header = new CoopHeader(c.Name, c.Location, c.MemberFarmers, ratingText, c.IsOrganicCertified, isConsumer);
                header.Follow.Text = following ? "Following" : "Follow";
                header.Follow.Style = following ? BtnStyle.Outline : BtnStyle.Primary;
                header.Message.Click += (s, e) =>
                {
                    string text = MessageDialog.Ask(this, "Message " + c.Name, "Write a message to " + c.Name + ". They will see it in their Messages inbox.", "Send message");
                    if (text == null) return;
                    try { AppServices.Engagement.SendMessage(id, text); Info("\u2713 Message sent to " + c.Name + "."); }
                    catch (Exception ex) { ShowError(ex, "sending your message"); }
                };
                header.Follow.Click += (s, e) =>
                {
                    try
                    {
                        following = AppServices.Engagement.ToggleFollow(id);
                        header.Follow.Text = following ? "Following" : "Follow";
                        header.Follow.Style = following ? BtnStyle.Outline : BtnStyle.Primary;
                        Info(following ? "\u2713 You are following " + c.Name + "." : "You unfollowed " + c.Name + ".");
                    }
                    catch (Exception ex) { ShowError(ex, "updating follow"); }
                };
                Page.Add(header, 0);

                var tabs = new TabStrip("Products", "About", "Reviews");
                Page.Add(tabs, 18);

                var body = new VStack();
                Page.Add(new InsetHost(body, 28), 0);

                var tiles = new System.Collections.Generic.List<Control>();
                if (c.EstablishedYear.HasValue) tiles.Add(new StatTile(c.EstablishedYear.Value.ToString(), "Established"));
                if (c.MemberFarmers.HasValue) tiles.Add(new StatTile(c.MemberFarmers.Value.ToString("#,##0"), "Member-farmers"));
                if (c.HectaresFarmed.HasValue) tiles.Add(new StatTile(c.HectaresFarmed.Value.ToString("#,##0"), "Hectares farmed"));
                tiles.Add(new StatTile(c.ProductCount.ToString(), "Products listed"));
                var tileGrid = new GridPanel { MinItemWidth = 200, ItemHeight = 70, Gap = 16 };
                body.Add(tileGrid, 20);
                tileGrid.SetItems(tiles);

                var about = new VStack();
                about.Add(Ui.Text(string.IsNullOrWhiteSpace(c.Description) ? "This cooperative hasn't added a description yet." : c.Description,
                    10f, FontStyle.Regular, Theme.Muted), 8);
                string contact = string.Join("  \u00B7  ", new[] { c.ContactEmail, c.ContactPhone }.Where(x => !string.IsNullOrWhiteSpace(x)));
                if (contact.Length > 0) about.Add(Ui.Text(contact, 9.5f, FontStyle.Bold, Theme.Forest), 0);
                body.Add(about, 24);

                var produceTitle = Ui.Section("Produce from this cooperative");
                body.Add(produceTitle, 12);
                if (products.Count == 0) body.Add(Ui.Muted("No produce is available right now."), 24);
                else
                {
                    var grid = new GridPanel { MinItemWidth = 200, ItemHeight = 166, Gap = 16 };
                    body.Add(grid, 28);
                    grid.SetItems(products.Select(p => { var card = NewProductCard(p); card.Compact = true; return (Control)card; }));
                }

                var reviewsTitle = Ui.Section("What consumers are saying");
                body.Add(reviewsTitle, 12);
                var rev = new RoundedPanel { Height = 92, Radius = 12 };
                double rating = c.AvgRating;
                rev.PostPaint += (s, e) =>
                {
                    var g = e.Graphics; GraphicsUtil.HighQuality(g);
                    TextRenderer.DrawText(g, c.ReviewCount > 0 ? rating.ToString("0.0") : "\u2013", Theme.Heading(26f), new Rectangle(22, 14, 90, 52), Theme.Deep, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                    for (int i = 0; i < 5; i++) IconPainter.DrawStar(g, new Rectangle(118 + i * 18, 24, 15, 15), i < (int)Math.Round(rating) && c.ReviewCount > 0);
                    TextRenderer.DrawText(g, c.ReviewCount > 0 ? "Based on " + c.ReviewCount + (c.ReviewCount == 1 ? " review of its produce" : " reviews of its produce") : "No reviews yet. Buyers can review produce after delivery.", Theme.Body(9f), new Rectangle(118, 46, 520, 20), Theme.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                };
                body.Add(rev, 0);

                tabs.TabChanged += i => ScrollToControl(i == 0 ? (Control)tileGrid : (i == 1 ? (Control)about : (Control)reviewsTitle));
            }
            catch (Exception ex)
            {
                ShowError(ex, "loading the cooperative");
                Defer(() => Nav.NavigateRoot(ViewInfo.HomeFor(CurrentUser.Role)));
            }
        }

        private void ScrollToControl(Control target)
        {
            int y = 0; for (Control c = target; c != null && c != this; c = c.Parent) y += c.Top;
            AutoScrollPosition = new Point(0, Math.Max(0, y - 60));
        }
    }
}
