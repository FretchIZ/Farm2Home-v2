using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Account details for the signed-in user.</summary>
    internal sealed class ProfileView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            var u = CurrentUser;
            Page.Clear();
            Page.Add(Ui.Title("Profile"), 20);
            var card = new Card();
            card.Body.Add(new PairRow("Name", u.FullName), 0);
            card.Body.Add(new PairRow("Email", u.Email), 0);
            card.Body.Add(new PairRow("Account type", u.Role.ToString()), 0);
            card.Body.Add(new PairRow("Contact number", string.IsNullOrWhiteSpace(u.ContactNumber) ? "\u2014" : u.ContactNumber), 0);
            card.Body.Add(new PairRow("Signed in since", u.LoginTime.ToString("MMM d, h:mm tt")), 12);
            card.Body.Add(Ui.Muted("To change your account details or password, please contact your Farm2Home administrator."), 0);
            Page.Add(card, 0);
        }
    }
}
