using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Cooperative's own listings: add, edit, update stock, remove.</summary>
    internal sealed class CoopProductsView : BaseView
    {
        private readonly DataGridView _grid = Tables.Create();
        private readonly RoundedPanel _card;
        private readonly AutoLabel _count = Ui.Sub("");
        private readonly AutoLabel _empty = Ui.Text("You have no listings yet. Click \u201CAdd listing\u201D to create your first one.", 11f, FontStyle.Regular, Theme.Muted);
        private string _search;

        public CoopProductsView()
        {
            Page.Add(Ui.Title("My products"), 4);
            Page.Add(_count, 16);

            var add = Ui.Button("+  Add listing", BtnStyle.Accent, 170, 46);
            var edit = Ui.Button("Edit", BtnStyle.Outline, 110, 46);
            var stock = Ui.Button("Update stock", BtnStyle.Outline, 150, 46);
            var remove = Ui.Button("Remove listing", BtnStyle.Ghost, 160, 46);
            add.Click += (s, e) => Nav.NavigateTo(ViewId.ProductEditor, null);
            edit.Click += (s, e) => Edit();
            stock.Click += (s, e) => UpdateStock();
            remove.Click += (s, e) => Remove();
            Page.Add(Ui.Buttons(add, edit, stock, remove), 16);

            Tables.AddColumn(_grid, "Product", 30);
            Tables.AddColumn(_grid, "Category", 18);
            Tables.AddColumn(_grid, "Price", 14);
            Tables.AddColumn(_grid, "Stock", 16);
            Tables.AddColumn(_grid, "Status", 16);
            _grid.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex != 4) return;
                var p = _grid.Rows[e.RowIndex].Tag as Product;
                if (p == null) return;
                e.CellStyle.ForeColor = StatusColor(p);
                e.CellStyle.Font = Theme.Body(10f, FontStyle.Bold);
            };
            _grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) Edit(); };
            _card = Tables.Wrap(_grid);
            Page.Add(_card, 12);
            Page.Add(_empty, 0);
            _empty.Visible = false;
        }

        private static string StatusText(Product p)
        {
            if (!p.IsAvailable) return "Draft";
            if (p.StockQuantity == 0) return "Out of stock";
            return p.StockQuantity <= 10 ? "Low stock" : "Available";
        }

        private static Color StatusColor(Product p)
        {
            if (!p.IsAvailable) return Theme.Muted;
            if (p.StockQuantity == 0) return Theme.Danger;
            return p.StockQuantity <= 10 ? Theme.MarigoldText : Theme.Forest;
        }

        public override void OnNavigatedTo(object arg)
        {
            _search = arg as string;
            Reload();
        }

        private Product Selected()
        {
            var p = _grid.CurrentRow == null ? null : _grid.CurrentRow.Tag as Product;
            if (p == null) Info("Select a listing first.", true);
            return p;
        }

        private void Reload()
        {
            if (IsDisposed) return;
            try
            {
                var list = AppServices.ProductManagement.GetListings();
                if (!string.IsNullOrWhiteSpace(_search))
                    list = list.Where(p => p.ProductName.IndexOf(_search, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
                _grid.Rows.Clear();
                foreach (var p in list)
                {
                    int i = _grid.Rows.Add(p.ProductName, p.CategoryName, Ui.Money(p.Price) + "/" + p.Unit, p.StockQuantity + " " + p.Unit, StatusText(p));
                    _grid.Rows[i].Tag = p;
                }
                Tables.Fit(_card, _grid, 12);
                _card.Visible = list.Count > 0;
                _empty.Visible = list.Count == 0;
                _count.Text = list.Count + " " + Ui.Plural(list.Count, "listing", "listings") +
                              (string.IsNullOrWhiteSpace(_search) ? "" : " matching \u201C" + _search + "\u201D");
            }
            catch (Exception ex) { ShowError(ex, "loading your listings"); }
        }

        private void Edit()
        {
            var p = Selected();
            if (p != null) Nav.NavigateTo(ViewId.ProductEditor, p.ProductId);
        }

        private void UpdateStock()
        {
            var p = Selected();
            if (p == null) return;
            string text = Prompt.Ask(this, "Update stock", "New stock quantity for " + p.ProductName + " (" + p.Unit + "):", p.StockQuantity.ToString());
            if (text == null) return;
            int qty;
            if (!int.TryParse(text.Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out qty) || qty < 0)
            { Info("Please enter a whole number of 0 or more.", true); return; }
            try { AppServices.ProductManagement.UpdateStock(p.ProductId, qty); Info("\u2713 Stock updated."); Reload(); }
            catch (Exception ex) { ShowError(ex, "updating stock"); }
        }

        private void Remove()
        {
            var p = Selected();
            if (p == null) return;
            if (!UiErrors.Confirm(this, "Remove \u201C" + p.ProductName + "\u201D from the marketplace?\nPast orders keep their details.")) return;
            try { AppServices.ProductManagement.Delete(p.ProductId); Info("Listing removed."); Reload(); }
            catch (Exception ex) { ShowError(ex, "removing the listing"); }
        }
    }
}
