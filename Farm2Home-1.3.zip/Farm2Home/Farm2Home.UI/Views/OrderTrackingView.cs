using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 07: order confirmation and tracking timeline.</summary>
    internal sealed class OrderTrackingView : BaseView
    {
        private OrderViewArg _arg = new OrderViewArg();

        public override void OnNavigatedTo(object arg)
        {
            var a = arg as OrderViewArg;
            if (a == null) { a = new OrderViewArg(); a.OrderIds.Add(Convert.ToInt32(arg)); }
            _arg = a;
            Render();
        }

        private void Render()
        {
            if (IsDisposed) return;
            try
            {
                var orders = _arg.OrderIds.Select(id => AppServices.Orders.GetMyOrder(id)).ToList();
                Page.Clear();

                var head = new VStack();
                if (_arg.JustPlaced)
                {
                    head.Add(new CheckCircle(), 10);
                    head.Add(new AutoLabel { Text = "Order placed successfully!", Font = Theme.Heading(19f), ForeColor = Theme.Ink, TextAlign = ContentAlignment.TopCenter }, 6);
                    string msg = orders.Count == 1
                        ? "Order " + orders[0].OrderNumber + " has been sent to " + orders[0].CooperativeName + ". You'll see an update here as it's prepared and delivered."
                        : "Your cart was split into " + orders.Count + " orders, one per cooperative: " + string.Join(", ", orders.Select(o => o.OrderNumber)) + ".";
                    var msgLabel = Ui.Text(msg, 10f, FontStyle.Regular, Theme.Muted); msgLabel.TextAlign = ContentAlignment.TopCenter;
                    head.Add(msgLabel, 4);
                    var payLabel = Ui.Text("Cash on delivery: nothing has been charged. Payment status stays Unpaid until delivery.", 9.5f, FontStyle.Bold, Theme.Ink);
                    payLabel.TextAlign = ContentAlignment.TopCenter;
                    head.Add(payLabel, 22);
                }
                else head.Add(Ui.Title("Order tracking"), 18);
                Page.Add(new CenterColumn(head, 780), 0);

                foreach (var o in orders) Page.Add(new CenterColumn(BuildOrder(o), 780), 18);

                var cont = Ui.Button("Continue shopping", BtnStyle.Outline, 140, 40);
                cont.Click += (s, e) => Nav.NavigateRoot(ViewId.Browse);
                var mine = Ui.Button("My orders", BtnStyle.Primary, 120, 40);
                mine.Click += (s, e) => Nav.NavigateRoot(ViewId.Orders);
                var btns = Ui.Buttons(mine, cont);
                var holder = new Panel { Height = 40 };
                holder.Controls.Add(btns);
                holder.Resize += (s, e) => { btns.Width = mine.Width + cont.Width + 12; btns.Location = new Point((holder.Width - btns.Width) / 2, 0); };
                Page.Add(holder, 0);
            }
            catch (Exception ex)
            {
                ShowError(ex, "loading your order");
                Defer(() => Nav.NavigateRoot(ViewId.Orders));
            }
        }

        private VStack BuildOrder(Order o)
        {
            var col = new VStack();
            var top = new Card { Inset = 20, Radius = 12 };
            top.Body.Add(Ui.Text("Order " + o.OrderNumber, 11f, FontStyle.Bold, Theme.Ink, Theme.Surface), 6);
            var badge = new StatusBadge();
            badge.SetOrderStatus(o.OrderStatus);
            top.Body.AddFixed(badge, 12);
            if (o.OrderStatus == OrderStatus.Cancelled)
                top.Body.Add(Ui.Text("This order was cancelled.", 10.5f, FontStyle.Bold, Theme.Danger, Theme.Surface), 0);
            else
            {
                DateTime? updated = null;
                if (o.Delivery != null) updated = DateTime.SpecifyKind(o.Delivery.UpdatedAt, DateTimeKind.Utc).ToLocalTime();
                top.Body.Add(new OrderTimeline { Status = o.OrderStatus, PlacedAt = o.OrderDate, UpdatedAt = updated }, 0);
            }
            col.Add(top, 14);

            var details = new Card { Inset = 18, Radius = 12 };
            details.Body.Add(Ui.Text("Delivery details", 10.5f, FontStyle.Bold, Theme.Ink, Theme.Surface), 8);
            details.Body.Add(new PairRow("Address", o.DeliveryAddress), 0);
            if (o.Delivery != null && !string.IsNullOrWhiteSpace(o.Delivery.Notes)) details.Body.Add(new PairRow("Time slot", o.Delivery.Notes), 0);
            details.Body.Add(new PairRow("Payment", Ui.PaymentText(o.PaymentMethod)), 0);
            details.Body.Add(new PairRow("Payment status", o.PaymentStatus) { RightColor = o.PaymentStatus == "Paid" ? Theme.Forest : Theme.MarigoldText }, 0);
            details.Body.Add(new PairRow("Cooperative", o.CooperativeName), 0);
            details.Body.Add(new PairRow("Contact", o.ContactNumber), 0);

            var items = new Card { Inset = 18, Radius = 12 };
            items.Body.Add(Ui.Text("Items (" + o.Items.Sum(i => i.Quantity) + ")", 10.5f, FontStyle.Bold, Theme.Ink, Theme.Surface), 8);
            foreach (var i in o.Items)
                items.Body.Add(new PairRow(i.ProductName + " \u00D7" + i.Quantity, Ui.Money(i.Subtotal)), 0);
            items.Body.Add(new PairRow("Delivery fee", Ui.Money(o.DeliveryFee)), o.Discount > 0 ? 0 : 4);
            if (o.Discount > 0) items.Body.Add(new PairRow("Promo " + o.PromoCode, "\u2212" + Ui.Money(o.Discount)) { RightColor = Theme.Forest }, 4);
            items.Body.Add(new Divider(), 6);
            string totalLabel = o.OrderStatus == OrderStatus.Cancelled ? "Total (cancelled)" : (o.PaymentStatus == "Paid" ? "Total paid" : "Total to pay");
            items.Body.Add(new PairRow(totalLabel, Ui.Money(o.Total), true), 0);
            col.Add(new EqualRow(details, items) { Gap = 14 }, 14);

            var refresh = Ui.Button("Refresh status", BtnStyle.Outline, 130, 36);
            refresh.Click += (s, e) => Defer(Render);
            var row = Ui.Buttons(refresh);
            if (o.OrderStatus == OrderStatus.Pending || o.OrderStatus == OrderStatus.Confirmed)
            {
                var cancel = Ui.Button("Cancel order", BtnStyle.Ghost, 120, 36);
                cancel.Click += (s, e) =>
                {
                    if (!UiErrors.Confirm(this, "Cancel order " + o.OrderNumber + "? The items will be returned to stock.")) return;
                    Defer(() =>
                    {
                        try { AppServices.Orders.CancelMyOrder(o.OrderId); Info("Order " + o.OrderNumber + " cancelled."); }
                        catch (Exception ex) { ShowError(ex, "cancelling the order"); }
                        Render();
                    });
                };
                row.Controls.Add(cancel);
            }
            col.Add(row, 0);
            return col;
        }
    }
}
