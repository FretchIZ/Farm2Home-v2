using System;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Consumer's order history. Orders are read from the database, so they survive restarts.</summary>
    internal sealed class OrdersView : BaseView
    {
        private readonly DataGridView _grid = Tables.Create();
        private readonly RoundedPanel _card;
        private readonly AutoLabel _count = Ui.Sub("");
        private readonly AutoLabel _empty = Ui.Text("You haven't placed any orders yet.", 11f, System.Drawing.FontStyle.Regular, Theme.Muted);

        public OrdersView()
        {
            Page.Add(Ui.Title("My orders"), 4);
            Page.Add(_count, 20);
            Tables.AddColumn(_grid, "Order", 18);
            Tables.AddColumn(_grid, "Date", 22);
            Tables.AddColumn(_grid, "Cooperative", 24);
            Tables.AddColumn(_grid, "Items", 10);
            Tables.AddColumn(_grid, "Total", 12);
            Tables.AddColumn(_grid, "Payment", 12);
            Tables.AddColumn(_grid, "Status", 16);
            Tables.UsePills(_grid, 6);
            _grid.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex != 6) return;
                var o = _grid.Rows[e.RowIndex].Tag as Order;
                if (o == null) return;
                e.CellStyle.ForeColor = Tables.StatusColor(o.OrderStatus);
                e.CellStyle.Font = Theme.Body(10f, System.Drawing.FontStyle.Bold);
            };
            _grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) Open(); };
            _card = Tables.Wrap(_grid);
            Page.Add(_card, 16);

            var view = Ui.Button("View order", BtnStyle.Primary, 160, 44);
            view.Click += (s, e) => Open();
            Page.Add(Ui.Buttons(view), 12);
            Page.Add(_empty, 0);
            _empty.Visible = false;
        }

        public override void OnNavigatedTo(object arg)
        {
            try
            {
                var orders = AppServices.Orders.GetMyOrders();
                _grid.Rows.Clear();
                foreach (var o in orders)
                {
                    int idx = _grid.Rows.Add(o.OrderNumber, o.OrderDate.ToString("MMM d, yyyy h:mm tt"), o.CooperativeName,
                        o.Items.Sum(i => i.Quantity), Ui.Money(o.Total), o.PaymentStatus, Components.OrderStatusText.Of(o.OrderStatus));
                    _grid.Rows[idx].Tag = o;
                }
                Tables.Fit(_card, _grid, 12);
                _count.Text = orders.Count + " " + Ui.Plural(orders.Count, "order", "orders");
                _card.Visible = orders.Count > 0;
                _empty.Visible = orders.Count == 0;
            }
            catch (Exception ex) { ShowError(ex, "loading your orders"); }
        }

        private void Open()
        {
            var o = _grid.CurrentRow == null ? null : _grid.CurrentRow.Tag as Order;
            if (o == null) { Info("Select an order first.", true); return; }
            var arg = new OrderViewArg();
            arg.OrderIds.Add(o.OrderId);
            Nav.NavigateTo(ViewId.OrderTracking, arg);
        }
    }
}
