using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Application;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Validators;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 10: one form for adding and editing a produce listing. "Draft" = hidden from the marketplace, "Publish" = visible.</summary>
    internal sealed class ProductEditorView : BaseView
    {
        private int _productId;
        private string _imageFile;
        private string _harvestRaw;                       // free-text harvest note from older data
        private string _coopName = "";

        private readonly InputBox _name = new InputBox { MaxLength = 120 };
        private readonly InputBox _price = new InputBox { Placeholder = "0.00" };
        private readonly InputBox _stock = new InputBox { Placeholder = "0" };
        private readonly InputBox _desc = new InputBox(true) { MaxLength = 1000 };
        private readonly InputBox _coopBox = new InputBox { ReadOnly = true };
        private readonly DateBox _harvestDate = new DateBox();
        private readonly SelectBox _category = new SelectBox(), _unit = new SelectBox();
        private readonly SegmentedToggle _status = new SegmentedToggle("Draft", "Publish") { Height = 44 };
        private readonly ImageBox _image = new ImageBox { Height = 210, Cursor = Cursors.Hand, AllowDrop = true, HintText = "Drag photos here, or click to browse" + Environment.NewLine + "JPG or PNG, up to 5 MB" };
        private readonly ProductCard _preview;
        private readonly Product _previewProduct = new Product { ProductName = "Product name", Unit = "kg", StockQuantity = 1, IsAvailable = true };
        private readonly AutoLabel _title = Ui.Title("Add a new produce listing");
        private readonly Crumbs _crumb = new Crumbs();
        private readonly AutoLabel _errors = Ui.Text("", 10f, FontStyle.Bold, Theme.Danger, Theme.Surface);
        private readonly FlatButton _publish = Ui.Button("Publish listing", BtnStyle.Accent);
        private readonly FlatButton _draft = Ui.Button("Save as draft", BtnStyle.Outline);
        private readonly FlatButton _delete = Ui.Button("Delete listing", BtnStyle.Ghost);

        public ProductEditorView()
        {
            _preview = new ProductCard(_previewProduct, false);

            _crumb.SetParts("My products", "Add new listing");
            _crumb.PartClicked += i => Nav.NavigateRoot(ViewId.CoopProducts);
            Page.Add(_crumb, 6);
            Page.Add(_title, 4);
            Page.Add(Ui.Sub("Fill in the details below so consumers can find and order this product."), 20);

            // ---- left column ----
            var photo = new Card();
            photo.Body.Add(Ui.Section("Photos"), 12);
            photo.Body.Add(_image, 12);
            var remove = Ui.Button("Remove photo", BtnStyle.Ghost, 160, 42);
            remove.Click += (s, e) => { _imageFile = null; _image.ImageFile = null; UpdatePreview(); };
            photo.Body.Add(Ui.Buttons(remove), 0);
            _image.Click += (s, e) => ChoosePhoto();
            _image.DragEnter += (s, e) => e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            _image.DragDrop += (s, e) =>
            {
                var files = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files != null && files.Length > 0) ImportPhoto(files[0]);
            };

            var details = new Card();
            details.Body.Add(Ui.Section("Product details"), 16);
            details.Body.Add(Ui.Field("Product name", _name), 14);
            details.Body.Add(new EqualRow(Ui.Field("Category", _category), Ui.Field("Harvest date (optional)", _harvestDate)), 14);
            details.Body.Add(new EqualRow(Ui.Field("Unit", _unit), Ui.Field("Price (\u20B1 per unit)", _price)), 14);
            details.Body.Add(new EqualRow(Ui.Field("Stock quantity", _stock), Ui.Field("Cooperative", _coopBox)), 14);
            details.Body.Add(Ui.Field("Description", _desc), 0);

            var left = new VStack();
            left.Add(photo, 16);
            left.Add(details, 0);

            // ---- right column ----
            var right = new VStack();
            right.Add(Ui.Text("Live preview", 10.5f, FontStyle.Bold, Theme.Muted), 8);
            right.Add(_preview, 16);
            var status = new Card { Inset = 22 };
            status.Body.Add(Ui.Section("Listing status"), 12);
            status.Body.Add(_status, 6);
            status.Body.Add(Ui.Muted("Draft listings are hidden from consumers."), 14);
            _errors.Visible = false;
            status.Body.Add(_errors, 10);
            _publish.Click += (s, e) => Save(true);
            _draft.Click += (s, e) => Save(false);
            var cancel = Ui.Button("Cancel", BtnStyle.Ghost);
            cancel.Click += (s, e) => LeaveEditor();
            _delete.Click += (s, e) => Delete();
            _delete.Visible = false;
            status.Body.Add(_publish, 8);
            status.Body.Add(_draft, 8);
            status.Body.Add(cancel, 0);
            status.Body.Add(_delete, 0);
            right.Add(status, 0);

            Page.Add(new TwoColumn(left, right, 360, true), 0);

            foreach (var box in new[] { _name, _price, _stock }) box.Inner.TextChanged += (s, e) => UpdatePreview();
            _unit.SelectionChanged += UpdatePreview;
            _status.SelectedIndex = 1;
        }

        public override void OnNavigatedTo(object arg)
        {
            try
            {
                var cats = AppServices.Catalog.GetCategories();
                _category.SetOptions(new[] { new SelectOption(null, "Select a category") }
                    .Concat(cats.Select(c => new SelectOption(c.CategoryId, c.CategoryName))));
                _unit.SetOptions(new[] { new SelectOption(null, "Select a unit") }
                    .Concat(ProductValidator.Units.Select(u => new SelectOption(u, u))));
                var coop = AppServices.Catalog.GetCooperative(CurrentUser.CooperativeId.GetValueOrDefault());
                _coopName = coop.Name;
                _coopBox.Text = coop.Name;
                _previewProduct.CooperativeName = coop.Name;

                if (arg != null)
                {
                    var p = AppServices.ProductManagement.GetForEdit(Convert.ToInt32(arg));
                    _productId = p.ProductId;
                    _name.Text = p.ProductName;
                    _category.Select(p.CategoryId);
                    _unit.Select(p.Unit);
                    _price.Text = p.Price.ToString("0.00", CultureInfo.CurrentCulture);
                    _stock.Text = p.StockQuantity.ToString();
                    _desc.Text = p.Description;
                    _status.SelectedIndex = p.IsAvailable ? 1 : 0;
                    _imageFile = p.ImagePath;
                    _image.ImageFile = p.ImagePath;
                    LoadHarvest(p.HarvestInfo);
                    _title.Text = "Edit produce listing";
                    _crumb.SetParts("My products", "Edit listing");
                    _publish.Text = "Publish changes";
                    _delete.Visible = true;
                }
                UpdatePreview();
            }
            catch (Exception ex)
            {
                ShowError(ex, "loading the listing");
                Defer(() => Nav.NavigateRoot(ViewId.CoopProducts));
            }
        }

        private void LoadHarvest(string info)
        {
            _harvestRaw = null;
            _harvestDate.Value = null;
            if (string.IsNullOrWhiteSpace(info)) return;
            string t = info.Trim();
            if (t.StartsWith("Harvested ", StringComparison.OrdinalIgnoreCase)) t = t.Substring(10);
            DateTime d;
            if (DateTime.TryParseExact(t, "MMM d, yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) _harvestDate.Value = d;
            else _harvestRaw = info;
        }

        private string HarvestText()
        {
            var d = _harvestDate.Value;
            return d.HasValue ? "Harvested " + d.Value.ToString("MMM d, yyyy", CultureInfo.InvariantCulture) : _harvestRaw;
        }

        private void UpdatePreview()
        {
            decimal price; int stock;
            _previewProduct.ProductName = string.IsNullOrWhiteSpace(_name.Text) ? "Product name" : _name.Text.Trim();
            _previewProduct.Price = decimal.TryParse(_price.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out price) ? price : 0m;
            _previewProduct.StockQuantity = int.TryParse(_stock.Text.Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out stock) ? Math.Max(0, stock) : 0;
            _previewProduct.Unit = (_unit.SelectedValue as string) ?? "kg";
            _previewProduct.IsAvailable = true;
            _previewProduct.ImagePath = _imageFile;
            _previewProduct.CooperativeName = _coopName;
            _preview.SetProduct(_previewProduct);
        }

        private void ShowErrors(IEnumerable<string> errors)
        {
            _errors.Text = string.Join(Environment.NewLine, errors);
            _errors.Visible = true;
        }

        private void ChoosePhoto()
        {
            using (var dlg = new OpenFileDialog { Filter = "Images (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png", Title = "Choose a photo" })
                if (dlg.ShowDialog(this) == DialogResult.OK) ImportPhoto(dlg.FileName);
        }

        private void ImportPhoto(string path)
        {
            try
            {
                _imageFile = ImageStore.Import(path);       // checks type, size and that it is a real image
                _image.ImageFile = _imageFile;
                _errors.Visible = false;
                UpdatePreview();
            }
            catch (BusinessException ex) { ShowErrors(new[] { ex.Message }); }
            catch (Exception ex) { ShowError(ex, "adding the photo"); }
        }

        private void Save(bool publish)
        {
            _status.SelectedIndex = publish ? 1 : 0;
            var errs = new List<string>();
            decimal price; int stock;
            if (!decimal.TryParse(_price.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out price)) { errs.Add("Price must be a number."); price = 0; }
            if (!int.TryParse(_stock.Text.Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out stock)) { errs.Add("Stock must be a whole number."); stock = 0; }
            if (errs.Count > 0) { ShowErrors(errs); return; }

            var cv = _category.SelectedValue;
            var input = new ProductInput
            {
                ProductId = _productId,
                ProductName = _name.Text,
                CategoryId = cv == null ? 0 : (int)cv,
                Unit = _unit.SelectedValue as string,
                Price = price,
                StockQuantity = stock,
                Description = _desc.Text,
                HarvestInfo = HarvestText(),
                IsAvailable = publish,
                ImagePath = _imageFile
            };

            _publish.Enabled = false; _draft.Enabled = false;
            try
            {
                AppServices.ProductManagement.Save(input);
                Info(publish ? "\u2713 Listing published." : "\u2713 Saved as draft.");
                Defer(() => Nav.NavigateRoot(ViewId.CoopProducts));
            }
            catch (BusinessException ex)
            {
                ShowErrors(ex.Message.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries));
                _publish.Enabled = true; _draft.Enabled = true;
            }
            catch (Exception ex)
            {
                ShowError(ex, "saving the listing");
                if (!IsDisposed) { _publish.Enabled = true; _draft.Enabled = true; }
            }
        }

        private void Delete()
        {
            if (!UiErrors.Confirm(this, "Delete this listing? It will be removed from the marketplace. Past orders keep their details.")) return;
            try
            {
                AppServices.ProductManagement.Delete(_productId);
                Info("Listing deleted.");
                Defer(() => Nav.NavigateRoot(ViewId.CoopProducts));
            }
            catch (Exception ex) { ShowError(ex, "deleting the listing"); }
        }

        private void LeaveEditor()
        {
            if (Nav.CanGoBack) Nav.GoBack(); else Nav.NavigateRoot(ViewId.CoopProducts);
        }
    }
}
