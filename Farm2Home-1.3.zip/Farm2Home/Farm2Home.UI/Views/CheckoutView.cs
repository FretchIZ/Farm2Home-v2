using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Farm2Home.Application;
using Farm2Home.Application.DTOs;
using Farm2Home.Application.Services;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 06: delivery details, payment (cash on delivery) and order summary.</summary>
    internal sealed class CheckoutView : BaseView
    {
        private InputBox _name, _phone, _street, _barangay, _city, _province, _zip;
        private AutoLabel _error;
        private FlatButton _place;
        private ChipGroup _slots;

        public override void OnNavigatedTo(object arg)
        {
            try
            {
                var cart = AppServices.Cart.GetCart();
                if (cart.Items.Count == 0)
                {
                    Defer(() => { Info("Your cart is empty.", true); Nav.NavigateRoot(ViewId.Cart); });
                    return;
                }
                Build(cart);
            }
            catch (Exception ex) { ShowError(ex, "loading checkout"); }
        }

        private void Build(CartSummary cart)
        {
            Page.Clear();
            Page.Add(Ui.Title("Checkout"), 4);
            Page.Add(new StepCrumbs(1, "Cart", "Delivery & payment", "Confirmation"), 18);

            _name = new InputBox { MaxLength = 150, Text = CurrentUser.FullName ?? "" };
            _phone = new InputBox { MaxLength = 20, Placeholder = "e.g. 0917 234 5678", Text = CurrentUser.ContactNumber ?? "" };
            // Pre-fill from the address saved on the account: "street, barangay, city, province"
            var saved = (CurrentUser.DefaultAddress ?? "").Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToArray();
            Func<int, string> part = i => saved.Length > i ? saved[i] : "";
            bool split = saved.Length >= 3;
            _street = new InputBox { MaxLength = 120, Placeholder = "House no., street", Text = split ? part(0) : (CurrentUser.DefaultAddress ?? "") };
            _barangay = new InputBox { MaxLength = 60, Text = split ? part(1) : "" };
            _city = new InputBox { MaxLength = 60, Text = split ? part(2) : "" };
            _province = new InputBox { MaxLength = 60, Text = split ? part(3) : "" };
            _zip = new InputBox { MaxLength = 4, Placeholder = "4 digits" };

            var left = new VStack();
            var addr = new Card { Inset = 18, Radius = 12 };
            addr.Body.Add(new HeaderRow(Icons.Pin, "Delivery address"), 12);
            addr.Body.Add(new EqualRow(Ui.Field("Full name", _name), Ui.Field("Phone number", _phone)) { Gap = 14 }, 12);
            addr.Body.Add(Ui.Field("Street address", _street), 12);
            addr.Body.Add(new EqualRow(Ui.Field("Barangay", _barangay), Ui.Field("City / municipality", _city)) { Gap = 14 }, 12);
            addr.Body.Add(new EqualRow(Ui.Field("Province", _province), Ui.Field("ZIP code", _zip)) { Gap = 14 }, 0);
            left.Add(addr, 14);

            _slots = new ChipGroup { Gap = 10 };
            var slotNames = DeliverySlots();
            _slots.SetOptions(slotNames, Math.Max(0, slotNames.IndexOf("Tomorrow, 8\u201310 AM")));
            var sched = new Card { Inset = 18, Radius = 12 };
            sched.Body.Add(new HeaderRow(Icons.Clock, "Delivery schedule"), 12);
            sched.Body.Add(_slots, 0);
            left.Add(sched, 14);

            var pay = new Card { Inset = 18, Radius = 12 };
            pay.Body.Add(new HeaderRow(Icons.Card, "Payment method"), 12);
            pay.Body.Add(new PaymentOption("Cash on delivery", "Pay in cash when your order arrives. Stays \u201CUnpaid\u201D until delivered."), 0);
            left.Add(pay, 0);

            int coops = cart.Items.Select(i => i.Product.CooperativeId).Distinct().Count();
            decimal delivery = coops * OrderService.DeliveryFeePerOrder;
            var promo = AppServices.Engagement.AppliedPromo;
            decimal discount = promo == null ? 0m : cart.Items.GroupBy(i => i.Product.CooperativeId).Sum(g => OrderService.DiscountFor(g.Sum(i => i.Subtotal), promo.Percent));

            var sum = new Card { Inset = 18, Radius = 12 };
            sum.Body.Add(Ui.Text("Order summary", 11f, FontStyle.Bold, Theme.Ink, Theme.Surface), 12);
            foreach (var i in cart.Items)
                sum.Body.Add(new PairRow(i.Product.ProductName + " \u00D7" + i.Quantity, Ui.Money(i.Subtotal)), 0);
            sum.Body.Add(new Divider(), 10);
            sum.Body.Add(new PairRow("Subtotal", Ui.Money(cart.Subtotal)), 0);
            sum.Body.Add(new PairRow("Delivery fee", Ui.Money(delivery)), 0);
            if (discount > 0) sum.Body.Add(new PairRow("Promo " + promo.Code + " (" + promo.Percent + "% off)", "\u2212" + Ui.Money(discount)) { RightColor = Theme.Forest }, 0);
            sum.Body.Add(Ui.Text(coops + " " + Ui.Plural(coops, "cooperative", "cooperatives") + " \u2192 " + coops + " separate " + Ui.Plural(coops, "order", "orders") + ".",
                9f, FontStyle.Regular, Theme.Muted, Theme.Surface), 8);
            sum.Body.Add(new Divider(), 10);
            sum.Body.Add(new PairRow("Total", Ui.Money(cart.Subtotal - discount + delivery), true), 14);

            _error = Ui.Text("", 9.5f, FontStyle.Bold, Theme.Danger, Theme.Surface);
            _error.Visible = false;
            sum.Body.Add(_error, 10);

            _place = Ui.Button("Place order", BtnStyle.Accent, 100, 42);
            _place.Click += (s, e) => PlaceOrder();
            sum.Body.Add(_place, 8);
            var secure = new Panel { Height = 20 };
            secure.Paint += (s, e) =>
            {
                GraphicsUtil.HighQuality(e.Graphics);
                const string t = "Cash on delivery \u00B7 pay when it arrives";
                int tw = TextRenderer.MeasureText(t, Theme.Body(9f)).Width, x0 = Math.Max(0, (secure.Width - tw - 18) / 2);
                IconPainter.Draw(e.Graphics, Icons.Lock, new Rectangle(x0, 3, 13, 13), Theme.Muted, 1.2f);
                TextRenderer.DrawText(e.Graphics, t, Theme.Body(9f), new Rectangle(x0 + 18, 0, tw + 4, 20), Theme.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
            sum.Body.Add(secure, 8);
            var back = Ui.Button("Back to cart", BtnStyle.Ghost, 100, 32);
            back.Click += (s, e) => { if (Nav.CanGoBack) Nav.GoBack(); else Nav.NavigateRoot(ViewId.Cart); };
            var cancel = Ui.Button("Cancel", BtnStyle.Ghost, 100, 32);
            cancel.Click += (s, e) => { if (UiErrors.Confirm(this, "Cancel checkout? Your cart will be kept.")) Nav.NavigateRoot(ViewId.Home); };
            sum.Body.Add(back, 0);
            sum.Body.Add(cancel, 0);

            Page.Add(new TwoColumn(left, sum, 300, true) { Gap = 22, StackBelow = 760 }, 0);
        }

        private static List<string> DeliverySlots()
        {
            var now = DateTime.Now;
            var slots = new List<string>();
            if (now.Hour < 15) slots.Add("Today, 4\u20136 PM");
            slots.Add("Tomorrow, 8\u201310 AM");
            slots.Add("Tomorrow, 2\u20134 PM");
            slots.Add(now.Date.AddDays(2).ToString("ddd") + ", 8\u201310 AM");
            return slots;
        }

        private void ShowErrors(IEnumerable<string> errors)
        {
            _error.Text = string.Join(Environment.NewLine, errors);
            _error.Visible = true;
        }

        private void PlaceOrder()
        {
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(_name.Text)) errors.Add("Full name is required.");
            if (string.IsNullOrWhiteSpace(_phone.Text)) errors.Add("Phone number is required.");
            if (string.IsNullOrWhiteSpace(_street.Text)) errors.Add("Street address is required.");
            if (string.IsNullOrWhiteSpace(_barangay.Text)) errors.Add("Barangay is required.");
            if (string.IsNullOrWhiteSpace(_city.Text)) errors.Add("City / municipality is required.");
            if (string.IsNullOrWhiteSpace(_province.Text)) errors.Add("Province is required.");
            string zip = _zip.Text.Trim();
            if (zip.Length > 0 && !Regex.IsMatch(zip, @"^\d{4}$")) errors.Add("ZIP code must be 4 digits.");
            if (errors.Count > 0) { ShowErrors(errors); return; }
            _error.Visible = false;

            string address = string.Join(", ", new[] { _street.Text.Trim(), _barangay.Text.Trim(), _city.Text.Trim(), _province.Text.Trim() })
                             + (zip.Length > 0 ? " " + zip : "");
            var request = new CheckoutRequest
            {
                CustomerName = _name.Text, ContactNumber = _phone.Text, DeliveryAddress = address, PaymentMethod = "CashOnDelivery",
                DeliverySlot = _slots.Selected,
                PromoCode = AppServices.Engagement.AppliedPromo == null ? null : AppServices.Engagement.AppliedPromo.Code
            };

            _place.Enabled = false;
            try
            {
                var orders = AppServices.Orders.PlaceOrders(request);
                AppServices.Engagement.ClearPromo();
                NotifyCartChanged();
                var arg = new OrderViewArg { OrderIds = orders.Select(o => o.OrderId).ToList(), JustPlaced = true };
                Defer(() => Nav.NavigateRoot(ViewId.OrderTracking, arg));
            }
            catch (BusinessException ex)
            {
                ShowErrors(new[] { ex.Message });          // e.g. insufficient stock; nothing was saved
                _place.Enabled = true;
            }
            catch (Exception ex)
            {
                ShowError(ex, "placing your order");
                if (!IsDisposed) _place.Enabled = true;
            }
        }
    }
}
