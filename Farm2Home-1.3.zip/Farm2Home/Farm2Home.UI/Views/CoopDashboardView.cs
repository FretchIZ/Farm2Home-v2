using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Screen 09: cooperative dashboard. Every number and the weekly chart come from the database.</summary>
    internal sealed class CoopDashboardView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            try
            {
                var coop = AppServices.Catalog.GetCooperative(CurrentUser.CooperativeId.GetValueOrDefault());
                var stats = AppServices.ProductManagement.GetStats();
                var listings = AppServices.ProductManagement.GetListings();
                var orders = AppServices.Orders.GetCooperativeOrders();
                var weekly = AppServices.ProductManagement.GetWeeklySales();
                Page.Clear();

                // title row: welcome on the left, "Add produce listing" on the right (stacks when narrow)
                var titles = new VStack();
                titles.Add(Ui.Title("Welcome back, " + coop.Name), 4);
                titles.Add(Ui.Sub("Here's how your cooperative is doing this month."), 0);
                var add = Ui.Button("Add produce listing", BtnStyle.Accent, 190, 40); add.IconName = Icons.Plus;
                add.Click += (s, e) => Nav.NavigateTo(ViewId.ProductEditor, null);
                var addHolder = new VStack();
                addHolder.AddFixed(add, 0);
                Page.Add(new TwoColumn(titles, addHolder, 190, true) { StackBelow = 760 }, 18);

                var cards = new GridPanel { MinItemWidth = 200, ItemHeight = 120, Gap = 16 };
                Page.Add(cards, 18);
                cards.SetItems(new Control[]
                {
                    new SummaryCard { Glyph = Icons.Earnings, Value = Ui.Money(stats.MonthSales), Caption = "Total sales this month" },
                    new SummaryCard { Glyph = Icons.Products, Value = stats.ActiveListings.ToString(), Caption = "Active listings", TagText = "of " + stats.TotalProducts + " total" },
                    new SummaryCard { Glyph = Icons.Orders, Value = stats.PendingOrders.ToString(), Caption = "Pending orders",
                                      TagText = stats.PendingOrders > 0 ? "Needs action" : "", TagColor = Theme.MarigoldText },
                    new SummaryCard { Glyph = Icons.People, Value = stats.CustomersReached.ToString(), Caption = "Consumers reached" }
                });

                // weekly sales chart + low stock alert, side by side
                var chart = new BarChart();
                chart.SetData(weekly);

                var low = listings.Where(p => p.IsAvailable && p.StockQuantity <= 10).OrderBy(p => p.StockQuantity).Take(5).ToList();
                var alert = new Card { Inset = 18, Radius = 12 };
                if (low.Count > 0)
                {
                    alert.Surface = Theme.DangerSoft;
                    alert.BorderColor = Theme.DangerSoft;
                    alert.Body.Add(new HeaderRow(Icons.Alert, "Low stock alert") { }, 4); ((HeaderRow)alert.Body.Controls[alert.Body.Controls.Count - 1]).Danger = true;
                    alert.Body.Add(Ui.Text(low.Count + " " + Ui.Plural(low.Count, "listing is", "listings are") + " running low \u2014 restock soon to avoid missed orders.",
                        9.5f, FontStyle.Regular, Theme.Muted, Theme.DangerSoft), 10);
                    foreach (var p in low)
                        alert.Body.Add(new PairRow(p.ProductName, p.StockQuantity + " " + p.Unit + " left") { RightColor = Theme.Danger }, 0);
                }
                else
                {
                    alert.Body.Add(Ui.Text("Stock levels look good", 12.5f, FontStyle.Bold, Theme.Forest, Theme.Surface), 4);
                    alert.Body.Add(Ui.Muted("None of your listings are running low."), 0);
                }
                Page.Add(new TwoColumn(chart, alert, 280, true) { Gap = 16 }, 22);

                var header = new SectionHeader("Recent orders", "View all");
                header.LinkClicked += () => Nav.NavigateRoot(ViewId.CoopOrders);
                Page.Add(header, 8);

                if (orders.Count == 0) Page.Add(Ui.Muted("No orders yet. They will appear here as consumers check out."), 0);
                else
                {
                    var grid = Tables.Create();
                    Tables.AddColumn(grid, "Order ID", 16);
                    Tables.AddColumn(grid, "Consumer", 20);
                    Tables.AddColumn(grid, "Items", 28);
                    Tables.AddColumn(grid, "Total", 10);
                    Tables.AddColumn(grid, "Status", 16);
                    Tables.AddColumn(grid, "", 8);
                    Tables.UsePills(grid, 4);
                    grid.CellFormatting += (s, e) =>
                    {
                        if (e.RowIndex < 0) return;
                        var o = grid.Rows[e.RowIndex].Tag as Farm2Home.Domain.Entities.Order;
                        if (o == null) return;
                        if (e.ColumnIndex == 5) { e.CellStyle.ForeColor = Theme.Forest; e.CellStyle.Font = Theme.Body(10f, FontStyle.Bold); e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; }
                    };
                    foreach (var o in orders.Take(5))
                    {
                        int idx = grid.Rows.Add(o.OrderNumber, o.CustomerName, Ui.ItemsSummary(o), Ui.Money(o.Total), OrderStatusText.Of(o.OrderStatus), "View");
                        grid.Rows[idx].Tag = o;
                    }
                    grid.Cursor = Cursors.Hand;
                    grid.CellClick += (s, e) =>
                    {
                        if (e.RowIndex < 0) return;
                        var o = grid.Rows[e.RowIndex].Tag as Farm2Home.Domain.Entities.Order;
                        if (o != null) Nav.NavigateRoot(ViewId.CoopOrders, o.OrderId);
                    };
                    var card = Tables.Wrap(grid);
                    Tables.Fit(card, grid, 5);
                    grid.CurrentCell = null; grid.ClearSelection();
                    Page.Add(card, 0);
                }
            }
            catch (Exception ex) { ShowError(ex, "loading your dashboard"); }
        }
    }
}
