using System;
using System.Linq;
using System.Windows.Forms;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Cooperative "Earnings" page: totals, the weekly chart, and the delivered orders that make up the sales.</summary>
    internal sealed class EarningsView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            try
            {
                var stats = AppServices.ProductManagement.GetStats();
                var weekly = AppServices.ProductManagement.GetWeeklySales();
                var orders = AppServices.Orders.GetCooperativeOrders();
                Page.Clear();
                Page.Add(Ui.Title("Earnings"), 4);
                Page.Add(Ui.Sub("What your cooperative has earned. Cash on delivery orders count as paid once they are delivered."), 22);

                var cards = new GridPanel { MinItemWidth = 200, ItemHeight = 150 };
                Page.Add(cards, 22);
                cards.SetItems(new Control[]
                {
                    new SummaryCard { Glyph = Icons.Earnings, Value = Ui.Money(stats.MonthSales), Caption = "Total sales this month" },
                    new SummaryCard { Glyph = Icons.Earnings, Value = Ui.Money(stats.TotalSales), Caption = "Delivered sales, all time" },
                    new SummaryCard { Glyph = Icons.Orders, Value = stats.CompletedOrders.ToString(), Caption = "Completed orders" }
                });

                var chart = new BarChart();
                chart.SetData(weekly);
                Page.Add(chart, 26);

                Page.Add(Ui.Section("Delivered orders"), 10);
                var delivered = orders.Where(o => o.OrderStatus == OrderStatus.Delivered).Take(8).ToList();
                if (delivered.Count == 0) { Page.Add(Ui.Muted("No delivered orders yet."), 0); return; }
                var grid = Tables.Create();
                Tables.AddColumn(grid, "Order ID", 18);
                Tables.AddColumn(grid, "Consumer", 28);
                Tables.AddColumn(grid, "Date", 24);
                Tables.AddColumn(grid, "Payment", 16);
                Tables.AddColumn(grid, "Total", 14);
                foreach (var o in delivered)
                    grid.Rows.Add(o.OrderNumber, o.CustomerName, o.OrderDate.ToString("MMM d, yyyy"), o.PaymentStatus, Ui.Money(o.Total));
                var card = Tables.Wrap(grid);
                Tables.Fit(card, grid, delivered.Count);
                Page.Add(card, 0);
            }
            catch (Exception ex) { ShowError(ex, "loading your earnings"); }
        }
    }
}
