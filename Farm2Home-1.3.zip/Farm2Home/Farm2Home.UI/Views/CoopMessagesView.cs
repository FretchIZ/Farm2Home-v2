using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Views
{
    /// <summary>Messages that consumers sent to this cooperative from its profile page.</summary>
    internal sealed class CoopMessagesView : BaseView
    {
        public override void OnNavigatedTo(object arg)
        {
            Render();
        }

        private void Render()
        {
            try
            {
                var inbox = AppServices.Engagement.GetInbox();
                int unread = 0; foreach (var m in inbox) if (!m.IsRead) unread++;
                Page.Clear();
                Page.Add(Ui.Title("Messages"), 4);
                Page.Add(Ui.Sub(inbox.Count == 0 ? "Consumers can message you from your cooperative page."
                    : inbox.Count + " " + Ui.Plural(inbox.Count, "message", "messages") + (unread > 0 ? " · " + unread + " unread" : " · all read")), 18);

                if (inbox.Count == 0)
                {
                    var empty = new Card();
                    empty.Body.Add(Ui.Text("No messages yet.", 12f, FontStyle.Bold, Theme.Ink, Theme.Surface), 6);
                    empty.Body.Add(Ui.Text("When a consumer writes to your cooperative, it will show up here.", 10.5f, FontStyle.Regular, Theme.Muted, Theme.Surface), 0);
                    Page.Add(empty, 0);
                    return;
                }

                foreach (var m in inbox)
                {
                    var msg = m;
                    var card = new Card { Inset = 20, Surface = msg.IsRead ? Theme.Surface : Theme.UnreadTint };
                    card.Body.Add(new MessageHeader(msg), 6);
                    card.Body.Add(Ui.Text(msg.Body, 10.5f, FontStyle.Regular, Theme.Ink, card.Body.BackColor), msg.IsRead ? 0 : 12);
                    if (!msg.IsRead)
                    {
                        var read = Ui.Button("Mark as read", BtnStyle.Outline, 130, 34);
                        read.Click += (s, e) =>
                        {
                            try { AppServices.Engagement.MarkRead(msg.MessageId); NotifyCartChanged(); }
                            catch (Exception ex) { ShowError(ex, "updating the message"); }
                            Defer(Render);
                        };
                        card.Body.AddFixed(read, 0);
                    }
                    Page.Add(card, 12);
                }
            }
            catch (Exception ex) { ShowError(ex, "loading your messages"); }
        }

        private sealed class MessageHeader : Control
        {
            private readonly CoopMessage _m;
            public MessageHeader(CoopMessage m)
            {
                _m = m; Height = 24;
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
                BackColor = Color.Transparent;
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                var flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
                int x = 0;
                var nameFont = Theme.Body(10.5f, FontStyle.Bold);
                if (!_m.IsRead) { e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias; using (var b = new SolidBrush(Theme.MarigoldText)) e.Graphics.FillEllipse(b, 0, 7, 10, 10); x = 18; }
                TextRenderer.DrawText(e.Graphics, _m.FromName, nameFont, new Rectangle(x, 0, Width - x - 190, Height), Theme.Ink, flags);
                if (!_m.IsRead)    // unread is shown with a word as well as a dot and a tint, so it never depends on colour alone
                {
                    int nw = Math.Min(Width - x - 250, TextRenderer.MeasureText(_m.FromName ?? "", nameFont, new Size(2000, Height), flags).Width);
                    TextRenderer.DrawText(e.Graphics, "New", Theme.Body(9f, FontStyle.Bold), new Rectangle(x + nw + 10, 0, 50, Height), Theme.MarigoldText, flags);
                }
                TextRenderer.DrawText(e.Graphics, Ui.When(_m.CreatedAt), Theme.Body(9f), new Rectangle(Width - 190, 0, 190, Height), Theme.Muted,
                    TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
        }
    }
}
