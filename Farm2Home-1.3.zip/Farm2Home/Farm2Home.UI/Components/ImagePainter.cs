using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Farm2Home.UI.Components
{
    /// <summary>Draws a product/cooperative picture (cropped to fill) or a friendly placeholder.</summary>
    internal static class ImagePainter
    {
        public static void Paint(Graphics g, Rectangle r, string file, bool coop, int radius, bool topOnly = false)
        {
            var img = ImageStore.Load(file);
            using (var path = topOnly ? TopRounded(r, radius) : GraphicsUtil.RoundedRect(r, radius))
            {
                g.SetClip(path, CombineMode.Replace);
                if (img != null)
                {
                    float scale = Math.Max((float)r.Width / img.Width, (float)r.Height / img.Height);
                    float sw = r.Width / scale, sh = r.Height / scale;
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.DrawImage(img, r, (img.Width - sw) / 2f, (img.Height - sh) / 2f, sw, sh, GraphicsUnit.Pixel);
                }
                else
                {
                    using (var b = new SolidBrush(Theme.MossLight)) g.FillRectangle(b, r);
                    if (coop)
                    {
                        int sz = Math.Max(20, Math.Min(r.Height, r.Width) * 36 / 100);
                        IconPainter.Draw(g, Icons.Cooperatives, new Rectangle(r.X + (r.Width - sz) / 2, r.Y + (r.Height - sz) / 2, sz, sz), Theme.IconGreen, Math.Max(1.6f, sz / 14f));
                    }
                    else DrawLeaf(g, r);
                }
                g.ResetClip();
            }
        }

        private static GraphicsPath TopRounded(Rectangle r, int radius)
        {
            var p = new GraphicsPath(); int d = radius * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddLine(r.Right, r.Bottom, r.X, r.Bottom); p.CloseFigure(); return p;
        }

        private static void DrawLeaf(Graphics g, Rectangle r)
        {
            float s = Math.Min(r.Width, r.Height) * 0.30f;
            float x = r.X + (r.Width - s) / 2f, y = r.Y + (r.Height - s) / 2f;
            using (var p = new GraphicsPath())
            using (var pen = new Pen(Theme.IconGreen, Math.Max(2f, s / 18f)) { LineJoin = LineJoin.Round })
            {
                p.AddBezier(x, y + s, x, y + s * 0.3f, x + s * 0.3f, y, x + s, y);
                p.AddBezier(x + s, y, x + s, y + s * 0.7f, x + s * 0.7f, y + s, x, y + s);
                g.DrawPath(pen, p);
            }
        }
    }
}
