using Farm2Home.Domain.Enums;

namespace Farm2Home.UI.Components
{
    internal static class OrderStatusText
    {
        public static string Of(OrderStatus s)
        {
            switch (s)
            {
                case OrderStatus.Pending: return "Pending";
                case OrderStatus.Confirmed: return "Confirmed";
                case OrderStatus.Preparing: return "Preparing";
                case OrderStatus.ReadyForDelivery: return "Ready for delivery";
                case OrderStatus.OutForDelivery: return "Out for delivery";
                case OrderStatus.Delivered: return "Delivered";
                case OrderStatus.Cancelled: return "Cancelled";
                default: return s.ToString();
            }
        }
    }
}
