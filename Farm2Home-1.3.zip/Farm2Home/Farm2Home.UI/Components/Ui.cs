using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Components
{
    /// <summary>Small factory/format helpers so every screen looks and reads the same.</summary>
    internal static class Ui
    {
        public static string Money(decimal v)
        {
            return "\u20B1" + (v == Math.Floor(v) ? v.ToString("#,##0") : v.ToString("#,##0.00"));
        }

        public static string ItemsSummary(Farm2Home.Domain.Entities.Order o)
        {
            if (o.Items == null || o.Items.Count == 0) return "";
            string s = string.Join(", ", System.Linq.Enumerable.Select(System.Linq.Enumerable.Take(o.Items, 2), i => i.ProductName));
            return o.Items.Count > 2 ? s + " +" + (o.Items.Count - 2) + " more" : s;
        }

        public static string ShortMoney(decimal v)
        {
            return v >= 1000m ? "\u20B1" + (v / 1000m).ToString("0.#") + "k" : Money(v);
        }

        /// <summary>"Harvested Sep 18, 2026" -> "2 days ago"; free text like "Harvested this week" -> "this week".</summary>
        public static string HarvestLabel(string harvestInfo)
        {
            if (string.IsNullOrWhiteSpace(harvestInfo)) return "\u2014";
            string t = harvestInfo.Trim();
            if (t.StartsWith("Harvested ", StringComparison.OrdinalIgnoreCase)) t = t.Substring(10);
            DateTime d;
            if (DateTime.TryParseExact(t, "MMM d, yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out d))
            {
                int days = (int)(DateTime.Today - d.Date).TotalDays;
                if (days <= 0) return "today";
                if (days == 1) return "yesterday";
                return days + " days ago";
            }
            return t;
        }

        public static string PaymentText(string method)
        {
            return method == "CashOnDelivery" ? "Cash on delivery" : method;
        }

        public static string When(DateTime d) { return d.ToString("MMM d, yyyy  h:mm tt"); }

        public static string Plural(int n, string one, string many) { return n == 1 ? one : many; }

        public static string Greeting()
        {
            int h = DateTime.Now.Hour;
            return h < 12 ? "Good morning" : (h < 18 ? "Good afternoon" : "Good evening");
        }

        public static string UnitName(string unit)
        {
            switch (unit)
            {
                case "kg": return "kilogram";
                case "g": return "gram";
                case "liter": return "liter";
                default: return unit;
            }
        }

        public static AutoLabel Text(string text, float size = 10.5f, FontStyle style = FontStyle.Regular, Color? color = null, Color? back = null)
        {
            return new AutoLabel
            {
                Text = text, Font = Theme.Body(size, style), ForeColor = color ?? Theme.Ink,
                BackColor = back ?? Color.Transparent
            };
        }

        public static AutoLabel Title(string text) { return new AutoLabel { Text = text, Font = Theme.Heading(19f), ForeColor = Theme.Ink }; }
        public static AutoLabel Sub(string text) { return Text(text, 10f, FontStyle.Regular, Theme.Muted); }
        public static AutoLabel Section(string text) { return Text(text, 12f, FontStyle.Bold, Theme.Ink); }
        public static AutoLabel Muted(string text) { return Text(text, 10f, FontStyle.Regular, Theme.Muted); }

        public static FlatButton Button(string text, BtnStyle style, int width = 150, int height = 38)
        {
            return new FlatButton { Text = text, Style = style, Size = new Size(width, height) };
        }

        public static CheckBox Check(string text)
        {
            return new CheckBox { Text = text, AutoSize = false, Height = 26, Font = Theme.Body(10f), ForeColor = Theme.Ink, Cursor = Cursors.Hand };
        }

        /// <summary>A label above an input.</summary>
        public static VStack Field(string label, Control input)
        {
            var v = new VStack();
            v.Add(Text(label, 9.5f, FontStyle.Bold, Theme.Muted), 6);
            v.Add(input, 0);
            return v;
        }

        public static WrapRow Buttons(params Control[] items)
        {
            var r = new WrapRow { Gap = 12 };
            foreach (var i in items) r.Controls.Add(i);
            return r;
        }
    }
}

namespace Farm2Home.UI.Components
{
    /// <summary>Turns the real review average and count into text. No reviews yet shows a plain note instead of a made-up number.</summary>
    internal static class RatingText
    {
        public static string Short(double avg, int count) { return count <= 0 ? "No reviews yet" : avg.ToString("0.0") + " (" + count + ")"; }
        public static string Long(double avg, int count) { return count <= 0 ? "No reviews yet" : avg.ToString("0.0") + " \u00B7 " + count + (count == 1 ? " review" : " reviews"); }
    }
}
