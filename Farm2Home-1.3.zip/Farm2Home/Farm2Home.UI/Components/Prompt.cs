using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Components
{
    /// <summary>Tiny "type a value" dialog (used for updating stock).</summary>
    internal static class Prompt
    {
        /// <summary>Returns the text, or null if cancelled.</summary>
        public static string Ask(IWin32Window owner, string title, string message, string initial)
        {
            using (var f = new Form())
            {
                f.Text = title; f.FormBorderStyle = FormBorderStyle.FixedDialog; f.MaximizeBox = false; f.MinimizeBox = false;
                f.StartPosition = FormStartPosition.CenterParent; f.ClientSize = new Size(420, 210); f.BackColor = Theme.Background;
                f.Font = Theme.Body(10f); f.ShowInTaskbar = false;

                var label = Ui.Text(message, 10.5f, FontStyle.Regular, Theme.Ink);
                label.SetBounds(24, 22, 372, 44);
                var input = new InputBox { Text = initial ?? "", Location = new Point(24, 76), Width = 372 };
                var ok = Ui.Button("OK", BtnStyle.Primary, 120, 44); ok.Location = new Point(276, 146);
                var cancel = Ui.Button("Cancel", BtnStyle.Outline, 120, 44); cancel.Location = new Point(146, 146);
                string result = null;
                ok.Click += (s, e) => { result = input.Text; f.DialogResult = DialogResult.OK; };
                cancel.Click += (s, e) => { f.DialogResult = DialogResult.Cancel; };
                input.EnterPressed += () => { result = input.Text; f.DialogResult = DialogResult.OK; };
                f.Controls.AddRange(new Control[] { label, input, ok, cancel });
                f.Shown += (s, e) => { input.Inner.Focus(); input.Inner.SelectAll(); };
                return f.ShowDialog(owner) == DialogResult.OK ? result : null;
            }
        }
    }
}
