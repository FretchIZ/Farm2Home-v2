using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using Farm2Home.Application;

namespace Farm2Home.UI.Components
{
    /// <summary>Product/cooperative images live in %LocalAppData%\Farm2Home\images. Only real JPG/PNG files are accepted.</summary>
    internal static class ImageStore
    {
        private const long MaxBytes = 5L * 1024 * 1024;
        private static readonly string Dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Farm2Home", "images");
        private static readonly Dictionary<string, Image> Cache = new Dictionary<string, Image>();

        /// <summary>Returns the image, or null if missing/corrupt so the caller can draw a placeholder.</summary>
        public static Image Load(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName)) return null;
            string safe = Path.GetFileName(fileName);
            Image cached;
            if (Cache.TryGetValue(safe, out cached)) return cached;
            try
            {
                string path = Path.Combine(Dir, safe);
                if (!File.Exists(path)) return null;
                using (var ms = new MemoryStream(File.ReadAllBytes(path)))
                using (var img = Image.FromStream(ms))
                {
                    var bmp = new Bitmap(img);       // copy so the file is never locked
                    Cache[safe] = bmp;
                    return bmp;
                }
            }
            catch { return null; }
        }

        /// <summary>Validates the picked file and copies it into the app's image folder. Returns the stored file name.</summary>
        public static string Import(string sourcePath)
        {
            try
            {
                string ext = (Path.GetExtension(sourcePath) ?? "").ToLowerInvariant();
                if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                    throw new BusinessException("Please choose a JPG or PNG image.");
                var info = new FileInfo(sourcePath);
                if (!info.Exists) throw new BusinessException("That image could not be found.");
                if (info.Length > MaxBytes) throw new BusinessException("Images must be 5 MB or smaller.");

                byte[] bytes = File.ReadAllBytes(sourcePath);
                bool isPng = bytes.Length > 8 && bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47;
                bool isJpg = bytes.Length > 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF;
                if (!isPng && !isJpg) throw new BusinessException("That file is not a valid JPG or PNG image.");

                using (var ms = new MemoryStream(bytes))
                using (var img = Image.FromStream(ms))
                    if (img.Width > 8000 || img.Height > 8000) throw new BusinessException("That image is too large.");

                Directory.CreateDirectory(Dir);
                string name = Guid.NewGuid().ToString("N") + (isPng ? ".png" : ".jpg");
                File.WriteAllBytes(Path.Combine(Dir, name), bytes);
                return name;
            }
            catch (BusinessException) { throw; }
            catch (Exception) { throw new BusinessException("That image could not be read. Please choose a different file."); }
        }
    }
}
