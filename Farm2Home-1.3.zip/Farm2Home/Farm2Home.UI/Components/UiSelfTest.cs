using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Farm2Home.Application.DTOs;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.Infrastructure.Data;
using Farm2Home.Infrastructure.Security;
using Farm2Home.UI.Forms;
using Farm2Home.UI.Navigation;

namespace Farm2Home.UI.Components
{
    /// <summary>
    /// Built-in page-speed and smoke test. Run it with:  Farm2Home.exe --selftest [--stress] [--shots folder] [--report file]
    /// It signs in as the demo consumer and the demo cooperative, opens EVERY screen (cold = first time, warm = second time),
    /// measures how long each one takes to appear fully drawn and fails if any screen is slower than the budget.
    /// Messages that would normally open a dialog are collected and listed instead, so the run never blocks.
    /// </summary>
    internal static class UiSelfTest
    {
        public const int BudgetMs = 1000;

        private static string _shotCmd;     // optional: a command that saves the screen, e.g. "import -window root {0}" ({0} = file name)

        private sealed class Row { public string Role, Page; public long Cold, Warm; public int Controls; }

        private static System.Drawing.Size? _size;

        public static int Run(string[] args)
        {
            string shots = Arg(args, "--shots"), reportPath = Arg(args, "--report");
            _shotCmd = Arg(args, "--shotcmd");
            var sz = Arg(args, "--size");   // e.g. 1000x660: opens the main window at that size so layouts can be checked
            if (sz != null) { var pr = sz.Split('x'); int w, h; if (pr.Length == 2 && int.TryParse(pr[0], out w) && int.TryParse(pr[1], out h)) _size = new System.Drawing.Size(w, h); }
            var errors = new List<string>();
            UiErrors.TestSink = m => errors.Add(m);
            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
            if (!string.IsNullOrEmpty(shots)) Directory.CreateDirectory(shots);

            var rows = new List<Row>();
            var total = Stopwatch.StartNew();
            var setup = DatabaseInitializer.EnsureReady();
            if (!setup.Success) { Console.WriteLine("SETUP FAILED: " + setup.UserMessage + " | " + setup.Technical); return 2; }
            AppServices.Initialize();
            Console.WriteLine("Database ready in " + setup.Milliseconds + " ms (" + setup.Summary + ")");
            if (Array.IndexOf(args, "--stress") >= 0)
            {
                string note = StressDataGenerator.Generate(DbConfig.ConnectionString, new StressProfile());
                Console.WriteLine("Large-data test: " + note);
            }

            try { RunForms(rows, errors, shots, setup); }
            catch (Exception ex) { errors.Add("FORMS RUN CRASHED: " + ex); }
            try { RunConsumer(rows, errors, shots); }
            catch (Exception ex) { errors.Add("CONSUMER RUN CRASHED: " + ex); }
            try { RunCooperative(rows, errors, shots); }
            catch (Exception ex) { errors.Add("COOPERATIVE RUN CRASHED: " + ex); }
            total.Stop();

            var sb = new StringBuilder();
            sb.AppendLine("Farm2Home page-load self-test   (budget " + BudgetMs + " ms per page)");
            sb.AppendLine(new string('-', 78));
            sb.AppendLine(Pad("Role", 13) + Pad("Page", 24) + Pad("First open", 12) + Pad("Second open", 13) + Pad("Controls", 10) + "Result");
            sb.AppendLine(new string('-', 78));
            int slow = 0;
            foreach (var r in rows)
            {
                bool ok = r.Cold <= BudgetMs && r.Warm <= BudgetMs;
                if (!ok) slow++;
                sb.AppendLine(Pad(r.Role, 13) + Pad(r.Page, 24) + Pad(r.Cold + " ms", 12) + Pad(r.Warm + " ms", 13) + Pad(r.Controls.ToString(), 10) + (ok ? "PASS" : "SLOW"));
            }
            sb.AppendLine(new string('-', 78));
            if (rows.Count > 0)
                sb.AppendLine("Pages: " + rows.Count + "   slowest first open: " + rows.Max(x => x.Cold) + " ms   slowest second open: " + rows.Max(x => x.Warm) +
                              " ms   average first open: " + (long)rows.Average(x => x.Cold) + " ms");
            sb.AppendLine("Slow pages: " + slow + "   Errors: " + errors.Count + "   Total run: " + total.ElapsedMilliseconds + " ms");
            foreach (var e in errors) sb.AppendLine("  ! " + e.Replace("\n", " | "));
            Console.WriteLine(sb.ToString());
            if (!string.IsNullOrEmpty(reportPath)) { try { File.WriteAllText(reportPath, sb.ToString()); } catch { } }
            return slow == 0 && errors.Count == 0 && rows.Count > 0 ? 0 : 1;
        }

        // ------------------------------------------------------------------ sign-in, register, reset (no user needed)
        private static void RunForms(List<Row> rows, List<string> errors, string shots, DatabaseSetupResult setup)
        {
            OpenForm(rows, shots, "Sign-in window", "signin", () => new LoginForm(System.Threading.Tasks.Task.FromResult(setup)));
            OpenForm(rows, shots, "Create account form", "register", () => new RegisterForm());
            OpenForm(rows, shots, "Reset password form", "reset", () => new ResetPasswordForm("someone@example.com"));
        }

        private static void OpenForm(List<Row> rows, string shots, string label, string shotName, Func<Form> make)
        {
            var sw = Stopwatch.StartNew();
            using (var f = make())
            {
                f.Show();
                Settle(f);
                sw.Stop();
                long cold = sw.ElapsedMilliseconds;
                Shot(f, shots, "form-" + shotName);
                rows.Add(new Row { Role = "Anyone", Page = label, Cold = cold, Warm = cold, Controls = CountControls(f) });
                f.Close();
            }
        }

        // ------------------------------------------------------------------ consumer
        private static void RunConsumer(List<Row> rows, List<string> errors, string shots)
        {
            AppServices.Auth.Login(DemoAccounts.ConsumerEmail, DemoAccounts.Password, UserRole.Consumer);
            var products = AppServices.Catalog.Browse(new ProductFilter { InStockOnly = true });
            var coops = AppServices.Catalog.GetCooperatives();
            AppServices.Cart.Clear();
            foreach (var p in products.Take(3)) AppServices.Cart.Add(p.ProductId, 1);

            using (var shell = new MainShellForm())
            {
                var sw = Stopwatch.StartNew();
                if (_size.HasValue) { shell.StartPosition = FormStartPosition.Manual; shell.Location = new System.Drawing.Point(0, 0); shell.Size = _size.Value; }
                shell.Show();
                Settle(shell);
                sw.Stop();
                rows.Add(new Row { Role = "Consumer", Page = "Window + Home (launch)", Cold = sw.ElapsedMilliseconds, Warm = TimeNav(shell, ViewId.Home, null), Controls = CountControls(shell) });
                Shot(shell, shots, "consumer-home");

                Visit(rows, shell, "Consumer", ViewId.Browse, null, shots);
                Visit(rows, shell, "Consumer", ViewId.ProductDetail, products[0].ProductId, shots);
                Visit(rows, shell, "Consumer", ViewId.Cart, null, shots);
                Visit(rows, shell, "Consumer", ViewId.Checkout, null, shots);

                var orders = AppServices.Orders.PlaceOrders(new CheckoutRequest
                {
                    CustomerName = "Maria Clara", ContactNumber = "0917-555-0101",
                    DeliveryAddress = "12 Sampaguita St., Brgy. Commonwealth, Quezon City, Metro Manila", PaymentMethod = "CashOnDelivery"
                });
                var arg = new OrderViewArg { JustPlaced = true };
                arg.OrderIds.AddRange(orders.Select(o => o.OrderId));
                Visit(rows, shell, "Consumer", ViewId.OrderTracking, arg, shots);
                Visit(rows, shell, "Consumer", ViewId.Orders, null, shots);
                Visit(rows, shell, "Consumer", ViewId.Cooperatives, null, shots);
                if (coops.Count > 0) Visit(rows, shell, "Consumer", ViewId.CooperativeProfile, coops[0].CooperativeId, shots);
                Visit(rows, shell, "Consumer", ViewId.Profile, null, shots);
                shell.Close();
            }
            AppServices.Auth.Logout();
        }

        // ------------------------------------------------------------------ cooperative
        private static void RunCooperative(List<Row> rows, List<string> errors, string shots)
        {
            AppServices.Auth.Login(DemoAccounts.CooperativeEmail, DemoAccounts.Password, UserRole.Cooperative);
            var listings = AppServices.ProductManagement.GetListings();
            using (var shell = new MainShellForm())
            {
                var sw = Stopwatch.StartNew();
                if (_size.HasValue) { shell.StartPosition = FormStartPosition.Manual; shell.Location = new System.Drawing.Point(0, 0); shell.Size = _size.Value; }
                shell.Show();
                Settle(shell);
                sw.Stop();
                rows.Add(new Row { Role = "Cooperative", Page = "Window + Dashboard (launch)", Cold = sw.ElapsedMilliseconds, Warm = TimeNav(shell, ViewId.CoopDashboard, null), Controls = CountControls(shell) });
                Shot(shell, shots, "coop-dashboard");

                Visit(rows, shell, "Cooperative", ViewId.CoopProducts, null, shots);
                Visit(rows, shell, "Cooperative", ViewId.ProductEditor, null, shots, "ProductEditor (new)");
                if (listings.Count > 0) Visit(rows, shell, "Cooperative", ViewId.ProductEditor, listings[0].ProductId, shots, "ProductEditor (edit)");
                Visit(rows, shell, "Cooperative", ViewId.CoopOrders, null, shots);
                Visit(rows, shell, "Cooperative", ViewId.CoopEarnings, null, shots);
                Visit(rows, shell, "Cooperative", ViewId.CoopMessages, null, shots);
                Visit(rows, shell, "Cooperative", ViewId.CoopProfile, null, shots);
                shell.Close();
            }
            AppServices.Auth.Logout();
        }

        // ------------------------------------------------------------------ helpers
        private static void Visit(List<Row> rows, MainShellForm shell, string role, ViewId id, object arg, string shots, string label = null)
        {
            long cold = TimeNav(shell, id, arg);
            Shot(shell, shots, role.ToLowerInvariant() + "-" + (label ?? id.ToString()).Replace(" ", "").Replace("(", "-").Replace(")", ""));
            long warm = TimeNav(shell, id, arg);
            rows.Add(new Row { Role = role, Page = label ?? id.ToString(), Cold = cold, Warm = warm, Controls = CountControls(shell) });
        }

        /// <summary>Time from "open the page" until it is fully built, filled with data and painted.</summary>
        private static long TimeNav(MainShellForm shell, ViewId id, object arg)
        {
            var sw = Stopwatch.StartNew();
            shell.Navigation.NavigateRoot(id, arg);
            Settle(shell);
            sw.Stop();
            return sw.ElapsedMilliseconds;
        }

        /// <summary>Lets queued work (page loads on a background thread, layout, painting) finish.</summary>
        private static void Settle(Form shell)
        {
            var guard = Stopwatch.StartNew();
            do
            {
                System.Windows.Forms.Application.DoEvents();
                var nav = (shell as MainShellForm) == null ? null : ((MainShellForm)shell).Navigation;
                if (nav != null && !nav.IsLoading) break;
            } while (guard.ElapsedMilliseconds < 15000);
            shell.Refresh();
            System.Windows.Forms.Application.DoEvents();
        }

        private static int CountControls(Control c) { int n = 1; foreach (Control k in c.Controls) n += CountControls(k); return n; }

        private static void Shot(Form f, string dir, string name)
        {
            if (string.IsNullOrEmpty(dir)) return;
            try
            {
                if (!string.IsNullOrEmpty(_shotCmd))
                {
                    string file = Path.Combine(dir, name + ".png");
                    var psi = new ProcessStartInfo("/bin/sh", "-c \"" + string.Format(_shotCmd, file) + "\"") { UseShellExecute = false, CreateNoWindow = true };
                    using (var p = Process.Start(psi)) { if (p != null) p.WaitForExit(8000); }
                    return;
                }
                using (var bmp = new Bitmap(f.Width, f.Height))
                {
                    f.DrawToBitmap(bmp, new Rectangle(0, 0, f.Width, f.Height));
                    bmp.Save(Path.Combine(dir, name + ".png"), ImageFormat.Png);
                }
            }
            catch { /* screenshots are optional */ }
        }

        private static string Arg(string[] a, string name)
        {
            for (int i = 0; i < a.Length - 1; i++) if (string.Equals(a[i], name, StringComparison.OrdinalIgnoreCase)) return a[i + 1];
            return null;
        }

        private static string Pad(string s, int n) { return (s ?? "").Length >= n ? s.Substring(0, n - 1) + " " : (s ?? "").PadRight(n); }
    }
}
