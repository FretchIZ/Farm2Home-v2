using System.Drawing;
using System.Windows.Forms;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Components
{
    /// <summary>"Write a message" dialog with a multi-line box. Returns the text, or null if cancelled.</summary>
    internal static class MessageDialog
    {
        public static string Ask(IWin32Window owner, string title, string intro, string okText)
        {
            using (var f = new Form())
            {
                f.Text = title; f.FormBorderStyle = FormBorderStyle.FixedDialog; f.MaximizeBox = false; f.MinimizeBox = false;
                f.StartPosition = FormStartPosition.CenterParent; f.ClientSize = new Size(480, 300); f.BackColor = Theme.Background;
                f.Font = Theme.Body(10f); f.ShowInTaskbar = false;

                var label = Ui.Text(intro, 10.5f, FontStyle.Regular, Theme.Ink);
                label.SetBounds(24, 20, 432, 44);
                var input = new InputBox(true) { MaxLength = 500, Location = new Point(24, 70), Width = 432, Height = 140, Placeholder = "Type your message…" };
                var counter = Ui.Text("0 / 500", 9f, FontStyle.Regular, Theme.Muted);
                counter.SetBounds(24, 216, 200, 18);
                input.Inner.TextChanged += (s, e) => counter.Text = input.Text.Length + " / 500";
                var ok = Ui.Button(okText, BtnStyle.Primary, 140, 42); ok.Location = new Point(316, 244);
                var cancel = Ui.Button("Cancel", BtnStyle.Outline, 120, 42); cancel.Location = new Point(186, 244);
                string result = null;
                ok.Click += (s, e) => { result = input.Text; f.DialogResult = DialogResult.OK; };
                cancel.Click += (s, e) => { f.DialogResult = DialogResult.Cancel; };
                f.Controls.AddRange(new Control[] { label, input, counter, ok, cancel });
                f.Shown += (s, e) => input.Inner.Focus();
                return f.ShowDialog(owner) == DialogResult.OK ? result : null;
            }
        }
    }
}
