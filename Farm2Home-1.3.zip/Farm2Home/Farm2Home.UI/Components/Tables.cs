using System;
using System.Drawing;
using System.Windows.Forms;
using Farm2Home.Domain.Enums;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Components
{
    /// <summary>Consistent, clean data tables.</summary>
    internal static class Tables
    {
        public const int RowHeight = 46;
        public const int HeaderHeight = 40;

        public static DataGridView Create()
        {
            var g = new DataGridView
            {
                AllowUserToAddRows = false, AllowUserToDeleteRows = false, AllowUserToResizeRows = false,
                AllowUserToResizeColumns = false, ReadOnly = true, RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
                BorderStyle = BorderStyle.None, BackgroundColor = Theme.Surface, GridColor = Theme.Border,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = HeaderHeight,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Dock = DockStyle.Fill, ScrollBars = ScrollBars.None, StandardTab = true
            };
            g.RowTemplate.Height = RowHeight;
            g.ColumnHeadersDefaultCellStyle.BackColor = Theme.Background;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted;
            g.ColumnHeadersDefaultCellStyle.Font = Theme.Body(9f, FontStyle.Bold);
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Theme.Background;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Theme.Muted;
            g.ColumnHeadersDefaultCellStyle.Padding = new Padding(12, 0, 12, 0);
            g.DefaultCellStyle.BackColor = Theme.Surface;
            g.DefaultCellStyle.ForeColor = Theme.Ink;
            g.DefaultCellStyle.Font = Theme.Body(9.5f);
            g.DefaultCellStyle.SelectionBackColor = Theme.MossLight;
            g.DefaultCellStyle.SelectionForeColor = Theme.Ink;
            g.DefaultCellStyle.Padding = new Padding(12, 0, 12, 0);
            return g;
        }

        public static void AddColumn(DataGridView g, string header, float weight)
        {
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = header, FillWeight = weight, SortMode = DataGridViewColumnSortMode.NotSortable });
        }

        /// <summary>Wraps the grid in a card and lets you size the card to the current rows.</summary>
        public static RoundedPanel Wrap(DataGridView g)
        {
            var card = new RoundedPanel { Padding = new Padding(1), Height = HeaderHeight + 2 };
            card.Controls.Add(g);
            return card;
        }

        public static void Fit(RoundedPanel card, DataGridView g, int maxRows)
        {
            int rows = Math.Max(1, Math.Min(g.Rows.Count, maxRows));
            g.ScrollBars = g.Rows.Count > maxRows ? ScrollBars.Vertical : ScrollBars.None;
            card.Height = HeaderHeight + rows * RowHeight + 4;
        }

        /// <summary>Draws the given column as a coloured status pill. Each row's Tag must be the Order.</summary>
        public static void UsePills(DataGridView g, int column)
        {
            g.CellPainting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex != column) return;
                var o = g.Rows[e.RowIndex].Tag as Farm2Home.Domain.Entities.Order;
                if (o == null) return;
                e.PaintBackground(e.CellBounds, (e.State & DataGridViewElementStates.Selected) != 0);
                Color bg, fg;
                switch (o.OrderStatus)
                {
                    case OrderStatus.Pending: bg = Theme.MarigoldSoft; fg = Theme.MarigoldText; break;
                    case OrderStatus.Confirmed: case OrderStatus.Preparing: bg = Theme.InfoSoft; fg = Theme.Info; break;
                    case OrderStatus.ReadyForDelivery: case OrderStatus.OutForDelivery: bg = Theme.MossLight; fg = Theme.Forest; break;
                    case OrderStatus.Cancelled: bg = Theme.DangerSoft; fg = Theme.Danger; break;
                    default: bg = Theme.NeutralBadge; fg = Theme.Muted; break;
                }
                string text = OrderStatusText.Of(o.OrderStatus);
                var f = Theme.Body(9f, FontStyle.Bold);
                int w = TextRenderer.MeasureText(text, f, new Size(300, 30), TextFormatFlags.NoPadding).Width + 22;
                var pill = new Rectangle(e.CellBounds.X + 12, e.CellBounds.Y + (e.CellBounds.Height - 22) / 2, w, 22);
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var path = GraphicsUtil.RoundedRect(pill, 11)) using (var b = new SolidBrush(bg)) e.Graphics.FillPath(b, path);
                TextRenderer.DrawText(e.Graphics, text, f, pill, fg, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                e.Handled = true;
            };
        }

        public static Color StatusColor(OrderStatus s)
        {
            switch (s)
            {
                case OrderStatus.Pending: return Theme.MarigoldText;
                case OrderStatus.Confirmed:
                case OrderStatus.Preparing: return Theme.Info;
                case OrderStatus.ReadyForDelivery:
                case OrderStatus.OutForDelivery:
                case OrderStatus.Delivered: return Theme.Forest;
                default: return Theme.Danger;
            }
        }
    }
}
