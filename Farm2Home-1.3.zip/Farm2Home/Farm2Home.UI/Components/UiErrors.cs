using System;
using System.Data.Common;
using System.Windows.Forms;
using Farm2Home.Application;
using Farm2Home.Infrastructure.Configuration;

namespace Farm2Home.UI.Components
{
    /// <summary>One place that turns exceptions into friendly messages and logs the technical detail.</summary>
    internal static class UiErrors
    {
        /// <summary>Used only by automated UI tests: when set, messages go here instead of opening a message box (and Confirm answers Yes).</summary>
        internal static Action<string> TestSink;

        public static void Show(IWin32Window owner, Exception ex, string doingWhat)
        {
            if (TestSink != null)
            {
                TestSink((ex is BusinessException ? "INFO: " : "ERROR: ") + doingWhat + " | " + ex.Message + (ex is BusinessException ? "" : "\n" + ex));
                return;
            }
            if (ex is BusinessException)
            {
                MessageBox.Show(owner, ex.Message, "Farm2Home", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (AppServices.Logger != null) AppServices.Logger.Error(ex, doingWhat);

            string text = ex is DbException
                ? "Farm2Home couldn't reach its database while " + doingWhat + ".\nPlease check your connection and try again."
                : "Something went wrong while " + doingWhat + ".\nPlease try again.";
            MessageBox.Show(owner, text, "Farm2Home", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void Info(IWin32Window owner, string message)
        {
            if (TestSink != null) { TestSink("INFO: " + message); return; }
            MessageBox.Show(owner, message, "Farm2Home", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static bool Confirm(IWin32Window owner, string message)
        {
            if (TestSink != null) { TestSink("CONFIRM: " + message); return true; }
            return MessageBox.Show(owner, message, "Farm2Home", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}
