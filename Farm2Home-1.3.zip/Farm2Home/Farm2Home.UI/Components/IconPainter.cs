using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Farm2Home.UI.Components
{
    /// <summary>Draws the app's line icons as vector shapes (24x24 design grid). No icon font needed.</summary>
    internal static class IconPainter
    {
        public static void Draw(Graphics g, string name, Rectangle box, Color color, float strokeWidth = 0f)
        {
            if (string.IsNullOrEmpty(name)) return;
            int s = Math.Min(box.Width, box.Height);
            float k = s / 24f;
            float w = strokeWidth > 0 ? strokeWidth : Math.Max(1.4f, 1.7f * k);
            var state = g.Save();
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TranslateTransform(box.X + (box.Width - s) / 2f, box.Y + (box.Height - s) / 2f);
            g.ScaleTransform(k, k);
            float pw = w / k;
            using (var pen = new Pen(color, pw) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
            using (var brush = new SolidBrush(color))
                Shape(g, name, pen, brush);
            g.Restore(state);
        }

        private static PointF P(double x, double y) { return new PointF((float)x, (float)y); }

        private static void Shape(Graphics g, string n, Pen pen, Brush fill)
        {
            switch (n)
            {
                case "home":
                    g.DrawLines(pen, new[] { P(3, 11), P(12, 3), P(21, 11) });
                    g.DrawLines(pen, new[] { P(5.5, 9.5), P(5.5, 20), P(18.5, 20), P(18.5, 9.5) });
                    break;
                case "barn":
                    g.DrawLines(pen, new[] { P(3, 21), P(3, 9), P(12, 3), P(21, 9), P(21, 21) });
                    g.DrawLines(pen, new[] { P(9, 21), P(9, 13), P(15, 13), P(15, 21) });
                    break;
                case "search":
                    g.DrawEllipse(pen, 3.5f, 3.5f, 13, 13);
                    g.DrawLine(pen, 15, 15, 20.5f, 20.5f);
                    break;
                case "bag":
                    g.DrawLines(pen, new[] { P(4.5f, 8), P(19.5f, 8), P(18.5f, 20.5f), P(5.5f, 20.5f), P(4.5f, 8) });
                    g.DrawArc(pen, 8, 3, 8, 10, 180, 180);
                    break;
                case "bookmark":
                    g.DrawLines(pen, new[] { P(6, 3.5f), P(18, 3.5f), P(18, 21), P(12, 16.5f), P(6, 21), P(6, 3.5f) });
                    break;
                case "user":
                    g.DrawEllipse(pen, 8, 3.5f, 8, 8);
                    g.DrawArc(pen, 4.5f, 14, 15, 14, 180, 180);
                    break;
                case "grid":
                    Round(g, pen, 3.5f, 3.5f, 7, 7); Round(g, pen, 13.5f, 3.5f, 7, 7);
                    Round(g, pen, 3.5f, 13.5f, 7, 7); Round(g, pen, 13.5f, 13.5f, 7, 7);
                    break;
                case "leaf":
                    using (var p = new GraphicsPath())
                    {
                        p.AddBezier(P(5, 19), P(3, 9), P(10, 3.5f), P(20, 4));
                        p.AddBezier(P(20, 4), P(21, 14), P(15, 20.5f), P(5, 19));
                        g.DrawPath(pen, p);
                    }
                    break;
                case "dollar":
                    g.DrawLine(pen, 12, 2.5f, 12, 21.5f);
                    g.DrawArc(pen, 6.5f, 5, 11, 7, 90, 270);
                    g.DrawArc(pen, 6.5f, 12, 11, 7, -90, 270);
                    break;
                case "signout":
                    g.DrawLines(pen, new[] { P(10, 4), P(4, 4), P(4, 20), P(10, 20) });
                    g.DrawLine(pen, 9, 12, 20, 12); g.DrawLines(pen, new[] { P(16, 8), P(20, 12), P(16, 16) });
                    break;
                case "pin":
                    using (var p = new GraphicsPath())
                    {
                        p.AddArc(5, 2.5f, 14, 14, 150, 240);
                        p.AddLine(P(16.9f, 15.5f), P(12, 21.5f)); p.AddLine(P(12, 21.5f), P(7.1f, 15.5f));
                        g.DrawPath(pen, p);
                    }
                    g.DrawEllipse(pen, 9.5f, 7, 5, 5);
                    break;
                case "bell":
                    using (var p = new GraphicsPath())
                    {
                        p.AddArc(6, 3.5f, 12, 12, 180, 180);
                        p.AddLine(P(18, 9.5f), P(18.5f, 16)); p.AddLine(P(18.5f, 16), P(20, 17.5f)); p.AddLine(P(20, 17.5f), P(4, 17.5f));
                        p.AddLine(P(4, 17.5f), P(5.5f, 16)); p.AddLine(P(5.5f, 16), P(6, 9.5f));
                        g.DrawPath(pen, p);
                    }
                    g.DrawArc(pen, 9.5f, 17.5f, 5, 4, 0, 180);
                    break;
                case "check":
                    g.DrawLines(pen, new[] { P(4.5f, 12.5f), P(9.5f, 17.5f), P(19.5f, 6.5f) });
                    break;
                case "trash":
                    g.DrawLine(pen, 4, 6.5f, 20, 6.5f);
                    g.DrawLines(pen, new[] { P(9, 6.5f), P(9, 3.5f), P(15, 3.5f), P(15, 6.5f) });
                    g.DrawLines(pen, new[] { P(6, 6.5f), P(7, 20.5f), P(17, 20.5f), P(18, 6.5f) });
                    break;
                case "mail":
                    Round(g, pen, 3, 5.5f, 18, 13, 2);
                    g.DrawLines(pen, new[] { new PointF(3.5f, 6.5f), new PointF(12, 13), new PointF(20.5f, 6.5f) });
                    break;
                case "lock":
                    Round(g, pen, 5, 10.5f, 14, 10, 2);
                    g.DrawArc(pen, 8, 3.5f, 8, 9, 180, 180);
                    break;
                case "clock":
                    g.DrawEllipse(pen, 3, 3, 18, 18);
                    g.DrawLines(pen, new[] { P(12, 7), P(12, 12), P(15.5f, 14) });
                    break;
                case "card":
                    Round(g, pen, 2.5f, 5.5f, 19, 13, 2);
                    g.DrawLine(pen, 2.5f, 10, 21.5f, 10);
                    break;
                case "upload":
                    g.DrawLine(pen, 12, 15, 12, 4);
                    g.DrawLines(pen, new[] { P(7.5f, 8), P(12, 3.5f), P(16.5f, 8) });
                    g.DrawLines(pen, new[] { P(4, 15), P(4, 20), P(20, 20), P(20, 15) });
                    break;
                case "people":
                    g.DrawEllipse(pen, 5, 5, 6.5f, 6.5f);
                    g.DrawArc(pen, 2.5f, 13, 11.5f, 12, 180, 180);
                    g.DrawArc(pen, 14.5f, 5.5f, 5.5f, 5.5f, 250, 250);
                    g.DrawArc(pen, 15, 13, 7, 9, 200, 160);
                    break;
                case "alert":
                    g.DrawLines(pen, new[] { P(12, 3.5f), P(21.5f, 20), P(2.5f, 20), P(12, 3.5f) });
                    g.DrawLine(pen, 12, 10, 12, 14.5f);
                    g.FillEllipse(fill, 11.1f, 16.6f, 1.8f, 1.8f);
                    break;
                case "apple":
                    g.DrawArc(pen, 4.5f, 7, 15, 14, 160, 220);
                    g.DrawLine(pen, 12, 8, 13, 3.5f);
                    break;
                case "grain":
                    g.DrawLines(pen, new[] { P(5, 20), P(5, 12), P(8, 6), P(16, 6), P(19, 12), P(19, 20) });
                    g.DrawLine(pen, 5, 20, 19, 20);
                    break;
                case "circle":
                    g.DrawEllipse(pen, 4.5f, 4.5f, 15, 15);
                    break;
                case "sprout":
                    g.DrawLine(pen, 12, 21, 12, 4);
                    g.DrawLine(pen, 12, 13, 7, 8); g.DrawLine(pen, 12, 13, 17, 8);
                    break;
                case "plus":
                    g.DrawLine(pen, 12, 5, 12, 19); g.DrawLine(pen, 5, 12, 19, 12);
                    break;
                case "minus":
                    g.DrawLine(pen, 5, 12, 19, 12);
                    break;
                case "chevron":
                    g.DrawLines(pen, new[] { P(6, 9), P(12, 15), P(18, 9) });
                    break;
                case "star":
                    Star(g, fill);
                    break;
            }
        }

        private static void Round(Graphics g, Pen pen, float x, float y, float w, float h, float r = 1.5f)
        {
            using (var p = GraphicsUtil.RoundedRect(new RectangleF(x, y, w, h), r)) g.DrawPath(pen, p);
        }

        private static PointF[] StarPoints()
        {
            var pts = new PointF[10];
            for (int i = 0; i < 10; i++)
            {
                double a = -Math.PI / 2 + i * Math.PI / 5; float r = i % 2 == 0 ? 10.5f : 4.4f;
                pts[i] = P(12 + (float)(r * Math.Cos(a)), 12.5f + (float)(r * Math.Sin(a)));
            }
            return pts;
        }

        private static void Star(Graphics g, Brush b) { g.FillPolygon(b, StarPoints()); }

        /// <summary>Rating star. Filled = marigold with a darker outline; empty = outline only, so the difference is shape, not just colour.</summary>
        public static void DrawStar(Graphics g, Rectangle box, bool filled)
        {
            var st = g.Save();
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float k = Math.Min(box.Width, box.Height) / 24f;
            g.TranslateTransform(box.X, box.Y); g.ScaleTransform(k, k);
            var pts = StarPoints();
            if (filled)
            {
                using (var b = new SolidBrush(Theme.Marigold)) g.FillPolygon(b, pts);
                using (var pen = new Pen(Theme.MarigoldText, 1.2f / k) { LineJoin = LineJoin.Round }) g.DrawPolygon(pen, pts);
            }
            else using (var pen = new Pen(Theme.ControlBorder, 1.4f / k) { LineJoin = LineJoin.Round }) g.DrawPolygon(pen, pts);
            g.Restore(st);
        }

        /// <summary>The two-leaf sprout used as the Farm2Home mark.</summary>
        public static void DrawMark(Graphics g, Rectangle box, Color color)
        {
            var state = g.Save();
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float k = Math.Min(box.Width, box.Height) / 32f;
            g.TranslateTransform(box.X, box.Y); g.ScaleTransform(k, k);
            using (var pen = new Pen(color, 2.4f) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                using (var left = new GraphicsPath())
                {
                    left.AddBezier(P(2, 6), P(2, 18), P(8, 24), P(16, 27));
                    left.AddBezier(P(16, 27), P(14, 16), P(10, 10), P(2, 6));
                    g.DrawPath(pen, left);
                }
                using (var right = new GraphicsPath())
                {
                    right.AddBezier(P(30, 6), P(30, 18), P(24, 24), P(16, 27));
                    right.AddBezier(P(16, 27), P(18, 16), P(22, 10), P(30, 6));
                    g.DrawPath(pen, right);
                }
            }
            g.Restore(state);
        }

        public static void DrawStar(Graphics g, Rectangle box, Color color)
        {
            using (var b = new SolidBrush(color)) { var st = g.Save(); g.SmoothingMode = SmoothingMode.AntiAlias; float k = Math.Min(box.Width, box.Height) / 24f; g.TranslateTransform(box.X, box.Y); g.ScaleTransform(k, k); Star(g, b); g.Restore(st); }
        }
    }
}
