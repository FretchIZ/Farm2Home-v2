using System;
using System.Drawing;
using System.Windows.Forms;

namespace Farm2Home.UI.Components
{
    /// <summary>Small non-blocking message at the bottom-right of the main window ("Product added to cart").</summary>
    internal sealed class Toast : Form
    {
        protected override bool ShowWithoutActivation { get { return true; } }

        private Toast(string text, bool error)
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            BackColor = error ? Theme.Danger : Theme.Deep;
            var label = new Label
            {
                Text = text, ForeColor = Color.White, BackColor = BackColor, Font = Theme.Body(10.5f, FontStyle.Bold),
                AutoSize = false, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(18, 0, 18, 0)
            };
            var w = TextRenderer.MeasureText(text, label.Font).Width + 44;
            ClientSize = new Size(Math.Min(520, Math.Max(220, w)), 52);
            label.Dock = DockStyle.Fill;
            Controls.Add(label);
            using (var path = GraphicsUtil.RoundedRect(new RectangleF(0, 0, Width, Height), 12)) Region = new Region(path);
        }

        public static void Show(Control owner, string text, bool error = false)
        {
            var host = owner == null ? null : owner.FindForm();
            if (host == null || host.IsDisposed) return;
            var t = new Toast(text, error);
            t.Location = new Point(host.Right - t.Width - 32, host.Bottom - t.Height - 40);
            var timer = new Timer { Interval = 2400 };
            timer.Tick += (s, e) => { timer.Stop(); timer.Dispose(); t.Close(); t.Dispose(); };
            t.Show(host);
            timer.Start();
        }
    }
}
