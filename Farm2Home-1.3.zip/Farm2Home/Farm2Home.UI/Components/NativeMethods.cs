using System;
using System.Runtime.InteropServices;

namespace Farm2Home.UI.Components
{
    internal static class NativeMethods
    {
        private const int EM_SETCUEBANNER = 0x1501;

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, string lParam);

        /// <summary>Shows grey placeholder text inside a TextBox.</summary>
        public static void SetPlaceholder(System.Windows.Forms.TextBox box, string text)
        {
            try { if (box.IsHandleCreated) SendMessage(box.Handle, EM_SETCUEBANNER, 1, text); }
            catch (Exception) { /* placeholder text is cosmetic; never let it break a screen */ }
        }
    }
}
