using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;

namespace Farm2Home.UI.Navigation
{
    /// <summary>Swaps screens inside one host panel. Keeps a back-stack and checks access before opening a screen.</summary>
    internal sealed class NavigationService
    {
        private class HistoryEntry
        {
            public ViewId Id; public object Arg;
            public HistoryEntry(ViewId id, object arg) { Id = id; Arg = arg; }
        }

        private readonly Control _host;
        private readonly Dictionary<ViewId, Func<BaseView>> _factories = new Dictionary<ViewId, Func<BaseView>>();
        private readonly Stack<HistoryEntry> _history = new Stack<HistoryEntry>();
        private BaseView _current;
        private ViewId? _currentId;
        private object _currentArg;

        public event Action<ViewId> Navigated;
        public event Action CartChanged;

        public NavigationService(Control host) { _host = host; }

        /// <summary>True while a screen is still fetching its data (always false for screens that load instantly).</summary>
        public bool IsLoading { get { return _current != null && _current.IsLoading; } }

        public bool CanGoBack { get { return _history.Count > 0; } }
        public ViewId? CurrentId { get { return _currentId; } }

        public void Register(ViewId id, Func<BaseView> factory) { _factories[id] = factory; }

        /// <summary>Open a top-level screen (sidebar click). Clears the back-stack.</summary>
        public void NavigateRoot(ViewId id, object arg = null) { _history.Clear(); Show(id, arg, false); }

        /// <summary>Open a screen on top of the current one so Back returns to it.</summary>
        public void NavigateTo(ViewId id, object arg = null) { Show(id, arg, true); }

        public void GoBack()
        {
            if (_history.Count == 0) return;
            var h = _history.Pop();
            Show(h.Id, h.Arg, false);
        }

        public void NotifyCartChanged() { if (CartChanged != null) CartChanged(); }

        private void Show(ViewId id, object arg, bool pushCurrent)
        {
            var user = AppServices.Session.CurrentUser;
            if (user == null || !ViewInfo.IsAllowed(id, user.Role))
            {
                UiErrors.Info(_host, "You do not have access to that page.");
                return;
            }

            BaseView next;
            try
            {
                Func<BaseView> factory;
                next = _factories.TryGetValue(id, out factory) ? factory() : new PlaceholderView(id);
                next.Attach(this);
            }
            catch (Exception ex)
            {
                UiErrors.Show(_host, ex, "opening that page");
                return;
            }

            if (pushCurrent && _currentId.HasValue) _history.Push(new HistoryEntry(_currentId.Value, _currentArg));

            var old = _current;
            _host.SuspendLayout();
            _host.Controls.Add(next);
            next.BringToFront();
            _current = next; _currentId = id; _currentArg = arg;
            _host.ResumeLayout(true);
            if (old != null) { _host.Controls.Remove(old); old.Dispose(); }

            if (Navigated != null) Navigated(id);
            try { next.OnNavigatedTo(arg); }
            catch (Exception ex) { UiErrors.Show(_host, ex, "loading that page"); }
        }
    }
}
