using System;
using System.Windows.Forms;
using Farm2Home.Domain.Entities;
using Farm2Home.Domain.Enums;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.UI.Components;
using Farm2Home.UI.Controls;

namespace Farm2Home.UI.Navigation
{
    /// <summary>Base class for every screen. Screens are UserControls hosted inside the shell, so there is only one window.</summary>
    internal class BaseView : UserControl
    {
        protected NavigationService Nav { get; private set; }

        /// <summary>Top-to-bottom content column. Add your controls here.</summary>
        protected VStack Page { get; private set; }

        public BaseView()
        {
            BackColor = Theme.Background;
            AutoScroll = true;
            DoubleBuffered = true;
            Padding = new Padding(28, 22, 28, 28);
            Font = Theme.Body(10f);
            Dock = DockStyle.Fill;

            Page = new VStack { Dock = DockStyle.Top };
            Page.SizeChanged += (s, e) => AutoScrollMinSize = new System.Drawing.Size(0, Page.Height + Padding.Vertical);
            Controls.Add(Page);
        }

        internal void Attach(NavigationService nav) { Nav = nav; }

        /// <summary>True while this screen is still fetching its data in the background.</summary>
        public virtual bool IsLoading { get { return false; } }

        /// <summary>Called after the screen is shown. 'arg' is whatever the previous screen passed (product id, search text...).</summary>
        public virtual void OnNavigatedTo(object arg) { }

        protected Farm2Home.Application.Services.SessionUser CurrentUser { get { return AppServices.Session.CurrentUser; } }

        protected void ShowError(Exception ex, string doingWhat) { UiErrors.Show(this, ex, doingWhat); }

        /// <summary>Call after the cart or orders change so the sidebar badges update.</summary>
        protected void NotifyCartChanged() { if (Nav != null) Nav.NotifyCartChanged(); }

        protected void Info(string message, bool error = false) { Toast.Show(this, message, error); }

        /// <summary>Runs after the current event finishes. Use before rebuilding controls from inside their own click handlers.</summary>
        protected void Defer(Action action)
        {
            if (IsHandleCreated && !IsDisposed) BeginInvoke(action);
        }

        protected ProductCard NewProductCard(Product p)
        {
            var user = AppServices.Session.CurrentUser;
            var card = new ProductCard(p, user != null && user.Role == UserRole.Consumer);
            card.OpenRequested += () => Nav.NavigateTo(ViewId.ProductDetail, p.ProductId);
            card.AddRequested += () => QuickAdd(p);
            return card;
        }

        protected CooperativeCard NewCoopCard(Cooperative c)
        {
            var card = new CooperativeCard(c);
            card.OpenRequested += () => Nav.NavigateTo(ViewId.CooperativeProfile, c.CooperativeId);
            return card;
        }

        protected void QuickAdd(Product p)
        {
            try
            {
                AppServices.Cart.Add(p.ProductId, 1);
                NotifyCartChanged();
                Info("\u2713 " + p.ProductName + " added to cart.");
            }
            catch (Exception ex) { ShowError(ex, "adding that item to your cart"); }
        }
    }
}
