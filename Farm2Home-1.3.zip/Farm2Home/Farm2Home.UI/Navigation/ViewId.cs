using Farm2Home.Domain.Enums;

namespace Farm2Home.UI.Navigation
{
    internal enum ViewId
    {
        // Consumer
        Home, Browse, ProductDetail, Cart, Checkout, Orders, OrderTracking, Cooperatives, CooperativeProfile, Profile,
        // Cooperative
        CoopDashboard, CoopProducts, ProductEditor, CoopOrders, CoopEarnings, CoopMessages, CoopProfile
    }

    /// <summary>Rules about screens: who may open them and which sidebar item they belong to.</summary>
    internal static class ViewInfo
    {
        public static ViewId HomeFor(UserRole role)
        {
            switch (role)
            {
                case UserRole.Cooperative: return ViewId.CoopDashboard;
                case UserRole.Administrator: return ViewId.Browse;
                default: return ViewId.Home;
            }
        }

        /// <summary>Which sidebar item lights up while this screen is open.</summary>
        public static ViewId NavGroup(ViewId id)
        {
            switch (id)
            {
                case ViewId.ProductDetail: return ViewId.Browse;
                case ViewId.Checkout: return ViewId.Cart;
                case ViewId.OrderTracking: return ViewId.Orders;
                case ViewId.CooperativeProfile: return ViewId.Cooperatives;
                case ViewId.ProductEditor: return ViewId.CoopProducts;
                default: return id;
            }
        }

        /// <summary>UI-level guard. The services enforce the same rules again, so this is a convenience, not the only defence.</summary>
        public static bool IsAllowed(ViewId id, UserRole role)
        {
            switch (role)
            {
                case UserRole.Consumer:
                    return id == ViewId.Home || id == ViewId.Browse || id == ViewId.ProductDetail || id == ViewId.Cart ||
                           id == ViewId.Checkout || id == ViewId.Orders || id == ViewId.OrderTracking ||
                           id == ViewId.Cooperatives || id == ViewId.CooperativeProfile || id == ViewId.Profile;
                case UserRole.Cooperative:
                    return id == ViewId.CoopDashboard || id == ViewId.CoopProducts || id == ViewId.ProductEditor ||
                           id == ViewId.CoopOrders || id == ViewId.CoopEarnings || id == ViewId.CoopMessages || id == ViewId.CoopProfile || id == ViewId.ProductDetail;
                case UserRole.Administrator:
                    return id == ViewId.Browse || id == ViewId.ProductDetail || id == ViewId.Cooperatives ||
                           id == ViewId.CooperativeProfile || id == ViewId.Profile;
                default:
                    return false;
            }
        }
    }
}
