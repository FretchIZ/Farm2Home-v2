using System.Collections.Generic;

namespace Farm2Home.UI.Navigation
{
    /// <summary>Which orders to show on the tracking screen, and whether to show the "Order placed" banner.</summary>
    internal sealed class OrderViewArg
    {
        public List<int> OrderIds { get; set; } = new List<int>();
        public bool JustPlaced { get; set; }
    }
}
