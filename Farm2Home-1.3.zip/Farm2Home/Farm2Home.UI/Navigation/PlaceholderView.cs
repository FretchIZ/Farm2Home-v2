using System.Drawing;
using System.Windows.Forms;

namespace Farm2Home.UI.Navigation
{
    /// <summary>Shown for screens that are built in the next phase, so navigation can be tested now.</summary>
    internal sealed class PlaceholderView : BaseView
    {
        public PlaceholderView(ViewId id)
        {
            var title = new Label
            {
                Text = id.ToString(), Font = Theme.Heading(26f), ForeColor = Theme.Deep, AutoSize = true,
                Location = new Point(Padding.Left, Padding.Top)
            };
            var note = new Label
            {
                Text = "This screen is built in Phase 5. The shell, sidebar and navigation around it are live.",
                Font = Theme.Body(11f), ForeColor = Theme.Muted, AutoSize = true,
                Location = new Point(Padding.Left, Padding.Top + 56)
            };
            Controls.Add(title);
            Controls.Add(note);
        }
    }
}
