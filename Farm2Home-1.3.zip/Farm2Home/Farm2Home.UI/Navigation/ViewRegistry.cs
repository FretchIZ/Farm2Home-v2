using Farm2Home.UI.Views;

namespace Farm2Home.UI.Navigation
{
    /// <summary>Connects each ViewId to the screen that implements it.</summary>
    internal static class ViewRegistry
    {
        public static void RegisterAll(NavigationService nav)
        {
            nav.Register(ViewId.Home, () => new HomeView());
            nav.Register(ViewId.Browse, () => new ProductsView());
            nav.Register(ViewId.ProductDetail, () => new ProductDetailView());
            nav.Register(ViewId.Cart, () => new CartView());
            nav.Register(ViewId.Checkout, () => new CheckoutView());
            nav.Register(ViewId.Orders, () => new OrdersView());
            nav.Register(ViewId.OrderTracking, () => new OrderTrackingView());
            nav.Register(ViewId.Cooperatives, () => new CooperativesView());
            nav.Register(ViewId.CooperativeProfile, () => new CooperativeProfileView());
            nav.Register(ViewId.CoopProfile, () => new CooperativeProfileView());
            nav.Register(ViewId.Profile, () => new ProfileView());
            nav.Register(ViewId.CoopDashboard, () => new CoopDashboardView());
            nav.Register(ViewId.CoopProducts, () => new CoopProductsView());
            nav.Register(ViewId.ProductEditor, () => new ProductEditorView());
            nav.Register(ViewId.CoopOrders, () => new CoopOrdersView());
            nav.Register(ViewId.CoopEarnings, () => new EarningsView());
            nav.Register(ViewId.CoopMessages, () => new CoopMessagesView());
        }
    }
}
