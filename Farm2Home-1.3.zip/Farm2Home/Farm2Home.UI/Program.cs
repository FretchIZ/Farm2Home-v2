using System;
using System.Windows.Forms;
using Farm2Home.Infrastructure.Configuration;
using Farm2Home.Infrastructure.Data;
using Farm2Home.UI.Components;
using Farm2Home.UI.Forms;

namespace Farm2Home.UI
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            // Page-speed + smoke test:  Farm2Home.exe --selftest [--shots folder] [--report file]
            if (Array.IndexOf(args, "--selftest") >= 0) return UiSelfTest.Run(args);

            try
            {
                // Multi-core JIT: later starts reuse a recorded profile so the window opens faster.
                string dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Farm2Home");
                System.IO.Directory.CreateDirectory(dir);
                System.Runtime.ProfileOptimization.SetProfileRoot(dir);
                System.Runtime.ProfileOptimization.StartProfile("startup.profile");
            }
            catch { /* optional speed-up only */ }

            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
            System.Windows.Forms.Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            System.Windows.Forms.Application.ThreadException += (s, e) => UiErrors.Show(null, e.Exception, "completing that action");
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                if (AppServices.Logger != null)
                    AppServices.Logger.Error(e.ExceptionObject as Exception ?? new Exception("Unknown error"), "Unhandled exception");
            };

            // Show the sign-in window straight away; the database check (find/create, never delete) runs in the background.
            var setup = System.Threading.Tasks.Task.Run(() =>
            {
                var r = DatabaseInitializer.EnsureReady();
                if (r.Success)
                {
                    try { AppServices.Initialize(); }               // builds the services and seeds demo accounts on the very first run
                    catch (Exception ex)
                    {
                        new FileLogger().Error(ex, "Starting services failed");
                        return new DatabaseSetupResult { UserMessage = "Farm2Home could not start its services.", Technical = DatabaseInitializer.Describe(ex) };
                    }
                }
                return r;
            });
            bool failed = false;

            // Sign in -> main window -> (Sign out returns here) ...
            while (true)
            {
                using (var login = new LoginForm(setup))
                {
                    var res = login.ShowDialog();
                    if (res == DialogResult.Abort) failed = true;
                    if (res != DialogResult.OK) break;
                }

                using (var shell = new MainShellForm())
                {
                    shell.ShowDialog();
                    if (!shell.LoggedOut) break;
                }
            }
            if (!failed && AppServices.Auth != null) AppServices.Auth.Logout();
            return 0;
        }
    }
}
