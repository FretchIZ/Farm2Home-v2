# Farm2Home (WinForms, .NET Framework 4.8, SQLite)

## Run
1. Open `Farm2Home.sln` in Visual Studio, Build > Rebuild Solution (restores the SQLite NuGet package).
2. Startup project: **Farm2Home.UI**, press F5.
3. Demo accounts (see `Database/DEMO_ACCOUNTS.md`), password `Farm2Home@2026`. Turn off with `SeedDemoAccounts=false` in `Farm2Home.UI/App.config`.

## Database
- SQLite file at `%LocalAppData%\Farm2Home\farm2home.db` (setting: `Farm2Home.UI/App.config`; `{LocalAppData}` is replaced at run time).
- Created and filled with sample data on first start from `Database/Schema.sql` and `Database/Seed.sql` (embedded in the app).
- An existing file is never dropped or overwritten; missing tables are added, sample data only goes into a brand-new file.
- Checkout runs in one transaction (stock check + order + stock update, rolled back on any failure). All SQL is parameterized.

## Start-up
`Program.cs` shows the sign-in window at once; `DatabaseInitializer.EnsureReady()` and `AppServices.Initialize()` run on a background thread and unlock Sign in.

## Tests
Set **Farm2Home.Tests** as startup project, Ctrl+F5. 96 checks: unit rules plus SQLite tests (search/filters, checkout, stock, rollback, persistence). `--unit-only` skips the SQLite ones.

## Accounts
- Email is validated (`EmailRules`), stored lower-case with a `CanonicalEmail` key (unique index) so Gmail dots/+tags cannot create duplicates.
- `AuthService.RegisterConsumer` is idempotent: same email + password again returns false and changes nothing.
- `SchemaMigrator` upgrades older database files in place or moves them aside as `*.bak-<time>`; nothing is ever deleted.
